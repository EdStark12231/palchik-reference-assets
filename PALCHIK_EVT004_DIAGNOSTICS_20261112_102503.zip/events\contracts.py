"""Typed contracts shared by event definitions and the runtime."""
from __future__ import annotations
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Mapping

class EventSource(str, Enum):
    RANDOM = "RANDOM"
    ACTION = "ACTION"
    GAME = "GAME"

class EventStatus(str, Enum):
    IDLE = "IDLE"
    WAITING = "WAITING"
    ACTIVE = "ACTIVE"
    SUSPENDED = "SUSPENDED"
    COMPLETED = "COMPLETED"
    CANCELLED = "CANCELLED"
    FAILED = "FAILED"

@dataclass(frozen=True)
class EventDefinition:
    event_id: str
    label: str
    description: str
    source: EventSource
    implementation: str
    config_file: str
    resources: tuple[str, ...] = ()
    exclusive_resources: tuple[str, ...] = ()
    subcategories: tuple[str, ...] = ()
    compatible_with: tuple[str, ...] = ()
    phase_policy: str = "CANCEL"
    interruptible: bool = True
    enabled: bool = True
    metadata: Mapping[str, Any] = field(default_factory=dict)

@dataclass
class EventInstance:
    instance_id: str
    event_id: str
    status: EventStatus = EventStatus.IDLE
    started_at: float | None = None
    finished_at: float | None = None
    data: dict[str, Any] = field(default_factory=dict)
    failure_reason: str | None = None
