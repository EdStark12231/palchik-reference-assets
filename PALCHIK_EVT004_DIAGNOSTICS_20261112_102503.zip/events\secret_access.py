"""Fixed numeric secret access and the PALCHIK event collection index."""
from __future__ import annotations

import secrets
from collections.abc import Mapping

EVENT_COLLECTION_ITEMS = (
    ("dead_people", "Я ВИЖУ МЁРТВЫХ ЛЮДЕЙ"),
    ("always_told_truth", "Я ВСЕГДА ГОВОРИЛ ПРАВДУ"),
    ("sweet_roll", "НАЙДИ СЛАДКИЙ РУЛЕТ"),
    ("talk_to_me", "ПОГОВОРИ СО МНОЙ"),
    ("road_of_adventures", "ДОРОГА ПРИКЛЮЧЕНИЙ"),
    ("you_are_all_wrong", "ДА, ВЫ БУКВАЛЬНО ВСЕ НЕ ПРАВЫ"),
    ("king_has_fallen", "КОРОЛЬ ПАЛ, МИЛОРД"),
    ("what_did_you_expect", "НУ.. А ЧТО ТЫ ОЖИДАЛ?"),
    ("cloning", "КЛОНИРОВАНИЕ"),
    ("why_did_i_do_that", "ЗАЧЕМ Я ЭТО СДЕЛАЛ?"),
    ("secret_level_unlocked", "СЕКРЕТНЫЙ УРОВЕНЬ РАЗБЛОКИРОВАН"),
    ("please_touch_anything", "ПЛИЗ ТАЧ ЭНИФИНГ"),
)
EVENT_COLLECTION_IDS = frozenset(item_id for item_id, _ in EVENT_COLLECTION_ITEMS)


SECRET_ACCESS_CODE = "172314"
SECRET_ACCESS_CODE_LENGTH = 6


def is_valid_numeric_code(candidate: str) -> bool:
    """Validate the fixed six-digit secret code; it never rotates per session."""
    return (
        isinstance(candidate, str)
        and len(candidate) == SECRET_ACCESS_CODE_LENGTH
        and candidate.isascii()
        and candidate.isdigit()
        and secrets.compare_digest(candidate, SECRET_ACCESS_CODE)
    )


def normalize_event_collection_progress(raw: object) -> dict[str, dict[str, bool]]:
    """Normalize known items and preserve progress for future event IDs."""
    source = raw if isinstance(raw, Mapping) else {}
    result: dict[str, dict[str, bool]] = {}
    for item_id, _ in EVENT_COLLECTION_ITEMS:
        item = source.get(item_id, {})
        if not isinstance(item, Mapping):
            item = {}
        found = bool(item.get("found", False))
        completed = bool(item.get("completed", False))
        result[item_id] = {"found": found or completed, "completed": completed}
    for item_id, item in source.items():
        if item_id in result or not isinstance(item_id, str) or not isinstance(item, Mapping):
            continue
        found = bool(item.get("found", False))
        completed = bool(item.get("completed", False))
        result[item_id] = {"found": found or completed, "completed": completed}
    return result


def mark_event_found(progress: object, event_id: str) -> dict[str, dict[str, bool]]:
    if event_id not in EVENT_COLLECTION_IDS:
        raise KeyError(f"Unknown PALCHIK collection event: {event_id}")
    result = normalize_event_collection_progress(progress)
    result[event_id]["found"] = True
    return result


def mark_event_completed(progress: object, event_id: str) -> dict[str, dict[str, bool]]:
    if event_id not in EVENT_COLLECTION_IDS:
        raise KeyError(f"Unknown PALCHIK collection event: {event_id}")
    result = normalize_event_collection_progress(progress)
    result[event_id]["found"] = True
    result[event_id]["completed"] = True
    return result


class SecretPromptSession:
    """Per-game-session gate for the two-click secret prompt.

    Collection unlock is intentionally not part of this state: it is persistent,
    while this object is reset whenever a new gameplay session begins.
    """

    def __init__(self) -> None:
        self.accepted_clicks = 0
        self.triggered_this_cycle = False
        self.completed_this_session = False

    def begin_session(self) -> None:
        self.accepted_clicks = 0
        self.triggered_this_cycle = False
        self.completed_this_session = False

    def begin_click_cycle(self) -> None:
        if self.completed_this_session:
            return
        self.accepted_clicks = 0
        self.triggered_this_cycle = False

    def register_accepted_click(self, accepted: bool = True) -> bool:
        if not accepted or self.completed_this_session:
            return False
        self.accepted_clicks += 1
        if self.accepted_clicks >= 2 and not self.triggered_this_cycle:
            self.triggered_this_cycle = True
            return True
        return False

    @property
    def prompt_pending(self) -> bool:
        return (
            not self.completed_this_session
            and self.triggered_this_cycle
            and self.accepted_clicks >= 2
        )

    def retry_after_cancel(self) -> None:
        if self.completed_this_session:
            return
        self.accepted_clicks = 0
        self.triggered_this_cycle = False

    def mark_completed(self) -> None:
        self.completed_this_session = True
        self.triggered_this_cycle = True


def choose_event_collection_icon_rect(
    surface_size: tuple[int, int],
    occupied_rects: object = (),
    icon_size: int = 42,
    margin: int = 18,
) -> tuple[int, int, int, int] | None:
    """Choose a free HUD slot without covering existing gameplay controls.

    Rectangles are supplied as (x, y, width, height). Candidates are ordered
    from upper-right down the right edge, then into free left-side slots.
    """
    width, height = int(surface_size[0]), int(surface_size[1])
    if width < icon_size or height < icon_size:
        return None

    occupied = []
    for rect in occupied_rects or ():
        if rect is None:
            continue
        try:
            x, y, w, h = (int(value) for value in rect)
        except (TypeError, ValueError):
            continue
        if w > 0 and h > 0:
            occupied.append((x, y, w, h))

    step = icon_size + 12
    candidates = [
        (width - icon_size - margin, margin),
        (width - icon_size - margin, margin + step),
        (width - icon_size - margin, margin + 2 * step),
        (margin, margin + step),
        (margin, height - icon_size - margin),
        (width - icon_size - margin, max(margin, height // 3)),
    ]

    def available(x: int, y: int) -> bool:
        if x < 0 or y < 0 or x + icon_size > width or y + icon_size > height:
            return False
        for ox, oy, ow, oh in occupied:
            if x < ox + ow and x + icon_size > ox and y < oy + oh and y + icon_size > oy:
                return False
        return True

    for x, y in candidates:
        if available(x, y):
            return (x, y, icon_size, icon_size)

    # Last-resort deterministic scan over the upper half of the HUD.
    y_limit = max(margin, min(height - icon_size - margin, height // 2))
    for y in range(margin, y_limit + 1, step):
        for x in range(width - icon_size - margin, margin - 1, -step):
            if available(x, y):
                return (x, y, icon_size, icon_size)
    return None
