"""Central audio service for PALCHIK.EXE.

Canonical audio assets stay under ``assets/music`` and are grouped by purpose.
The manifest is ``assets/music/audio_manifest.json``. Legacy flat paths remain
as migration fallbacks so old projects continue working while assets are sorted.
All manifest paths are relative to the project root unless they are absolute.
"""
from __future__ import annotations

import array
import json
import logging
import math
import random
import sys
from pathlib import Path
from typing import Iterable, Optional

import pygame

_LOGGER = logging.getLogger("PALCHIK.audio")

PROJECT_ROOT = Path(__file__).resolve().parent
AUDIO_ROOT = PROJECT_ROOT / "assets" / "music"
MANIFEST_PATH = AUDIO_ROOT / "audio_manifest.json"

# Defaults used when the manifest is missing or a mapping is not configured.
# The first existing path wins. Legacy paths intentionally remain as migration
# fallbacks; new assets should be put under assets/audio/.
DEFAULT_ASSET_PATHS: dict[str, tuple[str, ...]] = {
    # Canonical files are grouped under assets/music/<category>/.
    # Flat paths and assets/audio paths are transitional fallbacks only.
    "ui.click": (
        "assets/music/ui/arcade_double_response.wav",
        "assets/music/ui/pixel_click.wav",
        "assets/music/pixel_click.wav",
        "assets/audio/sfx/ui/arcade_double_response.wav",
    ),
    "gameplay.click": (
        "assets/music/gameplay/min_click.wav",
        "assets/music/gameplay/game_click.wav",
        "assets/music/min_click.wav",
        "assets/audio/sfx/gameplay/min_click.wav",
    ),
    "reward.lucky_coin": (
        "assets/music/rewards/lucky_coin.wav",
        "assets/music/lucky_coin.wav",
        "assets/audio/sfx/rewards/lucky_coin.wav",
    ),
    "music.menu": (
        "assets/music/background/main_menu_pixel.wav",
        "assets/music/background/main_menu_pixel.mp3",
        "assets/music/main_menu_pixel.wav",
        "assets/music/main_menu_pixel.mp3",
        "assets/audio/music/main_menu_pixel.wav",
    ),
    "music.game": (
        "assets/music/background/game_pixel.wav",
        "assets/music/background/game_pixel.mp3",
        "assets/music/game_pixel.wav",
        "assets/music/game_pixel.mp3",
        "assets/audio/music/game_pixel.wav",
    ),
    "minigame.chase_planet.timer_click": (
        "assets/music/ui/pixel_click.wav",
        "assets/music/minigames/chase_planet/timer_click.wav",
        "assets/music/minigames/chase_planet/timer_click.ogg",
        "assets/music/minigames/chase_planet/timer_click.mp3",
        "assets/music/min_click.wav",
        "assets/music/gameplay/min_click.wav",
        "assets/audio/sfx/minigames/chase_planet/timer_click.wav",
    ),
    "minigame.chase_planet.spawn": (
        "assets/music/minigames/chase_planet/start_mini_game_earth.wav",
        "assets/music/minigames/chase_planet/planet_spawn.wav",
        "assets/music/minigames/chase_planet/planet_spawn.ogg",
        "assets/music/minigames/chase_planet/planet_spawn.mp3",
        "assets/music/minigames/chase_planet/chase_planet_start.wav",
        "assets/music/planet_spawn.wav",
        "assets/music/chase_planet_start.wav",
        "assets/audio/sfx/minigames/chase_planet/planet_spawn.wav",
    ),
    "minigame.chase_planet.catch": (
        "assets/music/minigames/chase_planet/hit_planet_mini_game_earth.wav",
        "assets/music/minigames/chase_planet/planet_catch.wav",
        "assets/music/minigames/chase_planet/planet_catch.ogg",
        "assets/music/minigames/chase_planet/planet_catch.mp3",
        "assets/music/minigames/chase_planet/chase_planet_catch.wav",
        "assets/music/planet_catch.wav",
        "assets/music/chase_planet_catch.wav",
        "assets/audio/sfx/minigames/chase_planet/planet_catch.wav",
    ),
    "minigame.chase_planet.escape": (
        "assets/music/minigames/chase_planet/fail_mini_game_earth.wav",
        "assets/music/minigames/chase_planet/planet_escape.wav",
        "assets/music/minigames/chase_planet/planet_escape.ogg",
        "assets/music/minigames/chase_planet/planet_escape.mp3",
        "assets/music/minigames/chase_planet/chase_planet_escape.wav",
        "assets/music/planet_escape.wav",
        "assets/music/chase_planet_escape.wav",
        "assets/audio/sfx/minigames/chase_planet/planet_escape.wav",
    ),
    "minigame.chase_planet.click": (
        "assets/music/ui/pixel_click.wav",
    ),
    "minigame.chase_planet.victory": (
        "assets/music/minigames/chase_planet/victory_mini_game_earth.wav",
    ),
    "minigame.roach_attack.start": (
        "assets/music/minigames/roach_attack/roach_event_start.wav",
    ),
    "minigame.roach_attack.scuttle": (
        "assets/music/minigames/roach_attack/roach_scuttle_loop.wav",
    ),
    "minigame.roach_attack.squash": (
        "assets/music/minigames/roach_attack/roach_squash.wav",
    ),
}

_MINIGAME_EVENTS = {
    "timer_click": "minigame.chase_planet.click",
    "click": "minigame.chase_planet.click",
    "spawn": "minigame.chase_planet.spawn",
    "start": "minigame.chase_planet.spawn",
    "catch": "minigame.chase_planet.catch",
    "win": "minigame.chase_planet.victory",
    "victory": "minigame.chase_planet.victory",
    "escape": "minigame.chase_planet.escape",
    "miss": "minigame.chase_planet.escape",
    "fail": "minigame.chase_planet.escape",
    "defeat": "minigame.chase_planet.escape",
}


def _ensure_mixer() -> bool:
    """Initialize pygame's mixer when possible; return False instead of crashing."""
    try:
        if not pygame.mixer.get_init():
            pygame.mixer.init(frequency=44100, size=-16, channels=2, buffer=512)
        return True
    except pygame.error as exc:
        _LOGGER.warning("Mixer unavailable: %s", exc, exc_info=True)
        return False


def _normalise_paths(value) -> list[str]:
    """Accept a manifest value as a path string, list, or {paths: [...]} object."""
    if isinstance(value, str):
        return [value] if value.strip() else []
    if isinstance(value, (list, tuple)):
        return [item for item in value if isinstance(item, str) and item.strip()]
    if isinstance(value, dict):
        paths = value.get("paths", value.get("path", []))
        return _normalise_paths(paths)
    return []


class AudioController:
    """Owns music playback, caches sound effects, and routes sounds by purpose."""

    def __init__(self):
        global _DEFAULT_CONTROLLER

        self._volume = 0.8
        self.accessibility_audio = False
        self.current_music: Optional[str] = None
        self.audio_enabled = _ensure_mixer()
        self._sound_cache: dict[str, pygame.mixer.Sound] = {}
        self._loaded_paths: dict[str, Path] = {}
        self._warned: set[str] = set()
        self._manifest = self._read_manifest()
        self._channels: dict[str, pygame.mixer.Channel] = {}
        self._music_volume_factor = 1.0
        self._evt004_sfx_volume_factors: dict[str, float] = {}

        if self.audio_enabled:
            try:
                # Dedicated channels prevent a UI click from cutting off a reward,
                # and keep repeated mini-game clicks independent from background music.
                pygame.mixer.set_num_channels(max(22, pygame.mixer.get_num_channels()))
                self._channels = {
                    "ui": pygame.mixer.Channel(1),
                    "gameplay": pygame.mixer.Channel(2),
                    "minigame": pygame.mixer.Channel(3),
                    "reward": pygame.mixer.Channel(4),
                    "lore": pygame.mixer.Channel(5),
                    "custom": pygame.mixer.Channel(6),
                    "minigame_click": pygame.mixer.Channel(7),
                    "transition": pygame.mixer.Channel(8),
                    "roach_event": pygame.mixer.Channel(9),
                    "roach_ambience": pygame.mixer.Channel(10),
                    "roach_squash": pygame.mixer.Channel(11),
                    "evt003": pygame.mixer.Channel(12),
                    "evt004_appearance": pygame.mixer.Channel(13),
                    "evt004_roar": pygame.mixer.Channel(14),
                    "evt004_wing_flap_loop": pygame.mixer.Channel(15),
                    "evt004_fire_breath": pygame.mixer.Channel(16),
                    "evt004_ground_attack": pygame.mixer.Channel(17),
                    "evt004_landing": pygame.mixer.Channel(18),
                    "evt004_hit": pygame.mixer.Channel(19),
                    "evt004_death": pygame.mixer.Channel(20),
                    "evt004_interface_break": pygame.mixer.Channel(21),
                }
                self._apply_volume()
            except pygame.error as exc:
                self.audio_enabled = False
                self._warn_once("channels", f"Could not configure mixer channels: {exc}")

        # Legacy attributes are kept for code that inspects these fields.
        self.menu_music_path = self._first_existing("music.menu")
        self.game_music_path = self._first_existing("music.game")
        self.click_sound = self._load_sound_by_id("ui.click")
        self.lucky_sound = self._load_sound_by_id("reward.lucky_coin")
        self.click_channel = self._channels.get("ui")
        self._channel_switch_sound = self._build_channel_switch_sound()
        self._evt003_sounds = self._build_evt003_sounds()
        _DEFAULT_CONTROLLER = self

    def _read_manifest(self) -> dict:
        try:
            if not MANIFEST_PATH.is_file():
                return {}
            with MANIFEST_PATH.open("r", encoding="utf-8") as file:
                payload = json.load(file)
            sounds = payload.get("sounds", {}) if isinstance(payload, dict) else {}
            return sounds if isinstance(sounds, dict) else {}
        except (OSError, json.JSONDecodeError) as exc:
            self._warn_once("manifest", f"Cannot read {MANIFEST_PATH}: {exc}")
            return {}

    def _warn_once(self, key: str, message: str) -> None:
        if key not in self._warned:
            _LOGGER.warning("%s", message, exc_info=sys.exc_info()[0] is not None)
            self._warned.add(key)

    def _candidate_paths(self, asset_id: str) -> list[Path]:
        raw = _normalise_paths(self._manifest.get(asset_id))
        raw.extend(DEFAULT_ASSET_PATHS.get(asset_id, ()))
        seen: set[str] = set()
        paths: list[Path] = []
        for raw_path in raw:
            candidate = Path(raw_path).expanduser()
            if not candidate.is_absolute():
                candidate = PROJECT_ROOT / candidate
            # Deduplicate without requiring the path to exist.
            key = str(candidate.resolve(strict=False)).casefold()
            if key not in seen:
                seen.add(key)
                paths.append(candidate)
        return paths

    def _first_existing(self, asset_id: str) -> Optional[Path]:
        for path in self._candidate_paths(asset_id):
            if path.is_file():
                return path
        return None

    def _load_sound_by_id(self, asset_id: str) -> Optional[pygame.mixer.Sound]:
        if asset_id in self._sound_cache:
            return self._sound_cache[asset_id]
        if not self.audio_enabled:
            return None

        attempted = self._candidate_paths(asset_id)
        for path in attempted:
            if not path.is_file():
                continue
            try:
                sound = pygame.mixer.Sound(str(path))
                self._sound_cache[asset_id] = sound
                self._loaded_paths[asset_id] = path
                return sound
            except (pygame.error, OSError) as exc:
                self._warn_once(f"load:{asset_id}:{path}", f"Could not load {path}: {exc}")

        self._warn_once(
            f"missing:{asset_id}",
            f"Sound '{asset_id}' was not found. Checked: "
            + ", ".join(str(p.relative_to(PROJECT_ROOT)) if p.is_relative_to(PROJECT_ROOT) else str(p) for p in attempted),
        )
        return None

    def _get_channel(self, channel_name: str) -> Optional[pygame.mixer.Channel]:
        return self._channels.get(channel_name)

    def _apply_volume(self) -> None:
        if not self.audio_enabled:
            return
        try:
            pygame.mixer.music.set_volume(self._volume * self._music_volume_factor)
            for name, channel in self._channels.items():
                channel.set_volume(self._volume * self._evt004_sfx_volume_factors.get(name, 1.0))
        except pygame.error as exc:
            self._warn_once("volume", f"Could not apply volume: {exc}")

    def play_sfx(self, asset_id: str, channel: str = "gameplay", volume: Optional[float] = None, queue: bool = False) -> bool:
        """Play a catalog sound. Returns True only when playback was started."""
        if not self.audio_enabled:
            return False
        sound = self._load_sound_by_id(asset_id)
        target_channel = self._get_channel(channel)
        if sound is None or target_channel is None:
            return False
        try:
            target_channel.set_volume(self._volume if volume is None else max(0.0, min(1.0, volume)))
            if queue and target_channel.get_busy():
                target_channel.queue(sound)
            else:
                target_channel.play(sound)
            return True
        except pygame.error as exc:
            self._warn_once(f"play:{asset_id}", f"Could not play '{asset_id}': {exc}")
            return False

    def _build_channel_switch_sound(self) -> Optional[pygame.mixer.Sound]:
        """Synthesize a short TV channel-switch burst in memory; no audio asset is needed."""
        if not self.audio_enabled:
            return None
        mixer_spec = pygame.mixer.get_init()
        if not mixer_spec or mixer_spec[1] != -16:
            return None

        sample_rate, _, channel_count = mixer_spec
        rng = random.Random(0x50414C)
        sample_count = int(sample_rate * 0.48)
        samples = array.array("h")
        click_times = (0.025, 0.145)

        for frame in range(sample_count):
            t = frame / sample_rate
            hiss_envelope = min(1.0, t * 180.0) * max(0.0, 1.0 - t / 0.42)
            value = rng.uniform(-1.0, 1.0) * 0.34 * hiss_envelope

            for click_start in click_times:
                age = t - click_start
                if 0.0 <= age < 0.055:
                    decay = math.exp(-age * 92.0)
                    mechanical = (
                        0.48 * math.sin(2.0 * math.pi * 1180.0 * age)
                        + 0.22 * math.sin(2.0 * math.pi * 430.0 * age)
                        + 0.16 * rng.uniform(-1.0, 1.0)
                    ) * decay
                    value += mechanical

            pcm = int(max(-1.0, min(1.0, value)) * 32767)
            for _ in range(channel_count):
                samples.append(pcm)

        try:
            return pygame.mixer.Sound(buffer=samples.tobytes())
        except pygame.error as exc:
            self._warn_once("channel-switch-sound", f"Could not create channel-switch sound: {exc}")
            return None

    def play_channel_switch(self) -> bool:
        """Play the synthesized double-click and TV-static archive transition."""
        channel = self._get_channel("transition")
        if not self.audio_enabled or self._channel_switch_sound is None or channel is None:
            return False
        try:
            channel.set_volume(self._volume * 0.82)
            channel.play(self._channel_switch_sound)
            return True
        except pygame.error as exc:
            self._warn_once("play-channel-switch", f"Could not play channel-switch sound: {exc}")
            return False

    def _build_evt003_sounds(self):
        """Synthesize compact retro event cues in memory; no asset files required."""
        if not self.audio_enabled:
            return {}
        spec = pygame.mixer.get_init()
        if not spec or spec[1] != -16:
            return {}
        sample_rate, _, channels = spec

        def synth(kind):
            duration = {"typewriter": 0.026, "success": 0.42,
                        "failure": 0.92, "reprimand": 0.30}[kind]
            count = max(1, int(sample_rate * duration))
            data = array.array("h")
            for i in range(count):
                t = i / sample_rate
                if kind == "typewriter":
                    envelope = math.exp(-t * 115.0)
                    value = (math.sin(2 * math.pi * 1250 * t)
                             + 0.35 * math.sin(2 * math.pi * 2380 * t)) * envelope * 0.48
                elif kind == "success":
                    freq = 520 if t < 0.14 else 660 if t < 0.28 else 790
                    local = t if t < 0.14 else t - 0.14 if t < 0.28 else t - 0.28
                    envelope = min(1.0, t * 35.0) * max(0.0, 1.0 - t / duration)
                    value = math.sin(2 * math.pi * freq * local) * envelope * 0.38
                elif kind == "failure":
                    progress = t / duration
                    freq = 620.0 - 470.0 * progress
                    envelope = min(1.0, t * 22.0) * max(0.0, 1.0 - progress)
                    value = (math.sin(2 * math.pi * freq * t)
                             + 0.18 * math.sin(2 * math.pi * freq * 2.01 * t)) * envelope * 0.42
                else:
                    pulse = 1.0 if (t < 0.09 or 0.16 < t < 0.25) else 0.0
                    envelope = math.exp(-max(0.0, t - 0.16) * 22.0) if t > 0.16 else 1.0
                    carrier = math.sin(2 * math.pi * 178.0 * t)
                    value = math.tanh(carrier * 2.4) * pulse * envelope * 0.38
                pcm = int(max(-1.0, min(1.0, value)) * 32767)
                for _ in range(channels):
                    data.append(pcm)
            return pygame.mixer.Sound(buffer=data.tobytes())

        sounds = {}
        for name in ("typewriter", "success", "failure", "reprimand"):
            try:
                sounds[name] = synth(name)
            except pygame.error as exc:
                self._warn_once(f"evt003-sound:{name}", f"Could not synthesize EVT_003 {name}: {exc}")
        return sounds

    def play_evt003_sound(self, kind: str) -> bool:
        """Play a synthesized EVT_003 typewriter/success/failure/reprimand cue."""
        sound = getattr(self, "_evt003_sounds", {}).get(str(kind).lower().strip())
        channel = self._get_channel("evt003")
        if sound is None or channel is None:
            return False
        try:
            channel.set_volume(self._volume * (0.38 if kind == "typewriter" else 0.78))
            channel.play(sound)
            return True
        except pygame.error as exc:
            self._warn_once(f"play-evt003:{kind}", f"Could not play EVT_003 {kind}: {exc}")
            return False

    def play_typewriter_tick(self) -> bool:
        """Reusable short typewriter tick for character-by-character UI text."""
        return self.play_evt003_sound("typewriter")

    def play_evt003_success(self) -> bool:
        return self.play_evt003_sound("success")

    def play_evt003_failure(self) -> bool:
        return self.play_evt003_sound("failure")

    def play_evt003_reprimand(self) -> bool:
        return self.play_evt003_sound("reprimand")

    def play_click(self) -> bool:
        """Standard click for menu and interface buttons."""
        return self.play_sfx("ui.click", channel="ui")

    def play_game_click(self) -> bool:
        """Shorter click for the main gameplay target, separate from UI buttons."""
        return self.play_sfx("gameplay.click", channel="gameplay")

    def play_chase_planet(self, event: str, *, queue: bool = False) -> bool:
        """Play an event sound for the 'Catch the Planet' chase mini-game."""
        event_key = event.lower().strip()
        asset_id = _MINIGAME_EVENTS.get(event_key)
        if asset_id is None:
            self._warn_once(f"unknown-minigame:{event}", f"Unknown Chase Planet audio event: {event!r}")
            return False
        channel = "minigame_click" if asset_id == "minigame.chase_planet.click" else "minigame"
        event_volume = (
            self._volume * 0.60
            if asset_id == "minigame.chase_planet.spawn"
            else self._volume
        )
        return self.play_sfx(
            asset_id, channel=channel, volume=event_volume, queue=queue
        )

    def play_roach_attack(self, event: str) -> bool:
        """Play EVT_001 start, looping scuttle ambience, or squash impact."""
        config = {
            "start": ("minigame.roach_attack.start", "roach_event", 0.88, False),
            "scuttle_loop": ("minigame.roach_attack.scuttle", "roach_ambience", 0.22, True),
            "squash": ("minigame.roach_attack.squash", "roach_squash", 0.72, False),
        }
        item = config.get(str(event).lower().strip())
        if item is None:
            self._warn_once(f"unknown-roach-event:{event}", f"Unknown roach audio event: {event!r}")
            return False
        asset_id, channel_name, volume, loop = item
        if not self.audio_enabled:
            return False
        sound = self._load_sound_by_id(asset_id)
        channel = self._get_channel(channel_name)
        if sound is None or channel is None:
            return False
        try:
            channel.set_volume(self._volume * volume)
            channel.play(sound, loops=-1 if loop else 0)
            return True
        except pygame.error as exc:
            self._warn_once(f"play:{asset_id}", f"Could not play '{asset_id}': {exc}")
            return False

    def stop_roach_scuttle(self) -> None:
        """Stop only the dedicated looping ambience used by EVT_001."""
        channel = self._get_channel("roach_ambience")
        if channel is not None:
            try:
                channel.stop()
            except pygame.error as exc:
                self._warn_once("stop-roach-scuttle", f"Could not stop roach ambience: {exc}")

    def stop_roach_attack_audio(self) -> None:
        """Stop every sound channel owned exclusively by EVT_001."""
        for channel_name in ("roach_event", "roach_ambience", "roach_squash"):
            channel = self._get_channel(channel_name)
            if channel is not None:
                try:
                    channel.stop()
                except pygame.error as exc:
                    self._warn_once(
                        f"stop-{channel_name}",
                        f"Could not stop {channel_name}: {exc}",
                    )

    def play_lucky(self) -> bool:
        return self.play_sfx("reward.lucky_coin", channel="reward")

    def _play_music_id(self, asset_id: str, label: str) -> bool:
        if not self.audio_enabled:
            return False
        path = self._first_existing(asset_id)
        if path is None:
            self._warn_once(f"missing:{asset_id}", f"Music '{asset_id}' not found in canonical or legacy paths.")
            return False
        if self.current_music == label and pygame.mixer.music.get_busy():
            return True
        # If one candidate exists but has an unsupported/invalid format, continue to
        # other candidates instead of failing on the first file.
        for candidate in self._candidate_paths(asset_id):
            if not candidate.is_file():
                continue
            try:
                pygame.mixer.music.load(str(candidate))
                pygame.mixer.music.set_volume(self._volume)
                pygame.mixer.music.play(-1)
                self._music_volume_factor = 1.0
                self.current_music = label
                if label == "menu":
                    self.menu_music_path = candidate
                elif label == "game":
                    self.game_music_path = candidate
                return True
            except (pygame.error, OSError) as exc:
                self._warn_once(f"music:{asset_id}:{candidate}", f"Could not start music {candidate}: {exc}")
        return False

    def play_event_music(self, path: str | Path, *, volume: float = 0.7, label: str = "event") -> bool:
        """Play a looping event theme through pygame.mixer.music, not an SFX channel."""
        if not self.audio_enabled:
            return False
        requested = Path(path).expanduser()
        candidates = [requested] if requested.is_absolute() else [PROJECT_ROOT / requested, Path.cwd() / requested]
        resolved = next((item.resolve(strict=False) for item in candidates if item.is_file()), None)
        if resolved is None:
            self._warn_once(f"missing-event-music:{label}:{path}", f"Event music file not found: {path}")
            return False
        try:
            pygame.mixer.music.load(str(resolved))
            factor = max(0.0, min(1.0, float(volume)))
            self._music_volume_factor = factor
            pygame.mixer.music.set_volume(self._volume * self._music_volume_factor)
            pygame.mixer.music.play(-1)
            self.current_music = f"event:{label}"
            return True
        except (pygame.error, OSError, TypeError, ValueError) as exc:
            self._warn_once(f"event-music:{label}:{resolved}", f"Could not start event music {resolved}: {exc}")
            return False

    def stop_event_music(self, *, label: str | None = None) -> bool:
        """Stop the requested event track without stopping unrelated music."""
        if not self.audio_enabled:
            if self.current_music and self.current_music.startswith("event:"):
                self.current_music = None
            return False
        expected = f"event:{label}" if label else None
        if not self.current_music or not self.current_music.startswith("event:"):
            return False
        if expected is not None and self.current_music != expected:
            return False
        try:
            pygame.mixer.music.stop()
        except pygame.error as exc:
            self._warn_once("stop-event-music", f"Could not stop event music: {exc}")
            return False
        self.current_music = None
        return True

    def play_evt004_sfx(
        self, path: str | Path, *, event_key: str, loop: bool = False, volume: float = 0.78,
    ) -> bool:
        """Play a configured EVT004 one-shot or loop on its own dedicated channel."""
        key = str(event_key).strip().lower()
        channel = self._get_channel(f"evt004_{key}")
        if not self.audio_enabled or channel is None:
            return False
        requested = Path(path).expanduser()
        candidates = [requested] if requested.is_absolute() else [PROJECT_ROOT / requested, Path.cwd() / requested]
        resolved = next((item.resolve(strict=False) for item in candidates if item.is_file()), None)
        if resolved is None:
            self._warn_once(f"missing-evt004-sfx:{key}:{path}", f"EVT004 sound file not found: {path}")
            return False
        cache_key = f"file:{resolved}"
        sound = self._sound_cache.get(cache_key)
        if sound is None:
            try:
                sound = pygame.mixer.Sound(str(resolved))
            except (pygame.error, OSError) as exc:
                self._warn_once(f"load-evt004-sfx:{key}:{resolved}", f"Could not load EVT004 sound {resolved}: {exc}")
                return False
            self._sound_cache[cache_key] = sound
        try:
            factor = max(0.0, min(1.0, float(volume)))
            channel_name = f"evt004_{key}"
            self._evt004_sfx_volume_factors[channel_name] = factor
            channel.set_volume(self._volume * factor)
            if loop:
                channel.play(sound, loops=-1)
            else:
                channel.play(sound)
            return True
        except (pygame.error, TypeError, ValueError) as exc:
            self._warn_once(f"play-evt004-sfx:{key}", f"Could not play EVT004 sound {resolved}: {exc}")
            return False

    def stop_evt004_sfx(self, event_key: str) -> None:
        """Stop one EVT004 sound channel, typically the wing-flap loop."""
        channel = self._get_channel(f"evt004_{str(event_key).strip().lower()}")
        if channel is not None:
            try:
                channel.stop()
            except pygame.error as exc:
                self._warn_once(f"stop-evt004-sfx:{event_key}", f"Could not stop EVT004 sound {event_key}: {exc}")
        self._evt004_sfx_volume_factors.pop(f"evt004_{str(event_key).strip().lower()}", None)

    def stop_evt004_audio(self) -> None:
        """Stop every dedicated EVT004 SFX channel without affecting other events."""
        for name, channel in self._channels.items():
            if name.startswith("evt004_"):
                try:
                    channel.stop()
                except pygame.error as exc:
                    self._warn_once(f"stop-{name}", f"Could not stop {name}: {exc}")
                self._evt004_sfx_volume_factors.pop(name, None)

    def play_menu_music(self) -> bool:
        if self.audio_enabled and pygame.mixer.music.get_busy() and self.current_music != "menu":
            pygame.mixer.music.stop()
        return self._play_music_id("music.menu", "menu")

    def play_game_music(self) -> bool:
        if self.audio_enabled and pygame.mixer.music.get_busy() and self.current_music != "game":
            pygame.mixer.music.stop()
        return self._play_music_id("music.game", "game")

    def stop_music(self) -> None:
        if self.audio_enabled:
            try:
                pygame.mixer.music.stop()
            except pygame.error as exc:
                self._warn_once("stop-music", f"Could not stop music: {exc}")
        self.current_music = None
        self._music_volume_factor = 1.0

    def set_volume(self, value: float) -> None:
        try:
            self._volume = max(0.0, min(1.0, float(value)))
        except (TypeError, ValueError):
            return
        self._apply_volume()

    def play_file(self, path: str | Path, volume: Optional[float] = None, channel: str = "lore") -> bool:
        """Play a one-off file path, used by the in-game lore browser."""
        if not self.audio_enabled:
            return False
        requested = Path(path).expanduser()
        candidates = [requested] if requested.is_absolute() else [PROJECT_ROOT / requested, Path.cwd() / requested]
        resolved = next((candidate.resolve(strict=False) for candidate in candidates if candidate.is_file()), None)
        if resolved is None:
            self._warn_once(f"missing-file:{path}", f"Audio file not found: {path}")
            return False

        cache_key = str(resolved)
        sound = self._sound_cache.get(cache_key)
        if sound is None:
            try:
                sound = pygame.mixer.Sound(str(resolved))
            except (pygame.error, OSError) as exc:
                self._warn_once(f"load-file:{resolved}", f"Could not load {resolved}: {exc}")
                return False
            self._sound_cache[cache_key] = sound
        return self.play_sfx_from_sound(sound, channel=channel, volume=volume, cache_key=cache_key)

    def play_sfx_from_sound(
        self,
        sound: pygame.mixer.Sound,
        channel: str = "custom",
        volume: Optional[float] = None,
        cache_key: str = "custom-file",
    ) -> bool:
        target_channel = self._get_channel(channel)
        if not self.audio_enabled or target_channel is None:
            return False
        try:
            target_channel.set_volume(self._volume if volume is None else max(0.0, min(1.0, volume)))
            target_channel.play(sound)
            return True
        except pygame.error as exc:
            self._warn_once(f"play-file:{cache_key}", f"Could not play custom audio {cache_key}: {exc}")
            return False


_DEFAULT_CONTROLLER: Optional[AudioController] = None


def play_sound(path: str | Path, volume: Optional[float] = None) -> bool:
    """Backward-compatible module function used by game_scene's lore browser."""
    global _DEFAULT_CONTROLLER
    if _DEFAULT_CONTROLLER is None:
        _DEFAULT_CONTROLLER = AudioController()
    return _DEFAULT_CONTROLLER.play_file(path, volume=volume, channel="lore")
