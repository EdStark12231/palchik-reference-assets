"""EVT_004 Adventure Road presentation adapter for the live GameScene renderer.

Draws the dragon and damaged interface targets over the freshly rendered
GameScene surface. The host game owns the surface and input; this module only
adds the event overlay layer.
"""
from __future__ import annotations

import pygame
from typing import Optional

from .adventure_road_runtime import AdventureRoadRuntime, TargetSpec
from .adventure_road_dragon import InterfaceTarget


class AdventureRoadPresentation:
    """Thin overlay: reads live GameScene UI rects and draws the event on top."""

    # Target keys mapped to GameScene attribute names and default sizes.
    TARGET_SPECS = (
        TargetSpec(key="back", label="КНОПКА НАЗАД", kind="button", priority=1,
                   attack_mode="air", hp=2),
        TargetSpec(key="target", label="ЦЕЛЕВАЯ КНОПКА", kind="button", priority=2,
                   attack_mode="air", hp=2),
        TargetSpec(key="phrase", label="КНОПКА ФРАЗЫ", kind="button", priority=1,
                   attack_mode="ground", hp=2),
        TargetSpec(key="instant_wash", label="МГНОВЕННАЯ МОЙКА", kind="button", priority=2,
                   attack_mode="air", hp=2),
        TargetSpec(key="free_wash", label="БЕСПЛАТНАЯ МОЙКА", kind="button", priority=1,
                   attack_mode="ground", hp=2),
        TargetSpec(key="wallpaper", label="ОБОИ", kind="button", priority=1,
                   attack_mode="air", hp=1),
        TargetSpec(key="pbar", label="ПАНЕЛЬ ПРОГРЕССА", kind="button", priority=3,
                   attack_mode="air", hp=3),
        TargetSpec(key="name_entry", label="ВВОД ИМЕНИ", kind="button", priority=2,
                   attack_mode="ground", hp=2),
    )

    def __init__(self, game_view):
        self.game_view = game_view
        self.font: Optional[pygame.font.Font] = None
        self._target_specs: list[TargetSpec] = list(self.TARGET_SPECS)
        self._field_rect: Optional[pygame.Rect] = None

    def _font(self) -> pygame.font.Font:
        if self.font is None:
            self.font = pygame.font.SysFont("Arial", 16, bold=True)
        return self.font

    def build_field_rect(self, surface_size: tuple[int, int]) -> pygame.Rect:
        """Play field for the dragon: most of the screen minus UI margins."""
        width, height = surface_size
        margin_x = int(width * 0.05)
        margin_y = int(height * 0.12)
        return pygame.Rect(
            margin_x, margin_y,
            width - 2 * margin_x,
            height - margin_y - int(height * 0.10),
        )

    def collect_target_rects(self, surface_size: tuple[int, int]) -> list[TargetSpec]:
        """Read live UI rects from GameScene and return TargetSpecs with real positions."""
        width, height = surface_size
        view = self.game_view
        specs = []

        def spec_for(key: str, label: str, kind: str, priority: int,
                     attack_mode: str, hp: int,
                     rect: Optional[pygame.Rect], fallback: pygame.Rect) -> TargetSpec:
            r = pygame.Rect(fallback)
            if rect is not None and rect.width > 0 and rect.height > 0:
                r = pygame.Rect(rect)
            # Keep targets inside the field.
            r.clamp_ip(pygame.Rect(0, 0, width, height))
            return TargetSpec(key=key, label=label, rect=r, kind=kind,
                              priority=priority, attack_mode=attack_mode, hp=hp)

        candidates = [
            ("back", "КНОПКА НАЗАД", "button", 1, "air", 2,
             getattr(view, "rect_back", None),
             pygame.Rect(12, 12, 40, 40)),
            ("target", "ЦЕЛЕВАЯ КНОПКА", "button", 2, "air", 2,
             getattr(view, "rect_target", None),
             pygame.Rect(width - 200, 100, 180, 180)),
            ("phrase", "КНОПКА ФРАЗЫ", "button", 1, "ground", 2,
             getattr(view, "rect_phrase_btn", None),
             pygame.Rect(12, height - 60, 240, 40)),
            ("instant_wash", "МГНОВЕННАЯ МОЙКА", "button", 2, "air", 2,
             getattr(view, "rect_instant_wash", None),
             pygame.Rect(width // 2 - 180, height - 110, 360, 44)),
            ("free_wash", "БЕСПЛАТНАЯ МОЙКА", "button", 1, "ground", 2,
             getattr(view, "rect_free_wash_btn", None),
             pygame.Rect(width // 2 - 180, height - 60, 360, 44)),
            ("wallpaper", "ОБОИ", "button", 1, "air", 1,
             getattr(view, "rect_wallpaper", None),
             pygame.Rect(12, 60, 40, 40)),
            ("pbar", "ПАНЕЛЬ ПРОГРЕССА", "button", 3, "air", 3,
             getattr(view, "rect_pbar", None),
             pygame.Rect(width // 2 - 200, 12, 400, 36)),
            ("name_entry", "ВВОД ИМЕНИ", "button", 2, "ground", 2,
             getattr(view, "rect_name_entry_btn", None),
             pygame.Rect(width // 2 - 180, height - 160, 360, 50)),
        ]

        for key, label, kind, priority, attack_mode, hp, rect, fallback in candidates:
            specs.append(spec_for(key, label, kind, priority, attack_mode, hp, rect, fallback))

        return specs

    def build_runtime(self, surface_size: tuple[int, int], project_root,
                      dragon_hp: int = 8, seed: int | None = None) -> AdventureRoadRuntime:
        """Create a fresh AdventureRoadRuntime with live UI targets."""
        field = self.build_field_rect(surface_size)
        self._field_rect = field
        specs = self.collect_target_rects(surface_size)
        return AdventureRoadRuntime(
            field_rect=field,
            target_specs=specs,
            project_root=project_root,
            dragon_hp=dragon_hp,
            seed=seed,
        )

    def draw(self, surface: pygame.Surface, runtime: AdventureRoadRuntime,
             background_snapshot: pygame.Surface) -> None:
        """Draw the dragon and target damage over the game surface."""
        if runtime is None or not runtime.running:
            return
        runtime.draw(surface, background_snapshot)
