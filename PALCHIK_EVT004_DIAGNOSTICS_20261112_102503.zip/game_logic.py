import time
from save_manager import SaveManager
import random
import math
import unicodedata
import pygame
import localization
from events.evt003_penalties import EVT003PenaltyLedger, EVENT_ID as EVT003_EVENT_ID

PHASE_THRESHOLDS = {
    "phase_0": 0,
    "phase_1": 1500,
    "phase_2": 2000,
    "phase_3": 2500,
    "phase_4": 2800,
    "final": 3000
}

PHASE_NAMES = {
    "phase_0": "PHASE 0",
    "phase_1": "PHASE 1",
    "phase_2": "PHASE 2",
    "phase_3": "PHASE 3",
    "phase_4": "PHASE 4",
    "final": "FINAL PHASE"
}

class GameLogic:
    def __init__(self, ui_update_callback, limit_reached_callback, clean_finished_callback,translations=None):
        self.clicks_in_cycle = 0
        self.upgrade_cost = 10
        self.timer_active = False
        self.on_ui_update = ui_update_callback
        self.on_limit_reached = limit_reached_callback
        self.on_clean_finished = clean_finished_callback
        self.translations = translations if translations else {}
        
        
        saved_data = SaveManager.load_game_data()
        self.score = saved_data["score"]
        evt003_saved_state = SaveManager.load_event_state(EVT003_EVENT_ID)
        self.evt003_penalty_ledger = EVT003PenaltyLedger(evt003_saved_state)
        pending_notice = evt003_saved_state.get("pending_notification")
        self.evt003_pending_notification = (
            dict(pending_notice) if isinstance(pending_notice, dict) else None
        )
        self.current_lang = saved_data["lang"]
        self.total_clicks = saved_data.get("total_clicks", 0)
        self.wallpaper_index = saved_data.get("wallpaper_index", 0)
        self.base_timer_duration = 30000
        self.timer_duration = 30000
        self.timer_start_time = 0
        self.last_second_checked = 30
        self.horror_cooldown = False
        
        self.screenshot_requested = False
        self.screenshot_ticks = 0

        self.click_timestamps = []
        self.system_jammed = False
        self.ghost_mode_active = False
        self.required_final_clicks = 0
        self.current_final_clicks = 0

        self.minigame_active = False
        self.memory_sectors = ["0x0F", "0x3B", "0x7A", "0xFF"]
        self.target_sector_index = 0
        self.minigame_progress = 0
        self.cooldown_clicks_remaining = 0
        self.timer_active = False
        self.timer_start_time = 0
        self.seconds_left = 30
        self.timer_clicks = 0
        self.timer_scale = 1.0

        self.sprite_active = False
        self.sprite_x = 0.0
        self.sprite_y = 0.0
        self.sprite_speed = 3.5

        # Состояние Chase Planet. Старые координаты сохранены
        # для совместимости с остальными участками игры.
        self.chase_planets = []
        self.chase_planet_active = False
        self.chase_planet_rounds_started = 0
        self.chase_planets_target_count = 0
        self.chase_planets_caught_round = 0
        self.chase_planets_caught_total = 0
        self.timer_clicks = 0
        self.timer_scale = 1.0
        self.fade_screen_active = False
        self.fade_start_time = 0
        self.fade_duration = 3000 

        self.notification_text = ""
        self.notification_color = (255, 255, 255)
        self.notification_timer = 0
        self.notification_duration = 3000
        
        # Name verification system
        self.player_name = ""
        self.system_name = "ПАЛЧИК"
        self.name_verified = False
        self.system_os_user = saved_data.get("system_os_user", "")
        self.is_authentic = False
        self.secret_code = saved_data.get("secret_code", [])
        self.hidden_hitbox_x = saved_data.get("hidden_hitbox_x", 0)
        self.hidden_hitbox_y = saved_data.get("hidden_hitbox_y", 0)
        self.lore_icon_visible = saved_data.get("lore_icon_visible", False)
        if not self.secret_code:
            self.secret_code = [14, 17, 23]
            random.shuffle(self.secret_code)
        self.code_window_open = False
        self.lore_window_open = False
        self.lore_text_viewer_open = False
        self.lore_image_viewer_open = False
        self.lore_text_viewer_title = ""
        self.lore_text_viewer_content = ""
        self.lore_image_viewer_image = None
        self.input_buffer = [None, None, None]  # три двузначных числа
        self.current_cell_index = 0  # текущая активная ячейка (0-2)
        self.current_cell_buffer = ""  # временный буфер для набора цифр в текущей ячейке
        self.failed_attempts_count = 0
        self.auto_close_timer = 0.0
        self.system_response_text = ""
        
        # Click phrases system
        self.special_phrase_triggered = False
        self.click_phrase_cooldown = 0.0
        self.current_click_phrase = ""
        self.click_phrase_timer = 0.0
        self.click_phrase_alpha = 0
        self.click_phrase_scale = 0.0
        self.click_phrase_y_offset = 0
        # EVT_001_ROACH_ATTACK: временные параметры первого тестового события.
        self.roach_attack_active = False
        self.roach_entities = []
        self.roach_reward_per_roach = 1
        self.roach_event_squashed = 0
        self.roach_event_spawned = 0
        self.roach_event_status = "IDLE"
        self.roach_sequence_click_times = []
        self.roach_sequence_pending = False
        self.roach_sequence_deadline = 0.0
        self.roach_sequence_pause_duration = 1.0
        self.roach_sequence_grace_deadline = 0.0
        self.roach_sequence_second_clicks = 0
        self.roach_sequence_second_deadline = 0.0
        # EVT_002_WORD_SHOCK runtime state (not saved to disk).
        self.word_shock_active = False
        self.word_shock_started_at = 0.0
        self.word_shock_end_at = 0.0
        self.word_shock_duration_seconds = 0
        self.word_shock_modal_visible = False
        self.word_shock_modal_opened_at = 0.0
        self.word_shock_input = ""
        self.word_shock_feedback = ""
        self.word_shock_extensions = 0
        self.word_shock_event_status = "IDLE"
        self.word_shock_confirmation_after_seconds = 30.0
        self.word_shock_wrong_answer_extension_seconds = 60

    def _clear_event_sequence(self):
        self.roach_sequence_click_times = []
        self.roach_sequence_pending = False
        self.roach_sequence_deadline = 0.0
        self.roach_sequence_grace_deadline = 0.0
        self.roach_sequence_second_clicks = 0
        self.roach_sequence_second_deadline = 0.0

    def reset_roach_attack(self):
        """Сбросить только временное состояние EVT_001."""
        self.roach_attack_active = False
        self.roach_entities = []
        self.roach_event_squashed = 0
        self.roach_event_spawned = 0
        self.roach_event_status = "IDLE"
        self._clear_event_sequence()

    def stop_roach_attack(self):
        """Остановить EVT_001, сохранив уже начисленные очки."""
        self.roach_attack_active = False
        self.roach_entities = []
        self.roach_event_status = "STOPPED"
        self._clear_event_sequence()

    def record_roach_sequence_click(self, now=None):
        """Распознаёт 3 клика + паузу (EVT_001) и 3 + пауза + 3 (EVT_002)."""
        if self.roach_attack_active or self.word_shock_active:
            return "BLOCKED"
        now = time.monotonic() if now is None else float(now)
        if self.roach_sequence_second_clicks:
            if now > self.roach_sequence_second_deadline:
                self._clear_event_sequence()
                return "ROACH_TRIGGER"
            self.roach_sequence_second_clicks += 1
            if self.roach_sequence_second_clicks >= 3:
                self._clear_event_sequence()
                return "WORD_SHOCK_TRIGGER"
            self.roach_sequence_second_deadline = now + 1.0
            return "WORD_SEQUENCE"
        if self.roach_sequence_pending:
            if now < self.roach_sequence_deadline:
                self._clear_event_sequence()
                self.roach_sequence_click_times = [now]
                return "RESET_SEQUENCE"
            if now <= self.roach_sequence_grace_deadline:
                self.roach_sequence_pending = False
                self.roach_sequence_click_times = []
                self.roach_sequence_second_clicks = 1
                self.roach_sequence_second_deadline = now + 1.0
                return "WORD_SEQUENCE"
            self._clear_event_sequence()
            return "ROACH_TRIGGER"
        self.roach_sequence_click_times.append(now)
        if len(self.roach_sequence_click_times) >= 3:
            self.roach_sequence_click_times = []
            self.roach_sequence_pending = True
            self.roach_sequence_deadline = now + self.roach_sequence_pause_duration
            self.roach_sequence_grace_deadline = self.roach_sequence_deadline + 1.0
            return "ROACH_CANDIDATE"
        return "COLLECTING"

    def update_roach_sequence(self, now=None):
        """Вернуть ROACH_TRIGGER после паузы и окна распознавания второй тройки."""
        if not self.roach_sequence_pending and not self.roach_sequence_second_clicks:
            return ""
        now = time.monotonic() if now is None else float(now)
        if self.roach_sequence_second_clicks and now >= self.roach_sequence_second_deadline:
            self._clear_event_sequence()
            return "ROACH_TRIGGER"
        if self.roach_sequence_pending and now >= self.roach_sequence_grace_deadline:
            self._clear_event_sequence()
            return "ROACH_TRIGGER"
        return ""

    def start_word_shock(
        self, duration_seconds=None, now=None, *,
        confirmation_after_seconds=30.0, wrong_answer_extension_seconds=60,
    ):
        """Запустить EVT_002 без изменения счёта, цикла кликов и общего прогресса."""
        if (
            self.word_shock_active
            or self.roach_attack_active
            or self.minigame_active
            or self.timer_active
            or self.sprite_active
            or self.fade_screen_active
            or self.chase_planet_active
            or self.clicks_in_cycle >= 10
        ):
            return False
        now = time.monotonic() if now is None else float(now)
        duration = random.randint(120, 180) if duration_seconds is None else int(duration_seconds)
        duration = max(120, min(180, duration))
        self._clear_event_sequence()
        self.word_shock_active = True
        self.word_shock_started_at = now
        self.word_shock_end_at = now + duration
        self.word_shock_duration_seconds = duration
        self.word_shock_confirmation_after_seconds = max(0.0, float(confirmation_after_seconds))
        self.word_shock_wrong_answer_extension_seconds = max(1, int(wrong_answer_extension_seconds))
        self.word_shock_modal_visible = False
        self.word_shock_modal_opened_at = 0.0
        self.word_shock_input = ""
        self.word_shock_feedback = ""
        self.word_shock_extensions = 0
        self.word_shock_event_status = "ACTIVE"
        return True

    def update_word_shock(self, now=None):
        """Обновить 30-секундную задержку окна и срок действия события."""
        if not self.word_shock_active:
            return ""
        now = time.monotonic() if now is None else float(now)
        if now >= self.word_shock_end_at:
            self.word_shock_active = False
            self.word_shock_modal_visible = False
            self.word_shock_input = ""
            self.word_shock_event_status = "COMPLETED"
            return "EXPIRED"
        if (
            not self.word_shock_modal_visible
            and now - self.word_shock_started_at >= self.word_shock_confirmation_after_seconds
        ):
            self.word_shock_modal_visible = True
            self.word_shock_modal_opened_at = now
            return "MODAL_OPEN"
        return ""

    def submit_word_shock_answer(self, answer):
        """Принять подтверждение или продлить событие на 60 секунд."""
        if not self.word_shock_active or not self.word_shock_modal_visible:
            return "INACTIVE"
        normalized = unicodedata.normalize("NFKC", str(answer or "")).casefold().replace("ё", "е")
        normalized = "".join(char for char in normalized if char.isalnum())
        if not normalized:
            return "EMPTY"
        accepted = {
            "хорошо", "ок", "окей", "ладно", "принято", "понял", "поняла",
            "подтверждаю", "подтверждено", "подтверждаюсогласие",
            "согласен", "согласна", "согласенсвами", "согласнасвами",
            "да", "даконечно", "конечно", "разумеется", "верно",
            "безпроблем", "договорились", "согласовано", "принимаю",
            "ясогласен", "ясогласна", "японял", "явсепонял",
            "всепонятно", "хорошопонял", "хорошояпонял", "окейпонял",
            "ладнопонял", "yes", "ok", "okay", "alright", "understood",
            "confirmed",
        }
        if normalized in accepted:
            self.word_shock_active = False
            self.word_shock_modal_visible = False
            self.word_shock_input = ""
            self.word_shock_feedback = ""
            self.word_shock_event_status = "COMPLETED"
            return "ACCEPTED"
        self.word_shock_end_at += float(self.word_shock_wrong_answer_extension_seconds)
        self.word_shock_extensions += 1
        self.word_shock_input = ""
        self.word_shock_feedback = (
            f"ОТВЕТ НЕ ПРИНЯТ. +{self.word_shock_wrong_answer_extension_seconds} СЕКУНД."
        )
        return "EXTENDED"

    def stop_word_shock(self):
        self.word_shock_active = False
        self.word_shock_modal_visible = False
        self.word_shock_input = ""
        self.word_shock_feedback = ""
        self.word_shock_event_status = "STOPPED"
        self._clear_event_sequence()

    def reset_word_shock(self):
        self.word_shock_active = False
        self.word_shock_started_at = 0.0
        self.word_shock_end_at = 0.0
        self.word_shock_duration_seconds = 0
        self.word_shock_modal_visible = False
        self.word_shock_modal_opened_at = 0.0
        self.word_shock_input = ""
        self.word_shock_feedback = ""
        self.word_shock_extensions = 0
        self.word_shock_event_status = "IDLE"
        self._clear_event_sequence()

    def inspect_word_shock(self):
        labels = {
            "IDLE": "НЕ ЗАПУЩЕНО",
            "ACTIVE": "АКТИВНО",
            "STOPPED": "ОСТАНОВЛЕНО",
            "COMPLETED": "ЗАВЕРШЕНО",
        }
        return (
            f"EVT_002_WORD_SHOCK | Состояние: {labels.get(self.word_shock_event_status, self.word_shock_event_status)} | "
            f"Базовая длительность: {self.word_shock_duration_seconds} сек. | "
            f"Продлений: {self.word_shock_extensions}"
        )

    def start_roach_attack(self, entities):
        """Запустить реальное состояние EVT_001 с переданными координатами пяти тараканов."""
        if (
            self.roach_attack_active
            or self.word_shock_active
            or not entities
            or self.minigame_active
            or self.timer_active
            or self.sprite_active
            or self.fade_screen_active
            or self.chase_planet_active
        ):
            return False
        self.roach_entities = [dict(item) for item in entities]
        self.roach_attack_active = True
        self.roach_event_spawned = len(self.roach_entities)
        self.roach_event_squashed = 0
        self.roach_event_status = "ACTIVE"
        self._clear_event_sequence()
        labels = {
            "RU": "НАПАДЕНИЕ ТАРАКАНОВ",
            "US": "ROACH ATTACK",
            "ES": "ATAQUE DE CUCARACHAS",
            "DE": "KAKERLAKENANGRIFF",
        }
        label = labels.get(str(self.current_lang).upper(), labels["RU"])
        self.set_notification(label, duration=2200)
        self.notification_color = (220, 190, 110)
        return True

    def update_roaches(self, dt, width, height, forbidden_rect=None, cursor_pos=None):
        """Хаотичное движение тараканов с реакцией бегства от курсора."""
        if not self.roach_attack_active:
            return
        dt = max(0.0, min(float(dt), 0.05))
        width = max(100, int(width))
        height = max(100, int(height))
        roach_w, roach_h = 32, 25
        min_x, max_x = 26.0, float(max(26, width - roach_w - 26))
        min_y = float(max(132, int(height * 0.27)))
        max_y = float(max(int(min_y), height - 118))

        for roach in self.roach_entities:
            delay = float(roach.get("spawn_delay", 0.0))
            if delay > 0.0:
                delay = max(0.0, delay - dt)
                roach["spawn_delay"] = delay
                if delay > 0.0:
                    continue
                roach["visible"] = True

            if not roach.get("visible", True):
                roach["visible"] = True

            base_speed = float(roach.get("base_speed", 112.0))
            vx, vy = float(roach.get("vx", 0.0)), float(roach.get("vy", 0.0))
            turn_timer = float(roach.get("turn_timer", 0.0)) - dt

            if cursor_pos is not None:
                cx, cy = float(cursor_pos[0]), float(cursor_pos[1])
                dx = (float(roach["x"]) + roach_w * 0.5) - cx
                dy = (float(roach["y"]) + roach_h * 0.5) - cy
                distance = math.hypot(dx, dy)
            else:
                distance = 9999.0
                dx = dy = 0.0

            if distance < 205.0 and distance > 0.01:
                intensity = 1.0 - distance / 205.0
                flee_speed = base_speed * (2.05 + intensity * 1.10)
                desired_vx = dx / distance * flee_speed
                desired_vy = dy / distance * flee_speed
                blend = min(1.0, dt * (7.0 + intensity * 7.0))
                vx += (desired_vx - vx) * blend
                vy += (desired_vy - vy) * blend
                roach["turn_timer"] = max(turn_timer, 0.22)
            else:
                if turn_timer <= 0.0:
                    angle = math.atan2(vy, vx) + random.uniform(-0.95, 0.95)
                    target_speed = base_speed * random.uniform(0.78, 1.22)
                    vx = math.cos(angle) * target_speed
                    vy = math.sin(angle) * target_speed
                    turn_timer = random.uniform(0.30, 0.82)
                roach["turn_timer"] = turn_timer

            roach["turn_timer"] = max(0.0, float(roach.get("turn_timer", turn_timer)))
            # Gentle separation keeps the swarm from collapsing into one pile.
            repel_x = repel_y = 0.0
            for other in self.roach_entities:
                if other is roach or other.get("spawn_delay", 0.0) > 0.0 or not other.get("visible", True):
                    continue
                ox = (float(roach["x"]) + roach_w * 0.5) - (float(other["x"]) + roach_w * 0.5)
                oy = (float(roach["y"]) + roach_h * 0.5) - (float(other["y"]) + roach_h * 0.5)
                distance_sq = ox * ox + oy * oy
                if 1.0 < distance_sq < 46.0 * 46.0:
                    distance_other = math.sqrt(distance_sq)
                    strength = (46.0 - distance_other) / 46.0
                    repel_x += (ox / distance_other) * strength * base_speed * 0.75
                    repel_y += (oy / distance_other) * strength * base_speed * 0.75
            vx += repel_x * min(1.0, dt * 3.0)
            vy += repel_y * min(1.0, dt * 3.0)

            speed = math.hypot(vx, vy)
            max_speed = base_speed * (3.0 if distance < 205.0 else 1.45)
            min_speed = base_speed * 0.58
            if speed > max_speed:
                vx, vy = vx / speed * max_speed, vy / speed * max_speed
            elif 0.01 < speed < min_speed:
                vx, vy = vx / speed * min_speed, vy / speed * min_speed

            x = float(roach["x"]) + vx * dt
            y = float(roach["y"]) + vy * dt
            if x < min_x or x > max_x:
                vx = -vx
                x = max(min_x, min(max_x, x))
            if y < min_y or y > max_y:
                vy = -vy
                y = max(min_y, min(max_y, y))

            candidate = pygame.Rect(int(x), int(y), roach_w, roach_h)
            if forbidden_rect is not None and candidate.colliderect(forbidden_rect):
                center_x, center_y = candidate.center
                if abs(center_x - forbidden_rect.centerx) >= abs(center_y - forbidden_rect.centery):
                    if center_x < forbidden_rect.centerx:
                        x = forbidden_rect.left - roach_w - 4
                        vx = -abs(vx)
                    else:
                        x = forbidden_rect.right + 4
                        vx = abs(vx)
                else:
                    if center_y < forbidden_rect.centery:
                        y = forbidden_rect.top - roach_h - 4
                        vy = -abs(vy)
                    else:
                        y = forbidden_rect.bottom + 4
                        vy = abs(vy)

            roach["x"] = max(min_x, min(max_x, x))
            roach["y"] = max(min_y, min(max_y, y))
            roach["vx"], roach["vy"] = vx, vy
            if abs(vx) >= abs(vy):
                roach["direction"] = "right" if vx >= 0 else "left"
            else:
                roach["direction"] = "down" if vy >= 0 else "up"
            roach["turn_timer"] = max(0.0, float(roach.get("turn_timer", turn_timer)))

    def squash_roach(self, index):
        """Раздавить таракана, начислить одну монету и обновить сохранение."""
        if not self.roach_attack_active or not 0 <= int(index) < len(self.roach_entities):
            return 0
        self.roach_entities.pop(int(index))
        reward = int(self.roach_reward_per_roach)
        self.score += reward
        self.roach_event_squashed += 1
        self._sync_to_disk()
        self.on_ui_update()
        self.set_notification(f"+{reward}", duration=850)
        self.notification_color = (255, 215, 80)
        if not self.roach_entities:
            self.roach_attack_active = False
            self.roach_event_status = "COMPLETED"
        return reward

    def inspect_roach_attack(self):
        """Текстовый снимок состояния EVT_001 для админской вкладки."""
        status_labels = {
            "IDLE": "НЕ ЗАПУЩЕНО",
            "ACTIVE": "АКТИВНО",
            "STOPPED": "ОСТАНОВЛЕНО",
            "COMPLETED": "ЗАВЕРШЕНО",
        }
        status = status_labels.get(self.roach_event_status, self.roach_event_status)
        return (
            f"EVT_001_ROACH_ATTACK | Состояние: {status} | "
            f"На поле: {len(self.roach_entities)} | "
            f"Раздавлено: {self.roach_event_squashed}/{self.roach_event_spawned} | "
            f"Награда: +{self.roach_reward_per_roach} за каждого. "
            "Условие: 3 клика по центральной кнопке и пауза 1 сек. Нашествие: 24 таракана в 3 волны."
        )

    def get_click_phrase(self, phase: str) -> str:
        """Return a random click phrase for the given phase, with special handling."""
        from localization import TRANSLATIONS
        lang = getattr(self, 'current_lang', 'RU')
        if lang not in TRANSLATIONS:
            lang = 'RU'
        phrases_data = TRANSLATIONS[lang].get('click_phrases', {})
        pool = phrases_data.get(phase, [])
        if not pool and lang != 'RU':
            pool = TRANSLATIONS['RU'].get('click_phrases', {}).get(phase, [])
        if not pool:
            return ""
        # Special phrase: 2% chance once per session
        if not getattr(self, 'special_phrase_triggered', False) and random.random() < 0.02:
            self.special_phrase_triggered = True
            return phrases_data.get('special', '')
        # Phase 4 error phrase: 5% chance
        if phase == 'phase_4':
            error_phrase = "Ошибка обработки клика #показывать с шансом в 5%"
            if lang == 'US':
                error_phrase = "Click processing error #show with 5% chance"
            elif lang == 'ES':
                error_phrase = "Error de procesamiento de clic #mostrar con 5% de probabilidad"
            elif lang == 'DE':
                error_phrase = "Klickverarbeitungsfehler #mit 5% Wahrscheinlichkeit anzeigen"
            if random.random() < 0.05:
                return error_phrase
        phrase = random.choice(pool)
        # Alice phrase stub
        if 'Алиса' in phrase or 'Alice' in phrase:
            if 'Подлая еврейская музыка' in phrase or 'Underhanded Jewish Music' in phrase or 'Música judía despreciable' in phrase or 'Untertänige jüdische Musik' in phrase or '卑鄙的犹太音乐' in phrase:
                print("ALICE: Подлая еврейская музыка")  # временная заглушка
        return phrase

    def get_phase(self) -> str:
        tc = self.total_clicks
        for phase, threshold in sorted(PHASE_THRESHOLDS.items(), key=lambda x: x[1], reverse=True):
            if tc >= threshold:
                return phase
        return "phase_0"

    def get_phase_index(self) -> int:
        return list(PHASE_THRESHOLDS.keys()).index(self.get_phase())

    def get_phase_factor(self) -> float:
        phase = self.get_phase()
        if phase == "final": return 1.0
        if phase == "phase_4": return 0.85
        if phase == "phase_3": return 0.65
        if phase == "phase_2": return 0.45
        if phase == "phase_1": return 0.25
        return 0.0

    def get_next_phase(self) -> str:
        phases = list(PHASE_THRESHOLDS.keys())
        current = self.get_phase()
        idx = phases.index(current)
        if idx + 1 < len(phases):
            return phases[idx + 1]
        return current

    def request_screenshot(self, ticks):
        self.screenshot_requested = True
        self.screenshot_ticks = ticks

    def execute_screenshot(self, rgba_data, size):
        import pygame
        gl_surf = pygame.image.fromstring(rgba_data, size, "RGBA")
        gl_surf = pygame.transform.flip(gl_surf, False, True)
        filename = f"shot_click_{self.total_clicks}_{self.screenshot_ticks}.png"
        pygame.image.save(gl_surf, filename)
        self.screenshot_requested = False

    def _sync_to_disk(self):
        SaveManager.save_game_data(self.score, self.current_lang, self.total_clicks, self.wallpaper_index, self.player_name, getattr(self, "system_os_user", ""), self.secret_code)

    def _evt003_state_payload(self):
        state = self.evt003_penalty_ledger.to_dict()
        if self.evt003_pending_notification is not None:
            state["pending_notification"] = dict(self.evt003_pending_notification)
        return state

    def _save_evt003_state(self, *, score=None):
        SaveManager.save_event_state(
            EVT003_EVENT_ID, self._evt003_state_payload(), score=score
        )

    def reserve_evt003_attempt(self, phase: str, occurrence_id: str):
        """Persist once-per-phase reservation before the event is shown."""
        previous = self.evt003_penalty_ledger.to_dict()
        result = self.evt003_penalty_ledger.reserve_attempt(phase, occurrence_id)
        if result.get("reserved"):
            try:
                self._save_evt003_state()
            except Exception:
                self.evt003_penalty_ledger = EVT003PenaltyLedger(previous)
                raise
        return result

    def record_evt003_compliance(self, phase: str, occurrence_id: str):
        """Record a successful PLEASE DON'T TOUCH ANYTHING check exactly once."""
        previous = self.evt003_penalty_ledger.to_dict()
        result = self.evt003_penalty_ledger.record_compliance(phase, occurrence_id)
        if result["recorded"]:
            try:
                self._save_evt003_state()
            except Exception:
                self.evt003_penalty_ledger = EVT003PenaltyLedger(previous)
                raise
        return result

    def resolve_evt003_violation(
        self, phase: str, occurrence_id: str, decision: str, *, pending_notification=None
    ):
        """Atomically persist violation history, penalty balance and pending notice."""
        previous_state = self.evt003_penalty_ledger.to_dict()
        previous_pending = self.evt003_pending_notification
        result = self.evt003_penalty_ledger.resolve_violation(
            phase, occurrence_id, decision, current_balance=int(self.score)
        )
        if result["already_resolved"]:
            return result
        new_score = result["balance_after"]
        if pending_notification is not None:
            self.evt003_pending_notification = dict(pending_notification)
        try:
            self._save_evt003_state(
                score=new_score if result["decision"] == "PUNISHMENT" else None
            )
        except Exception:
            self.evt003_penalty_ledger = EVT003PenaltyLedger(previous_state)
            self.evt003_pending_notification = previous_pending
            raise
        if result["decision"] == "PUNISHMENT":
            self.score = new_score
            self.on_ui_update()
        return result

    def set_evt003_pending_notification(self, payload):
        """Persist the punishment notice until the next gameplay entry is acknowledged."""
        previous = self.evt003_pending_notification
        self.evt003_pending_notification = dict(payload)
        try:
            self._save_evt003_state()
        except Exception:
            self.evt003_pending_notification = previous
            raise

    def consume_evt003_pending_notification(self):
        """Clear a pending notice only after its OK button is acknowledged."""
        if self.evt003_pending_notification is None:
            return None
        previous = self.evt003_pending_notification
        self.evt003_pending_notification = None
        try:
            self._save_evt003_state()
        except Exception:
            self.evt003_pending_notification = previous
            raise
        return dict(previous)

    def is_horror_phase(self):
        return self.get_phase_index() >= 1

    def lucky_click_chance(self):
        if not self.is_horror_phase():
            return 0.05, 5
        phase_idx = self.get_phase_index()
        if phase_idx >= 4:
            return 0.01, -2
        if phase_idx >= 3:
            return 0.02, 1
        if phase_idx >= 1:
            return 0.03, 2
        return 0.05, 5

    def register_click(self):
        if self.timer_active or self.clicks_in_cycle >= 10 or self.minigame_active:
            return "IGNORE"
        if self.system_jammed:
            return "JAMMED"
            
        if self.cooldown_clicks_remaining > 0:
            self.cooldown_clicks_remaining -= 1
            
        current_time = time.monotonic()
        self.click_timestamps.append(current_time)
        if len(self.click_timestamps) > 8:
            self.click_timestamps.pop(0)
            
        if len(self.click_timestamps) == 8 and self.cooldown_clicks_remaining <= 0:
            intervals = [
                self.click_timestamps[i] - self.click_timestamps[i-1]
                for i in range(1, len(self.click_timestamps))
            ]
            mean_interval = sum(intervals) / 7.0
            is_monotonous = all(abs(i - mean_interval) < 0.004 for i in intervals)
            if is_monotonous and mean_interval < 0.5:
                self.system_jammed = True
                self.start_memory_minigame()
                return "TRAP_TRIGGERED"

        if self.clicks_in_cycle == 0 and not self.ghost_mode_active:
            if random.random() < 0.025:
                self.ghost_mode_active = True

        if self.clicks_in_cycle == 9:
            if self.required_final_clicks == 0:
                self.required_final_clicks = random.randint(3, 4)
                self.current_final_clicks = 0
                
            self.current_final_clicks += 1
            if self.current_final_clicks < self.required_final_clicks:
                self.total_clicks += 1
                return "RESISTANCE"
            else:
                self.required_final_clicks = 0
                self.current_final_clicks = 0

        if self.ghost_mode_active and self.clicks_in_cycle < 9:
            increment = random.randint(1, 2)
            self.clicks_in_cycle += increment
            self.score += increment * 2
            self.total_clicks += increment * 2
            if self.clicks_in_cycle >= 9:
                self.clicks_in_cycle = 9
                self.ghost_mode_active = False
            self._sync_to_disk()
            self.on_ui_update()
            return "GHOST_BOOST"
        else:
            self.clicks_in_cycle += 1
            self.total_clicks += 1
            lucky_chance, bonus = self.lucky_click_chance()
            if random.random() < lucky_chance:
                self.score += bonus
                self._sync_to_disk()
                self.on_ui_update(lucky=True)
            if self.clicks_in_cycle == 10:
                self.score += 5
                self._sync_to_disk()
                self.horror_cooldown = False
                self.on_limit_reached()
            else:
                self.on_ui_update()
            self._sync_to_disk()
            return "NORMAL"

    def wash_hands_instantly(self):
        if self.score >= self.upgrade_cost and self.clicks_in_cycle >= 10 and not self.timer_active and not self.system_jammed:
            self.score -= self.upgrade_cost
            if random.random() < 0.15:
                self.start_memory_minigame()
                self._sync_to_disk()
                self.on_ui_update()
                return "TRAP_TRIGGERED"
            self.clicks_in_cycle = 0
            self._sync_to_disk()
            self.horror_cooldown = False
            self.on_clean_finished()
            return True
        return False

    def _apply_phase_scaling(self):
        """Обновляет параметры мини-игры в зависимости от фазы."""
        pf = self.get_phase_factor()
        
        # Таймер чисток: от 30с (фаза 0) до 10с (финал)
        self.timer_duration = max(10000, int(self.base_timer_duration * (1.0 - pf * 0.7)))
        
        # Скорость ухода планеты увеличена на 35%, рост по фазам сохранён.
        self.sprite_speed = (3.5 + pf * 5.5) * 1.35
        
        # Кол-во кликов для появления спрайта: от 3 (фаза 0) до 1 (финал)
        self.sprite_spawn_clicks = max(1, 3 - int(pf * 2.5))

    def start_free_clean(self):
        if self.timer_active:
            return
        self.timer_active = True
        self._apply_phase_scaling()
        self.timer_start_time = int(time.monotonic() * 1000)
        self.last_second_checked = int(self.timer_duration // 1000)
        self.on_ui_update(seconds_left=self.last_second_checked)

    def start_memory_minigame(self):
        """Prepare the existing four-sector memory challenge for a direct test run."""
        self.minigame_active = True
        self.minigame_progress = 0
        self.minigame_clicks = 0
        self.sectors = ["0x0F", "0x3B", "0x7A", "0xED"]
        random.shuffle(self.sectors)
        self.target_sector_index = random.randint(0, len(self.sectors) - 1)
        return True

    def update(self):
        if not self.timer_active:
            return
        current_time = int(time.monotonic() * 1000)
        elapsed = current_time - self.timer_start_time
        
        if elapsed >= self.timer_duration:
            self.timer_active = False
            self.clicks_in_cycle = 0
            self.timer_clicks = 0
            
            if random.random() < 0.15:
                self.sprite_active = False
                self.chase_planets.clear()
                self.chase_planet_active = False
                self.start_memory_minigame()
                self._sync_to_disk()
                self.on_ui_update()
                return "TRAP_TRIGGERED"

            if self.sprite_active:
                self.sprite_active = False
                self.chase_planets.clear()
                # Флаг Chase Planet сохраняется до конца экрана результата.
                self.score = max(0, self.score - 10)
                
                phase_key = self.get_phase()
                
                lang_key = self.current_lang.upper() if self.current_lang.upper() in self.translations else self.current_lang.lower()
                lang_pack = self.translations.get(lang_key, self.translations.get("RU", self.translations.get("ru", {})))
                
                text_data = lang_pack.get("earth_phases", {}).get(phase_key, {"fail": ["ОШИБКА"]})
                self.set_notification(random.choice(text_data["fail"]), duration=5000)
                self.notification_color = (214, 48, 49)

                
                self.fade_screen_active = True
                self.fade_start_time = int(time.monotonic() * 1000)

            self._sync_to_disk()
            self.on_clean_finished()
        else:
            self.seconds_left = int((self.timer_duration - elapsed) // 1000)
            if self.seconds_left != getattr(self, "last_second_checked", 30):
                self.last_second_checked = self.seconds_left
                self.on_ui_update(seconds_left=self.seconds_left)

            
    def reset_session(self, reset_progress=False):
        """Reset transient gameplay state; optionally start a completely fresh run.

        Player identity, selected language and wallpaper preference are retained.
        The optional flag also clears score and cumulative click progression.
        """
        self.reset_roach_attack()
        self.reset_word_shock()
        self.clicks_in_cycle = 0
        self.timer_active = False
        self.timer_start_time = 0
        self.timer_duration = self.base_timer_duration
        self.last_second_checked = 30
        self.seconds_left = 30
        self.timer_clicks = 0
        self.timer_scale = 1.0
        self.horror_cooldown = False

        self.click_timestamps.clear()
        self.system_jammed = False
        self.ghost_mode_active = False
        self.required_final_clicks = 0
        self.current_final_clicks = 0
        self.cooldown_clicks_remaining = 0

        self.minigame_active = False
        self.minigame_progress = 0
        self.minigame_clicks = 0
        self.target_sector_index = 0
        # Match the sector codes used by the actual memory mini-game.
        self.sectors = ["0x0F", "0x3B", "0x7A", "0xED"]

        self.sprite_active = False
        self.sprite_x = 0.0
        self.sprite_y = 0.0
        self.sprite_speed = 3.5
        self.sprite_spawn_clicks = 3

        self.chase_planets.clear()
        self.chase_planet_active = False
        self.chase_planet_rounds_started = 0
        self.chase_planets_target_count = 0
        self.chase_planets_caught_round = 0
        self.chase_planets_caught_total = 0

        self.fade_screen_active = False
        self.fade_start_time = 0
        self.notification_text = ""
        self.notification_color = (255, 255, 255)
        self.notification_timer = 0
        self.notification_duration = 3000

        self.screenshot_requested = False
        self.screenshot_ticks = 0
        self.special_phrase_triggered = False
        self.click_phrase_cooldown = 0.0
        self.current_click_phrase = ""
        self.click_phrase_timer = 0.0
        self.click_phrase_alpha = 0
        self.click_phrase_scale = 0.0
        self.click_phrase_y_offset = 0
        self.click_phrase_pos = None

        # Close transient system windows without discarding the saved identity
        # or the archive's persistent unlock/code data.
        self.code_window_open = False
        self.lore_window_open = False
        self.lore_text_viewer_open = False
        self.lore_image_viewer_open = False
        self.lore_text_viewer_title = ""
        self.lore_text_viewer_content = ""
        self.lore_image_viewer_image = None
        self.input_buffer = [None, None, None]
        self.current_cell_index = 0
        self.current_cell_buffer = ""
        self.failed_attempts_count = 0
        self.auto_close_timer = 0.0
        self.system_response_text = ""

        if reset_progress:
            self.score = 0
            self.total_clicks = 0
            self._sync_to_disk()

    def verify_sector_click(self, clicked_index):
        if not self.minigame_active:
            return "INACTIVE"
        if clicked_index == self.target_sector_index:
            self.minigame_clicks += 1
            if self.minigame_clicks >= 3:
                self.minigame_active = False
                self.system_jammed = False
                self.clicks_in_cycle = 0
                if hasattr(self, "click_timestamps"):
                    self.click_timestamps.clear()
                if hasattr(self, "cooldown_clicks_remaining"):
                    self.cooldown_clicks_remaining = 400
                self._sync_to_disk()
                self.on_clean_finished()
                return "MINIGAME_WIN"
            else:
                current_target = self.target_sector_index
                while self.target_sector_index == current_target:
                    self.target_sector_index = random.randint(0, 3)
                self.on_ui_update()
                return "SECTOR_CLEARED"
        else:
            self.minigame_clicks = 0
            self.target_sector_index = random.randint(0, 3)
            self.on_ui_update()
            return "SECTOR_FAIL"

    def try_unjam_system(self):
        if self.system_jammed:
            self.system_jammed = False
            self.minigame_active = False
            self.click_timestamps.clear()
            self.cooldown_clicks_remaining = 400
            self.on_ui_update()
            return True
        return False

    def cheat_to_paranoia(self):
        self.total_clicks = 2500
        self._sync_to_disk()
        if self.clicks_in_cycle >= 10:
            self.on_limit_reached()

    def set_notification(self, text, duration=None):
        """Устанавливает текст уведомления с таймером жизни (в мс)."""
        self.notification_text = text
        self.notification_duration = duration if duration is not None else 3000
        self.notification_timer = int(time.monotonic() * 1000) + self.notification_duration

    def clear_notification(self):
        """Очищает уведомление."""
        self.notification_text = ""
        self.notification_timer = 0

    def get_center_text(self, lang_code):
        """Возвращает текст для центрального блока:
        - если есть активное уведомление — его
        - иначе — случайную мемную фразу (phrases или horror_phrases в зависимости от фазы)"""
        now = int(time.monotonic() * 1000)
        # Если таймер истёк — очищаем
        if self.notification_timer > 0 and now >= self.notification_timer:
            self.clear_notification()
        
        if self.notification_text:
            return self.notification_text
        
        # Выбираем случайную фразу в зависимости от фазы
        from localization import TRANSLATIONS
        data = TRANSLATIONS.get(lang_code, TRANSLATIONS["RU"])
        phase = self.get_phase()
        
        if phase in ("phase_0", "phase_1"):
            phrases = data.get("phrases", [])
            if phrases:
                return random.choice(phrases)
        else:
            phrases = data.get("horror_phrases", [])
            if phrases:
                return random.choice(phrases)
        
        # Fallback
        return "..."

    def get_personality_subtitle(self, phase):
        """Get a random subtitle from all personalities for the given phase."""
        from localization import TRANSLATIONS
        lang_data = TRANSLATIONS.get(self.current_lang, TRANSLATIONS["RU"])
        personality_data = lang_data.get("personality_subtitles", {})
        all_phrases = []
        for personality, phases in personality_data.items():
            if phase in phases:
                all_phrases.extend(phases[phase])
        if all_phrases:
            return random.choice(all_phrases)
        return None

    def get_subtitle_phase(self):
        return self.get_phase()

    def get_phrase_pool_and_glitch(self):
        phase = self.get_phase()
        if phase == "final":
            return [], 0.0, True
        if phase == "phase_4":
            return [], 1.0, False
        if phase == "phase_3":
            return range(12), 0.15, False
        if phase == "phase_2":
            return range(8), 0.06, False
        if phase == "phase_1":
            return range(4), 0.02, False
        return range(0), 0.0, False

    def select_phrase(self, lang_code, from_horror=False):
        from localization import TRANSLATIONS
        data = TRANSLATIONS.get(lang_code, TRANSLATIONS["RU"])
        
        if from_horror and self.is_horror_phase():
            subtitle_phase = self.get_subtitle_phase()
            subtitles = data.get("subtitles", {}).get(subtitle_phase, [])
            if subtitles:
                return random.choice(subtitles)
        
        if from_horror:
            phrases = data["horror_phrases"]
        else:
            phrases = data["phrases"]
        return random.choice(phrases)

    def is_final_phase(self):
        return self.get_phase() == "final"

    def get_glitch_intensity(self):
        phase_idx = self.get_phase_index()
        if phase_idx >= 5:
            return 0.0
        if phase_idx >= 4:
            return 0.20
        if phase_idx >= 3:
            return 0.06
        if phase_idx >= 2:
            return 0.02
        if phase_idx >= 1:
            return 0.005
        return 0.0

    def set_wallpaper(self, index):
        self.wallpaper_index = index % 4
        self._sync_to_disk()

    def verify_player_name(self, entered_name):
        """Проверяет имя игрока и определяет, настоящее ли оно."""
        if not entered_name or not entered_name.strip():
            return False
        
        self.player_name = entered_name.strip()
        
        # Простая проверка: если имя совпадает с системным - это fake
        # В реальности здесь может быть более сложная логика
        if self.player_name.upper() == self.system_name.upper():
            self.name_verified = False
        else:
            # Имя не совпадает с системным - считаем его настоящим
            self.name_verified = True
        
        return self.name_verified

    def get_personalized_horror_phrase(self, lang_code, phase):
        """Возвращает персонализированную фразу ужаса с учётом имени."""
        from localization import TRANSLATIONS
        data = TRANSLATIONS.get(lang_code, TRANSLATIONS["RU"])
        
        if not self.player_name:
            # Если имя не введено, возвращаем обычную фразу
            return None
        
        # Выбираем фразу в зависимости от фазы и верификации
        if phase == 2:
            if self.name_verified:
                key = "name_verified_phase2"
            else:
                key = "name_fake_phase2"
        elif phase == 3:
            key = "name_scan_phase3"
        elif phase >= 4:
            if self.name_verified:
                key = "name_final_true"
            else:
                key = "name_final_fake"
        else:
            return None
        
        template = data.get(key, "")
        if not template:
            return None
        
        # Подставляем имена в шаблон
        if "{system_name}" in template:
            template = template.replace("{system_name}", self.system_name)
        if "{player_name}" in template:
            template = template.replace("{player_name}", self.player_name)
        
        return template