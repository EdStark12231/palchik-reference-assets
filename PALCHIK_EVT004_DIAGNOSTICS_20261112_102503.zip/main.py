import sys
import pygame
import os
import random
import moderngl
import array
import time
import logging
import subprocess
from pathlib import Path
from localization import TRANSLATIONS
from events.catalog import load_default_catalog
from events.manager import EventManager
from events.effects import EffectRegistry
from events.legacy_lifecycle import LegacyEventLifecycle
from events.evt003_runtime import EVT003Runtime
from events.evt003_presentation import EVT003Presentation
from events.diagnostics import configure_app_logging, install_uncaught_exception_hook, log_exception, get_recent_log_entries
from typewriter import CharacterTypewriter
from events.secret_access import (
    EVENT_COLLECTION_ITEMS, SECRET_ACCESS_CODE, SECRET_ACCESS_CODE_LENGTH,
    is_valid_numeric_code, normalize_event_collection_progress,
    mark_event_found, mark_event_completed, SecretPromptSession,
    choose_event_collection_icon_rect,
)
from events.adventure_road_runtime import AdventureRoadRuntime
from events.adventure_road_presentation import AdventureRoadPresentation


class Profiler:
    """Система сбора метрик производительности."""
    def __init__(self):
        self.recording = False
        self.start_time = 0
        self.duration = 10.0  # секунд
        self.fps_values = []
        self.frame_times = []
        self.cpu_values = []
        self.ram_values = []
        self.scenario = "unknown"
    
    def start(self, duration=10.0, scenario="unknown"):
        self.recording = True
        self.start_time = time.time()
        self.duration = duration
        self.scenario = scenario
        self.fps_values = []
        self.frame_times = []
        self.cpu_values = []
        self.ram_values = []
    
    def tick(self, fps, dt):
        if not self.recording:
            return
        elapsed = time.time() - self.start_time
        self.fps_values.append(fps)
        self.frame_times.append(dt)
        if PSUTIL_AVAILABLE:
            self.cpu_values.append(psutil.cpu_percent(interval=0.0))
            mem = psutil.virtual_memory()
            self.ram_values.append(mem.percent)
        if elapsed >= self.duration:
            self.stop()
    
    def stop(self):
        self.recording = False
        self._print_report()
        self._save_report()
    
    def _print_report(self):
        if not self.fps_values:
            return
        avg_fps = sum(self.fps_values) / len(self.fps_values)
        min_fps = min(self.fps_values)
        max_fps = max(self.fps_values)
        avg_dt = sum(self.frame_times) / len(self.frame_times) * 1000
        min_dt = min(self.frame_times) * 1000
        max_dt = max(self.frame_times) * 1000
        
        print("\n" + "="*50)
        print("  ОТЧЁТ ПРОФИЛИРОВАНИЯ")
        print("="*50)
        print(f"  Сценарий: {self.scenario}")
        print(f"  Длительность: {self.duration:.1f} сек")
        print(f"  Кадров записано: {len(self.fps_values)}")
        print(f"  FPS: средний {avg_fps:.1f}, мин {min_fps:.0f}, макс {max_fps:.0f}")
        print(f"  Время кадра: среднее {avg_dt:.2f} мс, мин {min_dt:.2f}, макс {max_dt:.2f}")
        if self.cpu_values:
            avg_cpu = sum(self.cpu_values) / len(self.cpu_values)
            print(f"  Загрузка CPU: {avg_cpu:.1f}%")
        if self.ram_values:
            avg_ram = sum(self.ram_values) / len(self.ram_values)
            print(f"  Использование RAM: {avg_ram:.1f}%")
        print("="*50 + "\n")
    
    def _save_report(self):
        if not self.fps_values:
            return
        import os
        os.makedirs("profiles", exist_ok=True)
        timestamp = time.strftime("%Y%m%d_%H%M%S")
        filename = f"profiles/profile_{timestamp}_{self.scenario}.txt"
        
        avg_fps = sum(self.fps_values) / len(self.fps_values)
        min_fps = min(self.fps_values)
        max_fps = max(self.fps_values)
        avg_dt = sum(self.frame_times) / len(self.frame_times) * 1000
        min_dt = min(self.frame_times) * 1000
        max_dt = max(self.frame_times) * 1000
        
        with open(filename, "w", encoding="utf-8") as f:
            f.write("="*50 + "\n")
            f.write("  ОТЧЁТ ПРОФИЛИРОВАНИЯ\n")
            f.write("="*50 + "\n")
            f.write(f"  Сценарий: {self.scenario}\n")
            f.write(f"  Длительность: {self.duration:.1f} сек\n")
            f.write(f"  Кадров записано: {len(self.fps_values)}\n")
            f.write(f"  FPS: средний {avg_fps:.1f}, мин {min_fps:.0f}, макс {max_fps:.0f}\n")
            f.write(f"  Время кадра: среднее {avg_dt:.2f} мс, мин {min_dt:.2f}, макс {max_dt:.2f}\n")
            if self.cpu_values:
                avg_cpu = sum(self.cpu_values) / len(self.cpu_values)
                f.write(f"  Загрузка CPU: {avg_cpu:.1f}%\n")
            if self.ram_values:
                avg_ram = sum(self.ram_values) / len(self.ram_values)
                f.write(f"  Использование RAM: {avg_ram:.1f}%\n")
            f.write("="*50 + "\n")

try:
    import psutil
    PSUTIL_AVAILABLE = True
except ImportError:
    PSUTIL_AVAILABLE = False
from save_manager import SaveManager
from audio_system import AudioController
from settings_scene import SettingsController
from cursor_effects import CustomCursorManager
from game_scene import GameControllerPygame
from game_logic import GameLogic, PHASE_NAMES
from name_input_scene import NameInputScene
from text_cache import text_cache
import math

try:
    import cv2
    CV2_AVAILABLE = True
except ImportError:
    CV2_AVAILABLE = False

pygame.init()
pygame.mixer.init()
print("[DBG] pygame.init OK")

COLOR_BLACK = (0, 0, 0)
COLOR_WHITE = (255, 255, 255)
COLOR_GREY = (180, 180, 180)
COLOR_DARK_GREY = (80, 80, 80)

# Оптимизированный шейдер: уменьшено количество итераций noise с 8 до 5
FRAGMENT_SHADER = """
#version 330

in vec2 v_text;
uniform sampler2D u_texture;
uniform vec2 u_resolution;
uniform float u_time;
uniform float u_effects_enabled;
uniform float u_channel_switch;
uniform float u_channel_time;
out vec4 f_color;

const float PI = 3.14159265;

vec3 tex2D(sampler2D tex, vec2 p)
{
    vec3 col = texture(tex, p).rgb;
    if (0.5 < abs(p.x - 0.5))
        col = vec3(0.1);
    return col;
}

float hash(vec2 v)
{
    return fract(sin(dot(v, vec2(89.44, 19.36))) * 22189.22);
}

float iHash(vec2 v, vec2 r)
{
    vec2 v_r = v * r;
    vec2 fl = floor(v_r);
    vec2 fr = fract(v_r);
    float h00 = hash((fl + vec2(0.0, 0.0)) / r);
    float h10 = hash((fl + vec2(1.0, 0.0)) / r);
    float h01 = hash((fl + vec2(0.0, 1.0)) / r);
    float h11 = hash((fl + vec2(1.0, 1.0)) / r);
    vec2 ip = smoothstep(vec2(0.0), vec2(1.0), fr);
    return (h00 * (1.0 - ip.x) + h10 * ip.x) * (1.0 - ip.y) + (h01 * (1.0 - ip.x) + h11 * ip.x) * ip.y;
}

float noise(vec2 v)
{
    float sum = 0.0;
    // Уменьшено с 9 до 5 итераций для производительности
    for (int i = 1; i < 6; i++)
    {
        float fi = float(i);
        sum += iHash(v + vec2(fi), vec2(2.0 * pow(2.0, fi))) / pow(2.0, fi);
    }
    return sum;
}

void main()
{
    vec2 uv = v_text;
    if (u_channel_switch > 0.5) {
        float progress = clamp(u_channel_time / 1.2, 0.0, 1.0);
        float frame = floor(u_channel_time * 30.0);
        vec2 pixel = floor(uv * u_resolution);
        float row = floor(pixel.y / 2.0);
        float row_noise = hash(vec2(row, frame + 17.0));
        vec3 transition_color;

        // Brief colored analog interference: dense RGB noise and rolling bands.
        if (progress < 0.27) {
            float jitter = (hash(vec2(row, frame + 3.0)) - 0.5) * 0.055;
            vec2 noisy_uv = clamp(uv + vec2(jitter, 0.0), vec2(0.0), vec2(1.0));
            vec2 noisy_pixel = floor(noisy_uv * u_resolution);
            float n_r = hash(noisy_pixel + vec2(frame * 13.0, 2.0));
            float n_g = hash(noisy_pixel + vec2(5.0, frame * 17.0));
            float n_b = hash(noisy_pixel + vec2(frame * 23.0, 11.0));
            vec3 rgb_noise = vec3(n_r, n_g, n_b);
            float wave = noisy_uv.y * 78.0 + noisy_uv.x * 18.0 + frame * 0.34;
            vec3 color_bands = vec3(
                0.5 + 0.5 * sin(wave),
                0.5 + 0.5 * sin(wave + 2.094),
                0.5 + 0.5 * sin(wave + 4.188)
            );
            float roll = 0.5 + 0.5 * sin(noisy_uv.y * 31.0 - frame * 0.52);
            transition_color = mix(rgb_noise, color_bands, 0.58);
            transition_color *= mix(0.34, 1.18, roll);
        }
        // Hard white flash with fragmented horizontal signal tearing on the right.
        else if (progress < 0.53) {
            float tear_band = step(0.63, row_noise);
            float tear_start = 0.34 + 0.54 * hash(vec2(row, frame + 29.0));
            float fragment = step(tear_start, uv.x) * tear_band;
            float dash = step(0.52, hash(vec2(floor(pixel.x / 4.0), row + frame * 3.0)));
            float dark_shard = fragment * dash;
            float red_shard = dark_shard * step(0.91, hash(vec2(row, frame + 7.0)));
            float cyan_shard = dark_shard * step(0.94, hash(vec2(row, frame + 19.0)));
            transition_color = vec3(0.985);
            transition_color = mix(transition_color, vec3(0.012), dark_shard * 0.96);
            transition_color = mix(transition_color, vec3(0.88, 0.025, 0.07), red_shard * 0.92);
            transition_color = mix(transition_color, vec3(0.02, 0.62, 0.88), cyan_shard * 0.9);
            float white_speck = step(0.996, hash(pixel + vec2(frame * 41.0, frame * 7.0)));
            transition_color = mix(transition_color, vec3(1.0), white_speck);
        }
        // Dense black-and-white television snow with occasional horizontal dropouts.
        else {
            float grain = hash(pixel + vec2(frame * 37.0, frame * 19.0));
            float fine_grain = hash(floor(pixel * 0.5) + vec2(frame * 11.0, frame * 7.0));
            float static_value = mix(step(0.5, grain), step(0.5, fine_grain), 0.16);
            float dropout = step(0.986, hash(vec2(row, frame + 5.0)));
            float dark_band = step(0.992, hash(vec2(row * 0.5, frame + 13.0)));
            static_value *= 1.0 - dropout * 0.78;
            static_value = mix(static_value, 0.025, dark_band * 0.9);
            transition_color = vec3(static_value);
        }

        // Isolated black cuts separate the signal fragments, not a long fade.
        if (frame == 9.0 || frame == 19.0 || frame == 28.0) {
            transition_color = vec3(0.0);
        }

        vec3 source_color = texture(u_texture, uv).rgb;
        float noise_mix = smoothstep(0.0, 0.018, progress);
        f_color = vec4(mix(source_color, transition_color, noise_mix), 1.0);
        return;
    }
    if (u_effects_enabled < 0.5) {
        f_color = texture(u_texture, uv);
        return;
    }
    vec2 uvn = uv;
    float time = u_time;
    vec2 resolution = u_resolution;

    uvn.x += (noise(vec2(uvn.y, time)) - 0.5) * 0.005;
    uvn.x += (noise(vec2(uvn.y * 100.0, time * 10.0)) - 0.5) * 0.006;

    float tcPhase = clamp((sin(uvn.y * 8.0 - time * PI * 1.2) - 0.92) * noise(vec2(time)), 0.0, 0.01) * 10.0;
    float tcNoise = max(noise(vec2(uvn.y * 100.0, time * 10.0)) - 0.5, 0.0);
    uvn.x = uvn.x - tcNoise * tcPhase;

    float snPhase = smoothstep(0.03, 0.0, uvn.y);
    uvn.y += snPhase * 0.3;
    uvn.x += snPhase * ((noise(vec2(uv.y * 100.0, time * 10.0)) - 0.5) * 0.2);

    vec3 col = tex2D(u_texture, uvn);
    col *= 1.0 - tcPhase;
    col = mix(col, col.yzx, snPhase);

    // Уменьшено количество итераций хроматической аберрации с 7 до 4
    for (float x = -3.0; x < 2.0; x += 1.0)
    {
        col.rgb += vec3(
            tex2D(u_texture, uvn + vec2(x - 0.0, 0.0) * 4.5e-3).r,
            tex2D(u_texture, uvn + vec2(x - 2.0, 0.0) * 4.5e-3).g,
            tex2D(u_texture, uvn + vec2(x - 4.0, 0.0) * 4.5e-3).b
        ) * 0.1;
    }
    col *= 0.6;

    col *= 1.0 + clamp(noise(vec2(0.0, uv.y + time * 0.2)) * 0.6 - 0.25, 0.0, 0.1);

    float scanline = sin(uv.y * resolution.y * 1.5) * 0.03;
    col -= vec3(scanline);

    f_color = vec4(col, 1.0);
}
"""


class Application:
    def __init__(self):
        info = pygame.display.Info()
        self.screen = pygame.display.set_mode(
            (info.current_w, info.current_h),
            pygame.FULLSCREEN | pygame.DOUBLEBUF | pygame.OPENGL
        )
        print("[DBG] window created", self.screen.get_size())
        pygame.display.set_caption("PALCHIK")
        self.clock = pygame.time.Clock()
        self.running = True
        self.app_logger, self.log_file_path = configure_app_logging(Path(__file__).resolve().parent)
        install_uncaught_exception_hook(self.app_logger)
        # Event catalog is the single metadata source; legacy controllers remain active
        # until each event is migrated to EventManager in a separate verified step.
        self.event_catalog = load_default_catalog()
        self.event_manager = EventManager(self.event_catalog)
        self.event_effects = EffectRegistry()
        self.event_lifecycle = LegacyEventLifecycle(self.event_manager)

        saved_data = SaveManager.load_game_data()
        self.current_lang = saved_data["lang"]
        self.player_name = saved_data.get("player_name", "")
        collection_state = SaveManager.load_event_collection_state()
        self.event_collection_unlocked = collection_state["unlocked"]
        self.event_collection_progress = normalize_event_collection_progress(collection_state["progress"])
        self.event_collection_open = False
        self.event_collection_opened_at = 0.0
        self.event_collection_closing = False
        self.event_collection_closing_started_at = 0.0
        self.event_collection_icon_rect = None
        self.event_collection_window_rect = None
        self.event_collection_close_rect = None
        self.secret_prompt_session = SecretPromptSession()
        self.secret_input_open = False
        self.secret_input_closing = False
        self.secret_input_closing_started_at = 0.0
        self.secret_input_value = ""
        self.secret_input_started_at = 0.0
        self.secret_input_last_digit_at = 0.0
        self.secret_input_error_until = 0.0
        self.secret_input_rect = None

        self.audio_box = AudioController()
        self._roach_scuttle_playing = False
        self.settings_box = SettingsController()
        self.settings_box.audio_system = self.audio_box
        self.settings_box.current_lang = self.current_lang

        self.menu_cursor = CustomCursorManager()
        self.settings_box.menu_cursor = self.menu_cursor

        w, h = self.screen.get_size()
        self.game_view = GameControllerPygame(w, h)

        self.game_logic = GameLogic(
            ui_update_callback=self._on_game_ui_update,
            limit_reached_callback=self._on_limit_reached,
            clean_finished_callback=self._on_clean_finished,
            translations=TRANSLATIONS
        )
        # EVT_003 is registered and controlled by the existing PALCHIK EventManager.
        self.evt003_runtime = EVT003Runtime(self.event_manager, self.game_logic)
        self.evt003_presentation = EVT003Presentation(self.game_view)
        self.evt003_state = None
        self.evt003_instance_id = None
        self.evt003_started_at = 0.0
        self.evt003_gameover_started_at = 0.0
        self.evt003_typewriter_count = 0
        self.evt003_typewriter_interval = self.evt003_runtime.typewriter_interval

        # EVT_004 Adventure Road runtime and presentation
        self.evt004_runtime = None
        self.evt004_presentation = None
        self.evt004_instance_id = None
        self.evt004_started_at = 0.0
        self.evt004_audio_channel = None
        self.evt004_audio_config = dict((self.event_catalog.configuration("EVT_004_ADVENTURE_ROAD") or {}).get("audio", {}))
        self._evt004_wing_loop_active = False

        self.evt003_typewriter = CharacterTypewriter(self.evt003_typewriter_interval)
        self.evt003_is_sandbox = False
        self.evt003_dialog_payload = None
        self.evt003_ok_rect = None
        self.evt003_scheduled_phase = None
        self.evt003_next_check_at = 0.0
        self._evt003_schedule_phase(self.game_logic.get_phase())
        # Load saved player name into game logic
        if self.player_name:
            self.game_logic.player_name = self.player_name
            self.game_logic.name_verified = True

        self.hint_alpha = 0.0
        self.hint_visible = False
        self.last_blink_time = pygame.time.get_ticks()
        self.blink_interval = 600
        self.start_delay = 5000
        self.menu_start_time = pygame.time.get_ticks()

        self.game_seconds_left = 30
        self.game_current_phrase = "О КАК..."
        self.game_blink_visible = True
        self.game_last_blink_time = pygame.time.get_ticks()
        self.typed_phrase = ""
        self.final_phase_triggered = False
        self.fake_crash_start = 0
        self.crash_stage = 0

        self.notification_text = ""
        self.notification_timer = 0
        self.menu_jitter_offset = 0

        self.easter_egg_phrase = ""
        self.easter_egg_timer = 0

        self.effects_enabled = True
        self.channel_switch_active = False
        self.channel_switch_start_ms = 0
        self.channel_switch_duration_ms = 1200
        self.debug_mode = False
        self.profiler = Profiler()

        # Name entry system state
        self.name_entry_active = False
        self.name_input_scene = None

        # Admin panel and new-game instruction sequence.
        self.admin_panel_open = False
        self.admin_panel_rect = None
        self.admin_button_rects = {}
        self.admin_tab_rects = {}
        self.admin_panel_tab = "overview"
        self.intro_slides_active = False
        self.intro_slide_index = 0
        self.intro_slide_title = ""
        self.intro_slide_full_text = ""
        self.intro_slide_display_text = ""
        self.intro_slide_char_index = 0
        self.intro_slide_typewriter_accum = 0.0
        self.intro_slide_button_rect = None

        # Subtitle system state (упрощено: idle -> typewriter -> waiting_click)
        self.subtitle_full_text = ""
        self.subtitle_displayed_text = ""
        self.subtitle_alpha = 0
        self.subtitle_state = "idle"  # idle | typewriter | waiting_click
        self.subtitle_state_timer = 0.0
        self.subtitle_typewriter_speed = 0.05  # seconds per character
        self.subtitle_typewriter_timer = 0.0
        self.subtitle_next_idle_timer = 0.0  # timer before next subtitle appears
        
        # Code initialization sequence state
        self.code_init_active = False
        self.code_init_step = 0
        self.code_init_text = ""
        self.code_init_display = ""
        self.code_init_word_index = 0
        self.code_init_timer = 0.0
        self.code_init_phase_timer = 0.0
        self.code_init_word_count = 0
        self.code_init_current_word = 0

        self._load_fonts()
        self._setup_menu_hitboxes()

        self.video = None
        base_dir = os.path.dirname(os.path.abspath(__file__))
        video_path = os.path.join(base_dir, "assets", "video", "vhs_intro.mp4")
        if CV2_AVAILABLE and os.path.exists(video_path):
            try:
                self.video = cv2.VideoCapture(video_path)
                if self.video.isOpened():
                    self.current_screen = "intro"
                else:
                    self.current_screen = "menu"
                    self.audio_box.play_menu_music()
            except Exception:
                self.current_screen = "menu"
                self.audio_box.play_menu_music()
        else:
            self.current_screen = "menu"
            self.audio_box.play_menu_music()

        self.ctx = moderngl.create_context()
        self.program = self.ctx.program(
            vertex_shader='''
                #version 330
                in vec2 in_vert;
                in vec2 in_uv;
                out vec2 v_text;
                void main() {
                    gl_Position = vec4(in_vert, 0.0, 1.0);
                    v_text = vec2(in_uv.x, 1.0 - in_uv.y);
                }
            ''',
            fragment_shader=FRAGMENT_SHADER
        )
        vertices = array.array('f', [
            -1.0,  1.0, 0.0, 0.0,
            -1.0, -1.0, 0.0, 1.0,
             1.0,  1.0, 1.0, 0.0,
             1.0, -1.0, 1.0, 1.0,
        ])
        self.quad_buffer = self.ctx.buffer(vertices.tobytes())
        self.vao = self.ctx.vertex_array(self.program, [(self.quad_buffer, '2f 2f', 'in_vert', 'in_uv')])
        self.screen_texture = self.ctx.texture(self.screen.get_size(), 4)
        self.screen_texture.filter = (moderngl.LINEAR, moderngl.LINEAR) 

    def _load_fonts(self):
        font_path = "assets/shrift/ContraPhobotech-Regular.otf"
        try:
            self.font_title = pygame.font.Font(font_path, 60)
            self.font_hint = pygame.font.Font(font_path, 16)
            self.font_txt_btn = pygame.font.Font(font_path, 14)
        except:
            self.font_title = pygame.font.SysFont("Courier New", 64, bold=True)
            self.font_hint = pygame.font.SysFont("Courier New", 15, bold=True)
            self.font_txt_btn = pygame.font.SysFont("Courier New", 14, bold=True)
        self.font_icon_btn = pygame.font.SysFont("Segoe UI Symbol", 22, bold=True)
        self.font_crash = pygame.font.SysFont("Consolas", 18, bold=True)
        
        # Subtitle font - system Arial Bold (guaranteed Cyrillic support)
        self.font_subtitle = pygame.font.SysFont("Arial", 24, bold=True)

    def apply_glitch(self, text, intensity):
        if not self.effects_enabled:
            return text
        if intensity <= 0 or not text:
            return text
        result = list(text)
        for i in range(len(result)):
            if result[i].isalpha() and random.random() < intensity:
                choice = random.randint(0, 2)
                if choice == 0:
                    garbage = random.choice("@#$%&*§?")
                    result[i] = garbage
                elif choice == 1 and i < len(result)-1 and result[i+1].isalpha():
                    result[i], result[i+1] = result[i+1], result[i]
        return "".join(result)

    def _get_phase_name(self, clicks):
        phase = self.game_logic.get_phase()
        mapping = {
            "phase_0": "PHASE 0",
            "phase_1": "PHASE 1",
            "phase_2": "PHASE 2",
            "phase_3": "PHASE 3",
            "phase_4": "PHASE 4 (DECAY)",
            "final": "FINAL PHASE"
        }
        return mapping.get(phase, "PHASE 0")

    def _show_notification(self, text, duration=2000):
        self.notification_text = text
        self.notification_timer = pygame.time.get_ticks() + duration

    def _set_meme_phrase(self):
        lang_code = self.current_lang if self.current_lang in TRANSLATIONS else "RU"
        self.game_current_phrase = random.choice(TRANSLATIONS[lang_code]["phrases"])
        self.game_view.set_phrase(self.game_current_phrase, self.game_logic.get_glitch_intensity(), self.game_logic.total_clicks, is_horror=False)

    def _show_easter_egg(self):
        lang_code = self.current_lang if self.current_lang in TRANSLATIONS else "RU"
        is_horror = self.game_logic.is_horror_phase()
        if is_horror:
            pool = TRANSLATIONS[lang_code]["easter_eggs"]["horror_score_click"] + TRANSLATIONS[lang_code]["easter_eggs"]["horror_clicks_click"]
        else:
            pool = TRANSLATIONS[lang_code]["easter_eggs"]["score_click"] + TRANSLATIONS[lang_code]["easter_eggs"]["clicks_click"]
        self.easter_egg_phrase = random.choice(pool)
        self.easter_egg_timer = pygame.time.get_ticks() + 2000

    def _setup_menu_hitboxes(self):
        w, h = self.screen.get_size()
        self.menu_cursor.hitboxes.clear()
        self.menu_cursor.register_fake_button("start", 0, 0, w, int(h * 0.8), self._start_game)
        bottom_margin = 24
        btn_h = 48
        y_pos = h - bottom_margin - btn_h
        self.menu_cursor.register_fake_button("lang", 24, y_pos, 48, btn_h, self.settings_box.open_language_dialog)
        self.menu_cursor.register_fake_button("theme", 88, y_pos, 48, btn_h, self._toggle_cursor_theme)
        self.menu_cursor.register_fake_button("settings", w - 144, y_pos, 48, btn_h, self.settings_box.open_settings_dialog)
        self.menu_cursor.register_fake_button("exit", w - 80, y_pos, 56, btn_h, self._exit_game)

    def _toggle_cursor_theme(self):
        self.audio_box.play_click()
        new_theme = "light" if self.menu_cursor.current_theme == "dark" else "dark"
        self.menu_cursor.change_theme(new_theme)

    def _start_game(self):
        """Begin a new run through the name/instructions flow."""
        if self.settings_box.is_open:
            return
        self.audio_box.play_click()

        if not self.player_name or not self.player_name.strip():
            w, h = self.screen.get_size()
            self.name_input_scene = NameInputScene((w, h), self.current_lang, self.menu_cursor)
            self.name_entry_active = True
            self.intro_slides_active = False
            self.current_screen = "game"
            self.crash_stage = 0
            return

        # Existing profiles resume their saved progress. A first-time name entry
        # or the admin panel's explicit New Game action goes through the slides.
        self._begin_game_session(reset_progress=False)

    def _begin_game_session(self, reset_progress=False):
        """Start gameplay; clear saved progress only for an explicit new game."""
        self.intro_slides_active = False
        self.name_entry_active = False
        self.name_input_scene = None
        self.admin_panel_open = False
        self.event_collection_open = False
        self.event_collection_closing = False
        self.event_collection_window_rect = None
        self.event_collection_close_rect = None
        self.secret_input_open = False
        self.secret_input_closing = False
        self.secret_input_value = ""
        self.secret_input_error_until = 0.0
        self.secret_prompt_session.begin_session()
        self.channel_switch_active = False
        if self.settings_box.is_open:
            self.settings_box.close_dialog()
        self.audio_box.stop_music()
        self.current_screen = "game"
        self.crash_stage = 0
        self.fake_crash_start = 0
        self.game_view.recalculate_layout()
        self.game_view.target_scale = 1.0
        self.game_view.label_scale = 1.0
        self.game_view.target_animation_time = 0
        self.game_view.label_animation_time = 0
        self.game_view.lore_window_offset_x = 0
        self.game_view.lore_window_offset_y = 0
        self.game_view.lore_current_path = []
        self.game_view.lore_selection_index = 0
        self.game_view.lore_scroll_y = 0
        self.game_view.lore_window_dragging = False
        self.game_view.lore_scroll_dragging = False
        self.game_view.code_window_dirty = True
        self._stop_roach_audio()
        if self.game_logic.roach_attack_active or self.event_lifecycle.is_tracked("EVT_001_ROACH_ATTACK"):
            self._cancel_managed_roach_attack(reason="NEW_SESSION")
        if self.game_logic.word_shock_active or self.event_lifecycle.is_tracked("EVT_002_WORD_SHOCK"):
            self._cancel_managed_word_shock(reset=True, reason="NEW_SESSION")
        self.game_logic.reset_session(reset_progress=reset_progress)
        self.game_seconds_left = 30
        self._last_notification_update = 0
        self.notification_text = ""
        self.notification_timer = 0
        self.game_current_phrase = "О КАК..."
        self.game_blink_visible = True
        self.final_phase_triggered = False
        self.typed_phrase = ""
        self.easter_egg_phrase = ""
        self.easter_egg_timer = 0
        self.subtitle_state = "idle"
        self.subtitle_full_text = ""
        self.subtitle_displayed_text = ""
        self.subtitle_alpha = 0
        self.subtitle_state_timer = 0.0
        self.subtitle_typewriter_timer = 0.0
        self.subtitle_next_idle_timer = 0.0
        self.code_init_active = False
        self._set_meme_phrase()
        self.audio_box.play_game_music()
        self._evt003_begin_gameplay_entry()

    def _get_intro_slides(self):
        # Slide copy is kept here so the initial onboarding can be revised without
        # changing localization data or any gameplay systems.
        return [
            ("ВНИМАНИЕ!", "Это бета-билд игры PALCHIK.exe."),
            ("ПЕРЕД НАЧАЛОМ", "Для комфортного прохождения игры вам следует строго придерживаться трёх простых правил:"),
            ("ПРАВИЛО ПЕРВОЕ", "Всегда следуйте правилам игровых событий. Если вы не будете следовать заданным игровым правилам — вас ждут последствия."),
            ("ПРАВИЛО ВТОРОЕ", "Не пытайтесь самостоятельно исправлять ошибки игры. При возникновении неполадок дождитесь автоматического восстановления PALCHIK.exe."),
            ("ПРАВИЛО ТРЕТЬЕ", "Не вмешивайтесь в работу игры без необходимости. Взаимодействуйте только с объектами, предназначенными для текущего игрового процесса."),
            ("БЛАГОДАРИМ ЗА СОТРУДНИЧЕСТВО", "Теперь вы готовы к прохождению PALCHIK.exe.\n\nЖелаем приятной игры!"),
        ]

    def _load_intro_slide(self):
        title, body = self._get_intro_slides()[self.intro_slide_index]
        self.intro_slide_title = title
        self.intro_slide_full_text = title + "\n\n" + body
        self.intro_slide_display_text = ""
        self.intro_slide_char_index = 0
        self.intro_slide_typewriter_accum = 0.0
        self.intro_slide_button_rect = None

    def _begin_intro_slides(self):
        self.audio_box.stop_music()
        self.current_screen = "game"
        self.crash_stage = 0
        self.channel_switch_active = False
        self.name_entry_active = False
        self.name_input_scene = None
        self.admin_panel_open = False
        self.intro_slides_active = True
        self.intro_slide_index = 0
        self._load_intro_slide()

    def _update_intro_slides(self):
        if not self.intro_slides_active or self.admin_panel_open:
            return
        dt = max(0.0, min(self.clock.get_time() / 1000.0, 0.15))
        self.intro_slide_typewriter_accum += dt
        interval = 0.028
        count = int(self.intro_slide_typewriter_accum / interval)
        if count <= 0:
            return
        self.intro_slide_typewriter_accum -= count * interval
        self.intro_slide_char_index = min(
            len(self.intro_slide_full_text), self.intro_slide_char_index + count
        )
        self.intro_slide_display_text = self.intro_slide_full_text[:self.intro_slide_char_index]

    def _advance_intro_slide(self):
        if not self.intro_slides_active:
            return
        if self.intro_slide_char_index < len(self.intro_slide_full_text):
            return
        if self.intro_slide_index + 1 >= len(self._get_intro_slides()):
            self._begin_game_session(reset_progress=True)
            return
        self.intro_slide_index += 1
        self._load_intro_slide()

    def _wrap_intro_text(self, text, font, max_width):
        result = []
        for paragraph in text.split("\n"):
            if not paragraph:
                result.append("")
                continue
            words = paragraph.split()
            line = ""
            for word in words:
                candidate = word if not line else line + " " + word
                if font.size(candidate)[0] <= max_width or not line:
                    line = candidate
                else:
                    result.append(line)
                    line = word
            if line:
                result.append(line)
        return result

    def _draw_intro_slides_to_texture(self):
        w, h = self.screen_texture.size
        surf = pygame.Surface((w, h))
        surf.fill((12, 15, 20))

        # Restrained late-90s software dialog, not a horror presentation.
        win_w = min(780, max(420, w - 64))
        win_h = min(500, max(340, h - 64))
        win_w = min(win_w, w - 24)
        win_h = min(win_h, h - 24)
        win = pygame.Rect((w - win_w) // 2, (h - win_h) // 2, win_w, win_h)
        pygame.draw.rect(surf, (0, 0, 0), win.move(6, 7))
        pygame.draw.rect(surf, (192, 192, 192), win)
        pygame.draw.rect(surf, (255, 255, 255), win, 2)
        pygame.draw.rect(surf, (128, 128, 128), win, 1)
        title_bar = pygame.Rect(win.x + 3, win.y + 3, win.width - 6, 30)
        pygame.draw.rect(surf, (0, 0, 128), title_bar)
        title_font = pygame.font.SysFont("Arial", 18, bold=True)
        title = title_font.render("PALCHIK.exe - Information", True, (255, 255, 255))
        surf.blit(title, (title_bar.x + 10, title_bar.y + 5))

        content = pygame.Rect(win.x + 18, win.y + 48, win.width - 36, win.height - 112)
        pygame.draw.rect(surf, (255, 255, 255), content)
        pygame.draw.rect(surf, (128, 128, 128), content, 1)
        heading_font = pygame.font.SysFont("Arial", 25, bold=True)
        body_font = pygame.font.SysFont("Arial", 24)
        typed_text = self.intro_slide_display_text
        if "\n\n" in typed_text:
            heading_display, body_display = typed_text.split("\n\n", 1)
        else:
            heading_display = typed_text.split("\n", 1)[0]
            body_display = ""
        heading = heading_font.render(heading_display, True, (25, 35, 55))
        surf.blit(heading, (content.x + 28, content.y + 26))
        pygame.draw.line(surf, (190, 190, 190),
                         (content.x + 28, content.y + 66),
                         (content.right - 28, content.y + 66), 1)

        lines = self._wrap_intro_text(body_display, body_font, content.width - 56)
        line_y = content.y + 92
        line_height = body_font.get_linesize() + 8
        max_lines = max(1, (content.height - 112) // line_height)
        for line in lines[:max_lines]:
            rendered = body_font.render(line, True, (25, 25, 25))
            surf.blit(rendered, (content.x + 28, line_y))
            line_y += line_height

        footer_font = pygame.font.SysFont("Arial", 16)
        progress = footer_font.render(
            f"{self.intro_slide_index + 1} / {len(self._get_intro_slides())}",
            True, (60, 60, 60)
        )
        surf.blit(progress, (win.x + 22, win.bottom - 43))

        self.intro_slide_button_rect = None
        if self.intro_slide_char_index >= len(self.intro_slide_full_text):
            button_w, button_h = 174, 42
            button = pygame.Rect(win.right - button_w - 22, win.bottom - 54, button_w, button_h)
            self.intro_slide_button_rect = button
            pygame.draw.rect(surf, (128, 128, 128), button.move(2, 2))
            pygame.draw.rect(surf, (212, 208, 200), button)
            pygame.draw.line(surf, (255, 255, 255), button.topleft, (button.right - 1, button.top), 2)
            pygame.draw.line(surf, (255, 255, 255), button.topleft, (button.left, button.bottom - 1), 2)
            pygame.draw.line(surf, (80, 80, 80), (button.left, button.bottom - 1), (button.right - 1, button.bottom - 1), 2)
            pygame.draw.line(surf, (80, 80, 80), (button.right - 1, button.top), (button.right - 1, button.bottom - 1), 2)
            label = "НАЧАТЬ ИГРУ" if self.intro_slide_index == len(self._get_intro_slides()) - 1 else "ОК"
            button_font = pygame.font.SysFont("Arial", 20, bold=True)
            button_text = button_font.render(label, True, (20, 20, 20))
            surf.blit(button_text, button_text.get_rect(center=button.center))

        self._draw_admin_panel(surf)
        self.menu_cursor.draw(surf)
        self.screen_texture.write(pygame.image.tobytes(surf, 'RGBA', True))

    def _handle_intro_slide_events(self, event):
        if not self.intro_slides_active or self.admin_panel_open:
            return
        if event.type == pygame.KEYDOWN and event.key in (pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE):
            self._advance_intro_slide()
        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            screen_w, screen_h = self.screen.get_size()
            tex_w, tex_h = self.screen_texture.size
            pos = (int(event.pos[0] * tex_w / max(1, screen_w)),
                   int(event.pos[1] * tex_h / max(1, screen_h)))
            if self.intro_slide_button_rect and self.intro_slide_button_rect.collidepoint(pos):
                self._advance_intro_slide()

    def _admin_start_new_game(self):
        if self.game_logic.roach_attack_active or self.event_lifecycle.is_tracked("EVT_001_ROACH_ATTACK"):
            self._cancel_managed_roach_attack(reason="ADMIN_NEW_GAME")
        if self.game_logic.word_shock_active or self.event_lifecycle.is_tracked("EVT_002_WORD_SHOCK"):
            self._cancel_managed_word_shock(reason="ADMIN_NEW_GAME")
        self.admin_panel_open = False
        if self.settings_box.is_open:
            self.settings_box.close_dialog()
        self.current_screen = "game"
        self.crash_stage = 0
        self.channel_switch_active = False
        self.intro_slides_active = False
        self.audio_box.stop_music()
        w, h = self.screen.get_size()
        self.name_input_scene = NameInputScene((w, h), self.current_lang, self.menu_cursor)
        if hasattr(self.name_input_scene, "buffer"):
            self.name_input_scene.buffer = ""
        self.name_entry_active = True

    def _start_free_clean_flow(self):
        """Start the normal timed cleaning flow, shared by gameplay and admin tests."""
        self.game_logic.start_free_clean()
        self.game_logic.timer_clicks = 0
        self.game_logic.sprite_active = False
        self.game_logic.chase_planets.clear()
        self.game_logic.chase_planet_active = False

        phase_key = self.game_logic.get_phase()
        if phase_key in ["phase_0", "phase_1"]:
            phrases_pool = TRANSLATIONS[self.current_lang]["phrases"]
        else:
            phrases_pool = TRANSLATIONS[self.current_lang]["horror_phrases"]
            self.game_logic.set_notification(random.choice(phrases_pool), duration=5000)
        self.game_logic.notification_color = (255, 255, 255)

    def _spawn_chase_planets(self):
        """Create the standard Chase Planet round used by the live timer flow."""
        self.audio_box.play_chase_planet("spawn")
        tex_w, tex_h = self.screen_texture.size
        logic = self.game_logic
        logic.chase_planet_rounds_started += 1
        logic.chase_planets_target_count = min(6, logic.chase_planet_rounds_started)
        logic.chase_planets_caught_round = 0
        logic.chase_planet_active = True
        logic.chase_planets = []

        min_x = 40
        max_x = max(min_x, tex_w - 84)
        min_y = 60
        max_y = max(min_y, tex_h - 84)

        for _planet_number in range(logic.chase_planets_target_count):
            position = None
            for _attempt in range(30):
                x = random.randint(min_x, max_x)
                y = random.randint(min_y, max_y)
                if all(
                    math.hypot(x - other["x"], y - other["y"]) >= 78
                    for other in logic.chase_planets
                ):
                    position = (x, y)
                    break
            if position is None:
                position = (random.randint(min_x, max_x), random.randint(min_y, max_y))
            logic.chase_planets.append({"x": float(position[0]), "y": float(position[1])})

        first_planet = logic.chase_planets[0]
        logic.sprite_x = first_planet["x"]
        logic.sprite_y = first_planet["y"]
        logic.sprite_active = True
        logic.set_notification(TRANSLATIONS[self.current_lang]["earth_catch"], duration=5000)
        logic.notification_color = (255, 165, 0)

    def _start_chase_planet_test(self):
        """Enter the real timed Chase Planet state and spawn its first round immediately."""
        self._start_free_clean_flow()
        self.game_logic.timer_clicks = self.game_logic.sprite_spawn_clicks
        self._spawn_chase_planets()

    def _admin_minigame_registry(self):
        """Single registry for implemented mini-games and their real launch functions."""
        return {
            "memory": {
                "label": "MEMORY · СЕКТОРА",
                "description": "Найди правильный сектор три раза подряд.",
                "launcher": self.game_logic.start_memory_minigame,
            },
            "free_clean": {
                "label": "FREE CLEAN · ТАЙМЕР",
                "description": "Запусти штатный таймер уборки.",
                "launcher": self._start_free_clean_flow,
            },
            "chase_planet": {
                "label": "CHASE PLANET",
                "description": "Запусти таймер и сразу вызови первый раунд планет.",
                "launcher": self._start_chase_planet_test,
            },
        }

    def _admin_launch_minigame(self, game_id):
        if not self._admin_phase_controls_available():
            self._show_notification("Мини-игры доступны только в игровой сцене.", duration=1800)
            return
        definition = self._admin_minigame_registry().get(game_id)
        if not definition or not callable(definition.get("launcher")):
            self._show_notification("Эта мини-игра ещё не реализована.", duration=1800)
            return

        # Reuse the complete scene/session reset: preserve score and lifetime clicks,
        # but also clear application-level overlays, animations and window state.
        self._begin_game_session(reset_progress=False)
        definition["launcher"]()

    def _admin_reset_minigame(self):
        if not self._admin_phase_controls_available():
            return
        # Return to a clean gameplay baseline while keeping the panel on this tab.
        self._begin_game_session(reset_progress=False)
        self.admin_panel_open = True
        self.admin_panel_tab = "minigames"
        self._show_notification("ADMIN TEST RESET", duration=1800)

    def _begin_managed_event(self, event_id, *, data=None):
        """Reserve Event Manager resources before starting a legacy event controller."""
        try:
            return self.event_lifecycle.begin(event_id, data=data)
        except RuntimeError as exc:
            self._show_notification(f"Событие заблокировано: {exc}", duration=1800)
            return None

    def _finish_managed_event(self, event_id, *, cancelled=False, reason=None):
        """Finish the managed instance and restore temporary legacy parameters."""
        instance = self.event_lifecycle.instance_for(event_id)
        finished = self.event_lifecycle.finish(
            event_id, cancelled=cancelled, reason=reason
        )
        if (
            instance is not None
            and event_id == "EVT_001_ROACH_ATTACK"
            and "previous_roach_reward_per_roach" in instance.data
        ):
            self.game_logic.roach_reward_per_roach = int(
                instance.data["previous_roach_reward_per_roach"]
            )
        return finished

    def _cancel_managed_roach_attack(self, *, reset=False, reason="CANCELLED"):
        if reset:
            self.game_logic.reset_roach_attack()
        else:
            self.game_logic.stop_roach_attack()
        self._finish_managed_event(
            "EVT_001_ROACH_ATTACK", cancelled=True, reason=reason
        )
        self._stop_roach_audio()

    def _cancel_managed_word_shock(self, *, reset=False, reason="CANCELLED"):
        """Cancel the legacy Word Shock controller and release its managed resources."""
        if reset:
            self.game_logic.reset_word_shock()
        else:
            self.game_logic.stop_word_shock()
        pygame.key.stop_text_input()
        self._finish_managed_event(
            "EVT_002_WORD_SHOCK", cancelled=True, reason=reason
        )

    def _sync_managed_word_shock(self):
        """Reconcile Event Manager state with the legacy Word Shock controller."""
        event_id = "EVT_002_WORD_SHOCK"
        instance = self.event_lifecycle.instance_for(event_id)
        if instance is None:
            return
        if self.game_logic.word_shock_active:
            definition = self.event_catalog.get(event_id)
            start_phase = instance.data.get("phase_at_start")
            if (
                definition is not None
                and definition.phase_policy == "CANCEL"
                and start_phase is not None
                and self.game_logic.get_phase() != start_phase
            ):
                self._cancel_managed_word_shock(reason="PHASE_CHANGED")
            return
        completed = self.game_logic.word_shock_event_status == "COMPLETED"
        self._finish_managed_event(
            event_id,
            cancelled=not completed,
            reason=None if completed else self.game_logic.word_shock_event_status,
        )
        pygame.key.stop_text_input()

    def _sync_managed_roach_attack(self):
        """Reconcile the managed lifecycle with the still-legacy gameplay state."""
        event_id = "EVT_001_ROACH_ATTACK"
        instance = self.event_lifecycle.instance_for(event_id)
        if instance is None:
            return

        if self.game_logic.roach_attack_active:
            definition = self.event_catalog.get(event_id)
            start_phase = instance.data.get("phase_at_start")
            if (
                definition is not None
                and definition.phase_policy == "CANCEL"
                and start_phase is not None
                and self.game_logic.get_phase() != start_phase
            ):
                self._cancel_managed_roach_attack(reason="PHASE_CHANGED")
            return

        completed = self.game_logic.roach_event_status == "COMPLETED"
        self._finish_managed_event(
            event_id,
            cancelled=not completed,
            reason=None if completed else self.game_logic.roach_event_status,
        )
        self._stop_roach_audio()

    def _managed_event_inspect(self, event_id, legacy_text):
        instance = self.event_lifecycle.instance_for(event_id)
        if instance is None:
            history = [
                item for item in self.event_manager.instances.values()
                if item.event_id == event_id
            ]
            instance = max(
                history, key=lambda item: item.started_at or 0.0, default=None
            )
        if instance is not None:
            manager_state = instance.status.value
        else:
            blocked = self.event_manager.last_block_reason.get(event_id)
            manager_state = f"BLOCKED ({blocked})" if blocked else "IDLE"
        return f"{legacy_text} | Event Manager: {manager_state}"

    def _start_roach_attack(self, launch_source="ACTION_SEQUENCE"):
        """Запустить EVT_001: 24 таракана тремя волнами по восемь."""
        logic = self.game_logic
        if logic.roach_attack_active or logic.word_shock_active:
            return False
        if (
            logic.minigame_active
            or logic.timer_active
            or logic.sprite_active
            or logic.fade_screen_active
            or logic.chase_planet_active
        ):
            self._show_notification(
                "Сначала завершите активный игровой режим.", duration=1800
            )
            return False

        event_config = self.event_catalog.configuration("EVT_001_ROACH_ATTACK") or {}
        parameters = event_config.get("parameters", {})
        try:
            roaches_per_event = int(parameters.get("roaches_per_event", 24))
            reward_per_roach = int(parameters.get("reward_per_roach", 1))
        except (TypeError, ValueError):
            self._show_notification("Некорректная конфигурация EVT_001.", duration=1800)
            return False
        if not 1 <= roaches_per_event <= 48 or reward_per_roach < 0:
            self._show_notification("Параметры EVT_001 вне допустимого диапазона.", duration=1800)
            return False
        width, height = self.screen_texture.size
        target_exclusion = self.game_view.rect_target.inflate(170, 150)
        min_x, max_x = 28, max(28, width - 62)
        min_y = max(132, int(height * 0.27))
        max_y = max(min_y, height - 118)
        occupied = []
        entities = []
        band_width = min(150, max(70, width // 8))
        left_columns = (min_x, min(max_x, min_x + band_width // 2), min(max_x, min_x + band_width))
        right_columns = (
            max(min_x, max_x - band_width),
            max(min_x, max_x - band_width // 2),
            max_x,
        )
        row_positions = [
            round(min_y + (max_y - min_y) * row / 3)
            for row in range(4)
        ]
        spawn_slots = [
            (x, y, "left" if x in left_columns else "right")
            for y in row_positions
            for x in (*left_columns, *right_columns)
        ]
        spawn_slots = [
            slot for slot in spawn_slots
            if not pygame.Rect(slot[0], slot[1], 32, 25).colliderect(target_exclusion)
        ]
        random.shuffle(spawn_slots)

        if len(spawn_slots) < roaches_per_event:
            # Lower resolutions get a compact edge layout; avoid the target in every slot.
            edge_columns = (min_x, max_x)
            compact_rows = [
                round(min_y + (max_y - min_y) * row / 11)
                for row in range(12)
            ]
            extra_slots = [
                (x, y, "left" if x == min_x else "right")
                for y in compact_rows
                for x in edge_columns
            ]
            for slot in extra_slots:
                candidate = pygame.Rect(slot[0], slot[1], 32, 25)
                if not candidate.colliderect(target_exclusion) and slot not in spawn_slots:
                    spawn_slots.append(slot)
                if len(spawn_slots) >= roaches_per_event:
                    break

        for index in range(roaches_per_event):
            wave = index // 8
            if index < len(spawn_slots):
                base_x, base_y, side = spawn_slots[index]
            else:
                side = "left" if index % 2 == 0 else "right"
                base_x = min_x if side == "left" else max_x
                base_y = row_positions[index % len(row_positions)]
            x_jitter = 1 if width < 720 else 3
            x = max(min_x, min(max_x, base_x + random.randint(-x_jitter, x_jitter)))
            y = max(min_y, min(max_y, base_y + random.randint(-10, 10)))
            occupied.append(pygame.Rect(x, y, 32, 25))
            speed = random.uniform(108.0, 168.0)
            spread = random.uniform(-0.72, 0.72)
            angle = spread if side == "left" else 3.14159265 + spread
            vx = math.cos(angle) * speed
            vy = math.sin(angle) * speed
            entities.append({
                "x": float(x), "y": float(y), "vx": vx, "vy": vy,
                "base_speed": speed,
                "spawn_delay": wave * 0.78 + random.uniform(0.0, 0.20),
                "visible": wave == 0,
                "anim_offset": random.randint(0, 900),
                "turn_timer": random.uniform(0.25, 0.85),
                "direction": "right" if vx >= 0 else "left",
            })

        previous_reward = int(logic.roach_reward_per_roach)
        instance = self._begin_managed_event(
            "EVT_001_ROACH_ATTACK",
            data={
                "launch_source": str(launch_source),
                "phase_at_start": logic.get_phase(),
                "previous_roach_reward_per_roach": previous_reward,
                "configured_roaches": roaches_per_event,
                "configured_reward_per_roach": reward_per_roach,
            },
        )
        if instance is None:
            return False

        logic.roach_reward_per_roach = reward_per_roach
        try:
            started = logic.start_roach_attack(entities)
        except Exception:
            self._finish_managed_event(
                "EVT_001_ROACH_ATTACK", cancelled=True, reason="START_EXCEPTION"
            )
            raise
        if not started:
            self._finish_managed_event(
                "EVT_001_ROACH_ATTACK", cancelled=True, reason="LEGACY_START_REJECTED"
            )
            return False

        logic.roach_announcement_started_at = pygame.time.get_ticks()
        self.admin_event_inspect_text = self._managed_event_inspect(
            "EVT_001_ROACH_ATTACK", logic.inspect_roach_attack()
        )
        self.audio_box.play_roach_attack("start")
        return True

    def _start_word_shock(self, launch_source="ACTION_SEQUENCE"):
        """Start EVT_002 through Event Manager before activating its legacy controller."""
        logic = self.game_logic
        event_id = "EVT_002_WORD_SHOCK"
        payload = self.event_catalog.configuration(event_id) or {}
        parameters = payload.get("parameters", {})
        try:
            duration_min = int(parameters.get("duration_min_seconds", 120))
            duration_max = int(parameters.get("duration_max_seconds", 180))
            confirmation_delay = float(parameters.get("confirmation_after_seconds", 30))
            wrong_answer_extension = int(parameters.get("wrong_answer_extension_seconds", 60))
            if duration_min < 120 or duration_max > 180 or duration_min > duration_max:
                raise ValueError("INVALID_DURATION_RANGE")
            if confirmation_delay < 0 or wrong_answer_extension < 1:
                raise ValueError("INVALID_TIMING_PARAMETERS")
        except (TypeError, ValueError) as exc:
            self._show_notification(f"Некорректная конфигурация {event_id}: {exc}", duration=2200)
            return False
        duration = random.randint(duration_min, duration_max)
        instance = self._begin_managed_event(
            event_id,
            data={
                "launch_source": str(launch_source),
                "phase_at_start": logic.get_phase(),
                "duration_seconds": duration,
                "confirmation_after_seconds": confirmation_delay,
                "wrong_answer_extension_seconds": wrong_answer_extension,
            },
        )
        if instance is None:
            return False
        try:
            started = logic.start_word_shock(
                duration_seconds=duration,
                confirmation_after_seconds=confirmation_delay,
                wrong_answer_extension_seconds=wrong_answer_extension,
            )
        except Exception:
            self._finish_managed_event(event_id, cancelled=True, reason="START_EXCEPTION")
            raise
        if not started:
            self._finish_managed_event(event_id, cancelled=True, reason="LEGACY_START_REJECTED")
            return False
        self.game_view.word_shock_confirm_rect = None
        self.admin_event_inspect_text = self._managed_event_inspect(
            event_id, logic.inspect_word_shock()
        )
        return True

    def _submit_word_shock_answer(self):
        result = self.game_logic.submit_word_shock_answer(self.game_logic.word_shock_input)
        if result == "ACCEPTED":
            pygame.key.stop_text_input()
            self._finish_managed_event("EVT_002_WORD_SHOCK", cancelled=False)
            self.admin_event_inspect_text = self._managed_event_inspect(
                "EVT_002_WORD_SHOCK", self.game_logic.inspect_word_shock()
            )
        return result

    def _handle_word_shock_input(self, event):
        logic = self.game_logic
        if not logic.word_shock_active or not logic.word_shock_modal_visible:
            return
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_BACKSPACE:
                logic.word_shock_input = logic.word_shock_input[:-1]
            elif event.key in (pygame.K_RETURN, pygame.K_KP_ENTER):
                self._submit_word_shock_answer()
            # Остальные клавиши, включая Escape и F2, не закрывают событие.
            return
        if event.type == getattr(pygame, "TEXTINPUT", -1):
            text = getattr(event, "text", "")
            cleaned = "".join(ch for ch in text if ch.isprintable() and ch not in "\r\n\t")
            logic.word_shock_input = (logic.word_shock_input + cleaned)[:32]
            return
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            win_w, win_h = self.screen.get_size()
            tex_w, tex_h = self.screen_texture.size
            pos = (
                int(event.pos[0] * (tex_w / max(1, win_w))),
                int(event.pos[1] * (tex_h / max(1, win_h))),
            )
            # EVT_004 consumes clicks while the dragon event is active
            confirm_rect = getattr(self.game_view, "word_shock_confirm_rect", None)
            if confirm_rect and confirm_rect.collidepoint(pos):
                self._submit_word_shock_answer()

    def _sync_roach_audio(self):
        logic = self.game_logic
        blocked = (
            logic.minigame_active
            or logic.timer_active
            or logic.sprite_active
            or logic.chase_planet_active
            or logic.fade_screen_active
            or logic.clicks_in_cycle >= 10
            or logic.code_window_open
            or logic.lore_window_open
            or logic.lore_text_viewer_open
            or logic.lore_image_viewer_open
        )
        visible = any(
            item.get("visible", True) or item.get("spawn_delay", 0.0) <= 0.0
            for item in logic.roach_entities
        )
        should_play = logic.roach_attack_active and visible and not blocked
        if should_play and not self._roach_scuttle_playing:
            self._roach_scuttle_playing = self.audio_box.play_roach_attack("scuttle_loop")
        elif not should_play and self._roach_scuttle_playing:
            self.audio_box.stop_roach_scuttle()
            self._roach_scuttle_playing = False

    def _stop_roach_audio(self):
        """Stop every dedicated EVT_001 channel when the event/session is stopped."""
        self.audio_box.stop_roach_attack_audio()
        self._roach_scuttle_playing = False

    def _log_exception(self, context, exc):
        """Record caught exceptions both in logs/palchik.log and the admin log tab."""
        log_exception(self.app_logger, str(context), exc)

    def _open_admin_log_file(self):
        self.log_file_path.parent.mkdir(parents=True, exist_ok=True)
        self.log_file_path.touch(exist_ok=True)
        try:
            if os.name == "nt":
                os.startfile(str(self.log_file_path))
            else:
                subprocess.Popen(["xdg-open", str(self.log_file_path)])
        except Exception as exc:
            self._log_exception("ADMIN_LOG_OPEN", exc)
            self._show_notification("Не удалось открыть файл журнала. См. путь в панели.", duration=2500)

    def _start_evt004_audio(self):
        """Start EVT004's configured music through pygame.mixer.music."""
        self.audio_box.stop_music()
        music_path = self.evt004_audio_config.get("music")
        if not music_path:
            self.app_logger.warning("EVT_004 has no music path in its event config")
            return False
        started = self.audio_box.play_event_music(music_path, volume=0.30, label="evt004")
        if not started:
            self.app_logger.warning("EVT_004 theme could not be started: %s", music_path)
        return started

    def _route_evt004_audio_events(self, events):
        """Route runtime state transitions to dedicated EVT004 sound channels."""
        sound_paths = self.evt004_audio_config.get("events", {})
        for event_key in events:
            if event_key == "wing_flap_loop_stop":
                self.audio_box.stop_evt004_sfx("wing_flap_loop")
                self._evt004_wing_loop_active = False
                continue
            loop = event_key == "wing_flap_loop_start"
            sound_key = "wing_flap_loop" if loop else event_key
            sound_path = sound_paths.get(sound_key)
            if not sound_path:
                self.app_logger.warning("EVT_004 audio key missing from config: %s", sound_key)
                continue
            self.audio_box.play_evt004_sfx(
                sound_path, event_key=sound_key, loop=loop,
                volume=0.42 if loop else 0.78,
            )
            if loop:
                self._evt004_wing_loop_active = True

    def _stop_evt004_audio(self):
        """Stop only audio owned by EVT004."""
        self.audio_box.stop_evt004_audio()
        self.audio_box.stop_event_music(label="evt004")
        self._evt004_wing_loop_active = False

    def _initialize_evt004_instance(self, instance):
        """Build and start EVT004; release EventManager claims if setup fails."""
        self.evt004_instance_id = instance.instance_id
        self.evt004_started_at = time.monotonic()
        try:
            surface_size = (self.game_view.width, self.game_view.height)
            self.evt004_presentation = AdventureRoadPresentation(self.game_view)
            self.evt004_runtime = self.evt004_presentation.build_runtime(
                surface_size, Path(__file__).resolve().parent, dragon_hp=8,
            )
            self.evt004_runtime.start()
            self._start_evt004_audio()
            self._route_evt004_audio_events(self.evt004_runtime.drain_audio_events())
            return True
        except Exception:
            self.app_logger.exception("EVT_004 initialization failed")
            self._stop_evt004_audio()
            try:
                self.event_manager.finish(
                    instance.instance_id, cancelled=True, reason="INITIALIZATION_FAILED",
                )
            except Exception:
                self.app_logger.exception("EVT_004 failed to release startup resources")
            self.evt004_runtime = None
            self.evt004_presentation = None
            self.evt004_instance_id = None
            self.evt004_started_at = 0.0
            self._show_notification("EVT_004: ОШИБКА ЗАПУСКА · СМ. ЖУРНАЛ", duration=2500)
            return False

    def _start_evt004_from_secret_code(self):
        """Launch EVT_004 from the independent secret trigger code 111111."""
        if self.evt004_runtime is not None and self.evt004_runtime.running:
            self._show_notification("EVT_004 УЖЕ ВЫПОЛНЯЕТСЯ", duration=1500)
            return False
        if not self._admin_phase_controls_available():
            self._show_notification("EVT_004 ДОСТУПЕН ТОЛЬКО В ИГРОВОЙ СЦЕНЕ", duration=1800)
            return False
        try:
            instance = self.event_manager.begin("EVT_004_ADVENTURE_ROAD", {
                "source": "SECRET_CODE",
                "trigger_code": "111111",
            })
        except RuntimeError as exc:
            self._show_notification(f"EVT_004 БЛОКИРОВАН: {exc}", duration=2000)
            return False
        if not self._initialize_evt004_instance(instance):
            return False
        self._show_notification("EVT_004: ДОРОГА ПРИКЛЮЧЕНИЙ НАЧАТА", duration=2000)
        return True

    def _start_evt004_admin(self):
        """Launch EVT_004 from admin panel without writing player progress."""
        if not self._admin_phase_controls_available():
            self._show_notification("EVT_004 ДОСТУПЕН ТОЛЬКО В ИГРОВОЙ СЦЕНЕ", duration=1800)
            return False
        if self.evt004_runtime is not None and self.evt004_runtime.running:
            self._show_notification("EVT_004 УЖЕ ВЫПОЛНЯЕТСЯ", duration=1500)
            return False
        try:
            instance = self.event_manager.begin("EVT_004_ADVENTURE_ROAD", {
                "source": "ADMIN",
                "admin_sandbox": True,
            })
        except RuntimeError as exc:
            self._show_notification(f"EVT_004 БЛОКИРОВАН: {exc}", duration=2000)
            return False
        if not self._initialize_evt004_instance(instance):
            return False
        self._show_notification("EVT_004: АДМИН-ТЕСТ ЗАПУЩЕН", duration=2000)
        return True

    def _finish_evt004(self, cancelled=False, failed=False, reason=None):
        """Finish EVT_004: release resources, save outcome, restore audio/game state."""
        if self.evt004_instance_id is None:
            return
        instance_id = self.evt004_instance_id
        outcome = None
        if self.evt004_runtime is not None:
            result = self.evt004_runtime.result()
            if result is not None:
                outcome = result.result
        if cancelled and self.evt004_runtime is not None and self.evt004_runtime.running:
            self.evt004_runtime.cancel(reason or "HOST_CANCELLED")
            result = self.evt004_runtime.result()
            if result is not None:
                outcome = result.result
        if cancelled and outcome is None:
            outcome = "CANCELLED"
        if failed or outcome == "DEFEAT":
            event_status_failed = True
            event_status_cancelled = False
        elif cancelled or outcome == "CANCELLED":
            event_status_failed = False
            event_status_cancelled = True
        else:
            event_status_failed = False
            event_status_cancelled = False
        try:
            instance = self.event_manager.finish(
                instance_id,
                cancelled=event_status_cancelled,
                failed=event_status_failed,
                reason=reason,
            )
        except KeyError:
            instance = None
        is_admin_sandbox = False
        if self.evt004_runtime is not None:
            inst = self.event_manager.instances.get(instance_id)
            if inst is not None:
                is_admin_sandbox = bool(inst.data.get("admin_sandbox", False))
        if not is_admin_sandbox and outcome is not None:
            state = {
                "outcome": outcome,
                "reason": reason or "",
                "dragon_hp": self.evt004_runtime.dragon_hp if self.evt004_runtime else 0,
                "dragon_max_hp": self.evt004_runtime.dragon_hp_max if self.evt004_runtime else 0,
                "destroyed_targets": self.evt004_runtime.destroyed_targets if self.evt004_runtime else 0,
                "total_targets": self.evt004_runtime.total_targets if self.evt004_runtime else 0,
                "finished_at": time.monotonic(),
            }
            try:
                SaveManager.save_event_state("EVT_004_ADVENTURE_ROAD", state)
            except Exception:
                self.app_logger.exception("EVT_004 save state failed")
            if outcome == "VICTORY":
                try:
                    from events.secret_access import mark_event_completed, normalize_event_collection_progress
                    data = SaveManager._read_raw_game_data()
                    progress = normalize_event_collection_progress(data.get("event_collection_progress", {}))
                    progress = mark_event_completed(progress, "road_of_adventures")
                    SaveManager.save_event_collection_state(progress=progress)
                except Exception:
                    self.app_logger.exception("EVT_004 collection save failed")
            elif outcome == "DEFEAT":
                try:
                    from events.secret_access import mark_event_found, normalize_event_collection_progress
                    data = SaveManager._read_raw_game_data()
                    progress = normalize_event_collection_progress(data.get("event_collection_progress", {}))
                    progress = mark_event_found(progress, "road_of_adventures")
                    SaveManager.save_event_collection_state(progress=progress)
                except Exception:
                    self.app_logger.exception("EVT_004 defeat collection save failed")
        try:
            self._stop_evt004_audio()
            self.audio_box.play_game_music()
        except Exception:
            self.app_logger.exception("EVT_004 audio restore failed")
        self.evt004_runtime = None
        self.evt004_presentation = None
        self.evt004_instance_id = None
        self.evt004_started_at = 0.0
        if outcome == "VICTORY":
            self._show_notification("EVT_004: ПОБЕДА — ДРАКОН ПОБЕЖДЕН", duration=2500)
        elif outcome == "DEFEAT":
            self._show_notification("EVT_004: ПОРАЖЕНИЕ — ЦЕЛИ УНИЧТОЖЕНЫ", duration=2500)
        elif outcome == "CANCELLED":
            self._show_notification("EVT_004: ОТМЕНЕНО", duration=2000)

    def _update_evt004(self, dt):
        """Update EVT004 and route state-transition audio; return active state."""
        runtime = self.evt004_runtime
        if runtime is None:
            return False
        result = runtime.update(dt) if runtime.running else runtime.result()
        self._route_evt004_audio_events(runtime.drain_audio_events())
        if result is not None:
            if result.result == "VICTORY":
                self._finish_evt004(failed=False, cancelled=False, reason="DRAGON_DEFEATED")
            elif result.result == "DEFEAT":
                self._finish_evt004(failed=True, cancelled=False, reason="ALL_INTERFACE_TARGETS_DESTROYED")
            elif result.result == "CANCELLED":
                self._finish_evt004(cancelled=True, reason=result.reason or "HOST_CANCELLED")
            return False
        return runtime.running

    def _draw_evt004(self, surface):
        """Draw EVT_004 overlay over the game surface."""
        if self.evt004_runtime is None or self.evt004_presentation is None:
            return
        if not self.evt004_runtime.running:
            return
        snapshot = surface.copy()
        self.evt004_presentation.draw(surface, self.evt004_runtime, snapshot)

    def _handle_evt004_click(self, pos):
        """Route mouse click to EVT_004 runtime. Returns True if consumed."""
        if self.evt004_runtime is None or not self.evt004_runtime.running:
            return False
        self.evt004_runtime.player_attack(pos)
        return True

    def _admin_stop_event(self, event_id):
        if event_id == "EVT_001_ROACH_ATTACK":
            self._cancel_managed_roach_attack(reason="ADMIN_STOP")
            self.admin_event_inspect_text = self._managed_event_inspect(
                event_id, self.game_logic.inspect_roach_attack()
            )
        elif event_id == "EVT_002_WORD_SHOCK":
            self._cancel_managed_word_shock(reason="ADMIN_STOP")
            self.admin_event_inspect_text = self._managed_event_inspect(
                event_id, self.game_logic.inspect_word_shock()
            )
        else:
            return
        self.admin_panel_tab = "events"
        self._show_notification(event_id + ": STOPPED", duration=1500)

    def _admin_reset_event(self, event_id):
        if event_id == "EVT_001_ROACH_ATTACK":
            self._cancel_managed_roach_attack(reset=True, reason="ADMIN_RESET")
            self.admin_event_inspect_text = self._managed_event_inspect(
                event_id, self.game_logic.inspect_roach_attack()
            )
        elif event_id == "EVT_002_WORD_SHOCK":
            self._cancel_managed_word_shock(reset=True, reason="ADMIN_RESET")
            self.admin_event_inspect_text = self._managed_event_inspect(
                event_id, self.game_logic.inspect_word_shock()
            )
        else:
            return
        self.admin_panel_tab = "events"
        self._show_notification(event_id + ": RESET", duration=1500)

    def _admin_inspect_event(self, event_id):
        if event_id == "EVT_001_ROACH_ATTACK":
            self.admin_event_inspect_text = self._managed_event_inspect(
                event_id, self.game_logic.inspect_roach_attack()
            )
        elif event_id == "EVT_002_WORD_SHOCK":
            self.admin_event_inspect_text = self._managed_event_inspect(
                event_id, self.game_logic.inspect_word_shock()
            )

    def _admin_phase_controls_available(self):
        return (
            self.current_screen == "game"
            and self.crash_stage == 0
            and not self.intro_slides_active
            and not self.name_entry_active
            and not self.channel_switch_active
            and not (self.evt004_runtime is not None and self.evt004_runtime.running)
        )

    def _admin_set_phase(self, clicks):
        if not self._admin_phase_controls_available():
            return
        # Phase jumps clear transient state from the previous phase, but keep score.
        if self.game_logic.word_shock_active or self.event_lifecycle.is_tracked("EVT_002_WORD_SHOCK"):
            self._cancel_managed_word_shock(reason="PHASE_RESET")
        if self.game_logic.roach_attack_active or self.event_lifecycle.is_tracked("EVT_001_ROACH_ATTACK"):
            self._cancel_managed_roach_attack(reason="PHASE_RESET")
        self.game_logic.reset_session(reset_progress=False)
        self.game_logic.total_clicks = int(clicks)
        self.game_logic._sync_to_disk()
        self.final_phase_triggered = False
        self.crash_stage = 0
        self.fake_crash_start = 0
        self.game_view.recalculate_layout()
        self._show_notification(f"ADMIN: phase position {clicks} clicks", duration=1800)
        self._on_limit_reached()

    def _admin_event_registry(self):
        """Expose event metadata from the central catalog to the existing admin UI."""
        return {
            definition.event_id: {
                "label": definition.label,
                "description": definition.description,
            }
            for definition in self.event_catalog.all(enabled_only=True)
            if definition.metadata.get("admin_supported", False)
        }

    def _admin_trigger_event(self, event_id):
        if event_id not in self._admin_event_registry():
            self._show_notification("НЕВЕРНЫЙ ID СОБЫТИЯ.", duration=1600)
            return
        if not self._admin_phase_controls_available():
            self._show_notification("СОБЫТИЕ НЕДОСТУПНО В ЭТОТ МОМЕНТ.", duration=1800)
            return
        if event_id == "EVT_001_ROACH_ATTACK":
            started = self._start_roach_attack(launch_source="ADMIN")
        elif event_id == "EVT_002_WORD_SHOCK":
            started = self._start_word_shock(launch_source="ADMIN")
        elif event_id == "EVT_003_PLEASE_DONT_TOUCH":
            started = self._admin_trigger_evt003()
        elif event_id == "EVT_004_ADVENTURE_ROAD":
            started = self._start_evt004_admin()
        else:
            self._show_notification("ЭТО СОБЫТИЕ НЕ НАСТРОЕНО НА АДМИН СКРИПТ.", duration=1800)
            return
        if started:
            self.admin_panel_tab = "events"
            self.admin_panel_open = False
            self._show_notification(event_id + ": TRIGGERED", duration=1800)

    def _evt003_admin_block_reason(self):
        logic = self.game_logic
        blocked = (
            logic.word_shock_active or logic.roach_attack_active
            or logic.minigame_active or logic.timer_active or logic.sprite_active
            or logic.chase_planet_active or logic.fade_screen_active
            or logic.code_window_open or logic.lore_window_open
            or logic.lore_text_viewer_open or logic.lore_image_viewer_open
            or self.settings_box.is_open
        )
        return "GAMEPLAY_MODE_BUSY" if blocked else None

    def _start_evt003_admin_flow(self, phase, *, sandbox):
        if not self._admin_phase_controls_available():
            self._show_notification("EVT_003 доступен только в игровой сцене.", duration=1800)
            return False
        if self.evt003_state is not None:
            self._show_notification("EVT_003 уже выполняется.", duration=1800)
            return False
        reason = self._evt003_admin_block_reason()
        if reason:
            self._show_notification("EVT_003 нельзя запустить поверх другого игрового режима.", duration=2200)
            return False
        allowed, reason = self.evt003_runtime.can_start(phase, sandbox=sandbox)
        if not allowed:
            message = (
                "EVT_003 уже использовал реальную попытку в этой фазе."
                if reason == "ALREADY_OCCURRED_THIS_PHASE"
                else f"EVT_003 сейчас недоступен: {reason or 'EVENT_BLOCKED'}"
            )
            self._show_notification(message, duration=2600)
            return False
        try:
            instance = self.evt003_runtime.start(phase, sandbox=sandbox)
        except Exception as exc:
            self._log_exception(f"EVT003_ADMIN_START phase={phase} sandbox={sandbox}", exc)
            self._show_notification("EVT_003: не удалось запустить событие. Откройте F2 → ЖУРНАЛ.", duration=2800)
            return False
        self.evt003_instance_id = instance.instance_id
        self.evt003_started_at = float(instance.started_at or time.monotonic())
        self.evt003_typewriter_count = 0
        self.evt003_typewriter.reset(
            "PLEASE DON'T TOUCH ANYTHING", started_at=self.evt003_started_at,
            interval=self.evt003_typewriter_interval,
        )
        self.evt003_dialog_payload = None
        self.evt003_is_sandbox = bool(sandbox)
        self.evt003_state = "RUNNING"
        self.evt003_scheduled_phase = phase
        self.evt003_next_check_at = float("inf")
        return True

    def _admin_trigger_evt003(self):
        """Real run: consumes a persistent phase attempt and applies normal outcomes."""
        return self._start_evt003_admin_flow(self.game_logic.get_phase(), sandbox=False)

    def _admin_test_evt003(self, phase):
        """Repeatable sandbox run: same presentation/resources, no player-save writes."""
        return self._start_evt003_admin_flow(str(phase), sandbox=True)

    def mark_event_found(self, event_id):
        """Mark a collection item as discovered; safe for future event handlers."""
        updated = mark_event_found(self.event_collection_progress, event_id)
        SaveManager.save_event_collection_state(progress=updated)
        self.event_collection_progress = updated

    def mark_event_completed(self, event_id):
        """Mark an event as completed (completion also implies discovery)."""
        updated = mark_event_completed(self.event_collection_progress, event_id)
        SaveManager.save_event_collection_state(progress=updated)
        self.event_collection_progress = updated

    def _open_secret_input(self, *, force=False):
        """Open the six-digit access dialog for the current gameplay session."""
        if self.secret_prompt_session.completed_this_session and not force:
            return False
        if self.secret_input_open:
            return True
        self.secret_input_value = ""
        self.secret_input_started_at = time.monotonic()
        self.secret_input_last_digit_at = 0.0
        self.secret_input_error_until = 0.0
        self.secret_input_closing = False
        self.secret_input_closing_started_at = 0.0
        self.secret_input_open = True
        return True

    def _cancel_secret_input(self):
        """Close the dialog with its existing animation; do not alter unlock state."""
        if not self.secret_input_open or self.secret_input_closing:
            return False
        self.secret_input_closing = True
        self.secret_input_closing_started_at = time.monotonic()
        self.secret_input_value = ""
        self.secret_prompt_session.retry_after_cancel()
        return True

    def _confirm_secret_input(self):
        """Confirm the PIN from the dialog's OK button."""
        if len(self.secret_input_value) != SECRET_ACCESS_CODE_LENGTH:
            self.secret_input_error_until = time.monotonic() + 0.55
            self._show_notification("ВВЕДИТЕ 6 ЦИФР", duration=1500)
            return False
        return self._submit_secret_input()

    def _submit_secret_input(self, candidate=None):
        """Route 111111 to EVT_004 and keep 172314 as collection unlock only."""
        attempt = self.secret_input_value if candidate is None else str(candidate)
        # is_valid_numeric_code intentionally validates only the legacy collection PIN.
        # EVT_004 has its own independent trigger code and must not replace it.
        if attempt != "111111" and not is_valid_numeric_code(attempt):
            self.secret_input_value = ""
            self.secret_input_error_until = time.monotonic() + 0.75
            self._show_notification("НЕВЕРНЫЙ КОД", duration=1800)
            return False

        if attempt == "111111":
            if not self._start_evt004_from_secret_code():
                self.secret_input_error_until = time.monotonic() + 0.75
                return False
            self.secret_prompt_session.mark_completed()
            self.secret_input_closing = True
            self.secret_input_closing_started_at = time.monotonic()
            self.secret_input_value = ""
            self.event_collection_open = False
            self.event_collection_closing = False
            self.event_collection_window_rect = None
            self.event_collection_close_rect = None
            return True

        try:
            SaveManager.save_event_collection_state(
                unlocked=True, progress=self.event_collection_progress,
            )
        except Exception:
            self.app_logger.exception("Не удалось сохранить разблокировку коллекции событий")
            self.secret_input_error_until = time.monotonic() + 0.75
            self._show_notification("ОШИБКА СОХРАНЕНИЯ ДОСТУПА", duration=2200)
            return False

        self.event_collection_unlocked = True
        self.secret_prompt_session.mark_completed()
        self.secret_input_closing = True
        self.secret_input_closing_started_at = time.monotonic()
        self.secret_input_value = ""
        self.event_collection_open = False
        self.event_collection_closing = False
        self.event_collection_window_rect = None
        self.event_collection_close_rect = None
        self._show_notification("КОД ПРИНЯТ · КОЛЛЕКЦИЯ СОБЫТИЙ ОТКРЫТА", duration=2600)
        return True

    def _handle_secret_input_key(self, event):
        """Handle digits, backspace, Enter and Escape in the PIN dialog."""
        if self.secret_input_closing:
            return
        if event.key == pygame.K_ESCAPE:
            self._cancel_secret_input()
            return
        if event.key == pygame.K_BACKSPACE:
            self.secret_input_value = self.secret_input_value[:-1]
            return
        if event.key in (pygame.K_RETURN, pygame.K_KP_ENTER):
            self._confirm_secret_input()
            return

        digit = None
        unicode_value = getattr(event, "unicode", "")
        if (isinstance(unicode_value, str) and len(unicode_value) == 1
                and unicode_value.isascii() and unicode_value.isdigit()):
            digit = unicode_value
        elif pygame.K_0 <= event.key <= pygame.K_9:
            digit = str(event.key - pygame.K_0)
        elif pygame.K_KP0 <= event.key <= pygame.K_KP9:
            digit = str(event.key - pygame.K_KP0)
        if digit is not None and len(self.secret_input_value) < SECRET_ACCESS_CODE_LENGTH:
            self.secret_input_value += digit
            self.secret_input_last_digit_at = time.monotonic()

    def _draw_secret_input(self, surface):
        if not self.secret_input_open:
            self.secret_input_rect = None
            self.secret_input_close_rect = None
            self.secret_input_ok_rect = None
            self.secret_input_cancel_rect = None
            return

        width, height = surface.get_size()
        target = getattr(self.game_view, "rect_target", None)

        # Preserve the existing dimensions and placement below the target button.
        panel_w = min(680, max(260, width - 32))
        if panel_w > width - 12:
            panel_w = width - 12
        panel_h = min(214, max(146, height - 24))
        x = (width - panel_w) // 2
        if target is not None:
            y = target.bottom + 18
            if y + panel_h > height - 12:
                y = target.top - panel_h - 18
        else:
            y = int(height * 0.56 - panel_h / 2)
        y = max(6, min(height - panel_h - 6, y))
        final_panel = pygame.Rect(x, y, panel_w, panel_h)

        now = time.monotonic()
        opening_t = min(1.0, max(0.0, (now - self.secret_input_started_at) / 0.30))
        opening_ease = 1.0 - (1.0 - opening_t) ** 3
        closing_t = 0.0
        if self.secret_input_closing:
            closing_t = min(1.0, max(0.0, (now - self.secret_input_closing_started_at) / 0.22))
        visibility = opening_ease * (1.0 - closing_t)
        if self.secret_input_closing and closing_t >= 1.0:
            self.secret_input_open = False
            self.secret_input_closing = False
            self.secret_input_value = ""
            self.secret_prompt_session.retry_after_cancel()
            self.secret_input_rect = None
            self.secret_input_close_rect = None
            self.secret_input_ok_rect = None
            self.secret_input_cancel_rect = None
            return

        scale_x = 0.86 + 0.14 * visibility
        scale_y = 0.92 + 0.08 * visibility
        draw_w = max(1, int(panel_w * scale_x))
        draw_h = max(1, int(panel_h * scale_y))
        layer = pygame.Surface((panel_w, panel_h), pygame.SRCALPHA)

        error_active = now < self.secret_input_error_until
        error_elapsed = max(0.0, 0.75 - (self.secret_input_error_until - now)) if error_active else 0.0
        error_strength = max(0.0, 1.0 - error_elapsed / 0.75) if error_active else 0.0
        shake_x = int(math.sin(error_elapsed * 58.0) * 7 * error_strength) if error_active else 0

        # Match GameScene._draw_hidden_code_ui: classic Win9x bevel and blue title bar.
        layer.fill((192, 192, 192, 255))
        pygame.draw.rect(layer, (128, 128, 128), (0, 0, panel_w, panel_h), 2)
        pygame.draw.rect(layer, (255, 255, 255), (2, 2, panel_w - 4, 1))
        pygame.draw.rect(layer, (255, 255, 255), (2, 2, 1, panel_h - 4))
        pygame.draw.rect(layer, (64, 64, 64), (2, panel_h - 3, panel_w - 4, 1))
        pygame.draw.rect(layer, (64, 64, 64), (panel_w - 3, 2, 1, panel_h - 4))

        title_bar_h = 24
        pygame.draw.rect(layer, (192, 192, 192), (3, title_bar_h, panel_w - 6, panel_h - title_bar_h - 3))
        pygame.draw.rect(layer, (0, 0, 128), (3, 3, panel_w - 6, title_bar_h - 3))
        title_font = pygame.font.SysFont("Arial", 14, bold=True)
        title_surface = title_font.render("ВВОД ПИН-КОДА", True, (255, 255, 255))
        layer.blit(title_surface, (8, 6))

        # Same red close control as the hidden archive dialog.
        close_local = pygame.Rect(panel_w - 24, 4, 18, 18)
        pygame.draw.rect(layer, (192, 0, 0), close_local)
        pygame.draw.rect(layer, (128, 128, 128), close_local, 1)
        close_font = pygame.font.SysFont("Arial", 12, bold=True)
        close_surface = close_font.render("X", True, (255, 255, 255))
        layer.blit(close_surface, close_surface.get_rect(center=close_local.center))

        # Reuse the small pixel-art key from GameScene._draw_hidden_code_ui.
        pygame.draw.circle(layer, (88, 67, 25), (43, 83), 14)
        pygame.draw.circle(layer, (244, 196, 55), (42, 82), 11)
        pygame.draw.circle(layer, (192, 192, 192), (42, 82), 4)
        pygame.draw.line(layer, (91, 69, 25), (50, 90), (78, 118), 9)
        pygame.draw.line(layer, (244, 196, 55), (50, 90), (78, 118), 6)
        pygame.draw.line(layer, (91, 69, 25), (66, 106), (73, 99), 8)
        pygame.draw.line(layer, (244, 196, 55), (66, 106), (73, 99), 5)
        pygame.draw.line(layer, (91, 69, 25), (73, 113), (80, 106), 8)
        pygame.draw.line(layer, (244, 196, 55), (73, 113), (80, 106), 5)

        prompt_color = (150, 25, 25) if error_active else (0, 0, 0)
        prompt_size = 14 if panel_w >= 420 else 11
        prompt_font = pygame.font.SysFont("Arial", prompt_size, bold=False)
        prompt_surface = prompt_font.render("ВВЕДИТЕ КОД ДОСТУПА", True, prompt_color)
        prompt_x = 101 if panel_w >= 420 else max(8, (panel_w - prompt_surface.get_width()) // 2)
        layer.blit(prompt_surface, (prompt_x, 43))

        # The six fields keep the existing one-digit-per-keyboard-press behavior.
        if panel_w >= 620:
            slot_w, slot_gap = 32, 8
            slots_start_x = 153
        elif panel_w >= 420:
            slot_w, slot_gap = 22, 4
            slots_start_x = 153
        else:
            slot_gap = 3
            slot_w = min(18, max(14, (panel_w - 112 - 5 * slot_gap) // SECRET_ACCESS_CODE_LENGTH))
            slots_start_x = 101
        slot_h = 36 if panel_h >= 190 else 28
        slots_y = 111 if panel_h >= 190 else 82
        if panel_w < 420:
            slot_h = 30 if panel_h >= 190 else 24
        digit_font = pygame.font.SysFont("Arial", 18 if slot_w >= 30 else 14, bold=True)
        for index in range(SECRET_ACCESS_CODE_LENGTH):
            slot = pygame.Rect(slots_start_x + index * (slot_w + slot_gap), slots_y, slot_w, slot_h)
            pygame.draw.rect(layer, (255, 255, 255), slot)
            pygame.draw.line(layer, (96, 96, 96), slot.topleft, (slot.right - 1, slot.top))
            pygame.draw.line(layer, (96, 96, 96), slot.topleft, (slot.left, slot.bottom - 1))
            pygame.draw.line(layer, (255, 255, 255), (slot.left, slot.bottom - 1), (slot.right - 1, slot.bottom - 1))
            pygame.draw.line(layer, (255, 255, 255), (slot.right - 1, slot.top), (slot.right - 1, slot.bottom - 1))

            is_filled = index < len(self.secret_input_value)
            is_active = index == len(self.secret_input_value) and index < SECRET_ACCESS_CODE_LENGTH
            if is_filled:
                digit_surface = digit_font.render(self.secret_input_value[index], True, (0, 0, 0))
                layer.blit(digit_surface, digit_surface.get_rect(center=slot.center))
            if is_active:
                focus_color = (192, 0, 0) if error_active else (0, 0, 255)
                pygame.draw.rect(layer, focus_color, slot, 2)
                if int(now * 3.5) % 2 == 0:
                    caret = pygame.Rect(slot.centerx - 1, slot.y + 7, 2, max(8, slot.height - 14))
                    pygame.draw.rect(layer, (0, 0, 128), caret)
            elif error_active:
                pygame.draw.rect(layer, (192, 0, 0), slot, 1)

        def draw_button(rect, label):
            pygame.draw.rect(layer, (192, 192, 192), rect)
            pygame.draw.line(layer, (255, 255, 255), rect.topleft, (rect.right - 1, rect.top))
            pygame.draw.line(layer, (255, 255, 255), rect.topleft, (rect.left, rect.bottom - 1))
            pygame.draw.line(layer, (96, 96, 96), (rect.left, rect.bottom - 1), (rect.right - 1, rect.bottom - 1))
            pygame.draw.line(layer, (96, 96, 96), (rect.right - 1, rect.top), (rect.right - 1, rect.bottom - 1))
            button_font = pygame.font.SysFont("Arial", 11, bold=True)
            button_surface = button_font.render(label, True, (0, 0, 0))
            layer.blit(button_surface, button_surface.get_rect(center=rect.center))

        if panel_w >= 420:
            button_w, button_h = 82, 26
            button_x = panel_w - 100
            ok_local = pygame.Rect(button_x, 54, button_w, button_h)
            cancel_local = pygame.Rect(button_x, 91, button_w, button_h)
        else:
            button_w, button_h = 58, 22
            button_x = panel_w - button_w - 8
            ok_local = pygame.Rect(button_x, 49, button_w, button_h)
            cancel_local = pygame.Rect(button_x, 76, button_w, button_h)
        draw_button(ok_local, "OK")
        draw_button(cancel_local, "Отмена")

        if panel_w >= 420:
            label_font = pygame.font.SysFont("Arial", 13, bold=False)
            label_surface = label_font.render("PIN-код:", True, (0, 0, 0))
            layer.blit(label_surface, (101, slots_y + max(4, (slot_h - label_surface.get_height()) // 2)))

        # Use the archive dialog's short confirmation message and keyboard equivalents.
        footer_color = (150, 25, 25) if error_active else (0, 0, 0)
        footer_text = (
            "ДОСТУП ОТКЛОНЁН · ПОВТОРИТЕ ВВОД" if error_active else
            "Нажмите OK для подтверждения."
        )
        footer_font = pygame.font.SysFont("Arial", 12 if panel_w >= 420 else 9, bold=False)
        footer_surface = footer_font.render(footer_text, True, footer_color)
        footer_y = 165 if panel_h >= 190 else panel_h - 12
        if panel_w >= 420:
            layer.blit(footer_surface, (101, footer_y))
        else:
            if footer_surface.get_width() > panel_w - 16:
                footer_surface = pygame.font.SysFont("Arial", 8, bold=False).render(footer_text, True, footer_color)
            layer.blit(footer_surface, footer_surface.get_rect(center=(panel_w // 2, footer_y)))

        scaled = pygame.transform.scale(layer, (draw_w, draw_h))
        scaled.set_alpha(max(0, min(255, int(255 * visibility))))
        actual_rect = scaled.get_rect(
            center=(final_panel.centerx + shake_x,
                    final_panel.centery + int((1.0 - opening_ease) * 14))
        )
        shadow = pygame.Surface((draw_w + 10, draw_h + 10), pygame.SRCALPHA)
        pygame.draw.rect(
            shadow, (0, 0, 0, int(105 * visibility)),
            pygame.Rect(4, 4, draw_w, draw_h),
        )
        surface.blit(shadow, (actual_rect.x - 4, actual_rect.y + 1))
        surface.blit(scaled, actual_rect)
        self.secret_input_rect = actual_rect

        hit_scale_x = draw_w / max(1, panel_w)
        hit_scale_y = draw_h / max(1, panel_h)
        def to_screen_rect(local_rect):
            return pygame.Rect(
                actual_rect.x + int(local_rect.x * hit_scale_x),
                actual_rect.y + int(local_rect.y * hit_scale_y),
                max(1, int(local_rect.width * hit_scale_x)),
                max(1, int(local_rect.height * hit_scale_y)),
            )
        self.secret_input_close_rect = to_screen_rect(close_local)
        self.secret_input_ok_rect = to_screen_rect(ok_local)
        self.secret_input_cancel_rect = to_screen_rect(cancel_local)

    def _open_event_collection(self):
        if not self.event_collection_unlocked or self.event_collection_open:
            return False
        self.event_collection_open = True
        self.event_collection_opened_at = time.monotonic()
        self.event_collection_closing = False
        self.event_collection_closing_started_at = 0.0
        return True

    def _close_event_collection(self):
        if self.event_collection_open and not self.event_collection_closing:
            self.event_collection_closing = True
            self.event_collection_closing_started_at = time.monotonic()

    def _draw_event_collection_icon(self, surface):
        if not self.event_collection_unlocked:
            self.event_collection_icon_rect = None
            return
        width, height = surface.get_size()
        game = self.game_view
        occupied = []
        for name in (
            "rect_back", "rect_target", "rect_phrase_btn", "rect_pbar",
            "rect_wallpaper", "rect_lore_icon", "rect_instant_wash",
            "rect_free_wash_btn", "rect_name_entry_btn", "lore_win_rect",
        ):
            rect = getattr(game, name, None)
            if rect is not None:
                occupied.append((rect.x, rect.y, rect.width, rect.height))
        for rect in getattr(game, "rect_sectors", ()):
            if rect is not None:
                occupied.append((rect.x, rect.y, rect.width, rect.height))
        # Reserve the existing lower-right status/notification area as well.
        occupied.append((max(0, width - 520), max(0, height - 62), min(520, width), 62))
        chosen = choose_event_collection_icon_rect((width, height), occupied, icon_size=42, margin=18)
        if chosen is None:
            self.event_collection_icon_rect = None
            return
        rect = pygame.Rect(*chosen)
        self.event_collection_icon_rect = rect

        now = time.monotonic()
        pulse = 0.5 + 0.5 * math.sin(now * 3.8)
        halo = pygame.Surface((rect.width + 18, rect.height + 18), pygame.SRCALPHA)
        pygame.draw.rect(halo, (0, 255, 105, int(28 + 44 * pulse)), (4, 4, rect.width + 10, rect.height + 10), 5)
        surface.blit(halo, (rect.x - 9, rect.y - 9))
        pygame.draw.rect(surface, (4, 18, 25), rect)
        pygame.draw.rect(surface, (0, 210, 95), rect, 2)
        pygame.draw.rect(surface, (35, 105, 122), rect.inflate(-8, -8), 1)
        # Pixel book glyph; the old wallpaper and lore shortcuts retain their own slots.
        pygame.draw.rect(surface, (160, 225, 255), (rect.x + 10, rect.y + 9, 9, 24))
        pygame.draw.rect(surface, (195, 245, 255), (rect.x + 21, rect.y + 9, 10, 24))
        pygame.draw.rect(surface, (4, 30, 42), (rect.x + 18, rect.y + 9, 4, 24))
        pygame.draw.line(surface, (20, 90, 110), (rect.x + 12, rect.y + 15), (rect.x + 17, rect.y + 15), 1)
        pygame.draw.line(surface, (20, 90, 110), (rect.x + 23, rect.y + 15), (rect.x + 29, rect.y + 15), 1)

    def _draw_event_collection_window(self, surface):
        width, height = surface.get_size()
        now = time.monotonic()
        opening_t = min(1.0, max(0.0, (now - self.event_collection_opened_at) / 0.30))
        opening_ease = 1.0 - (1.0 - opening_t) ** 3
        closing_t = 0.0
        if self.event_collection_closing:
            closing_t = min(1.0, max(0.0, (now - self.event_collection_closing_started_at) / 0.22))
        visibility = opening_ease * (1.0 - closing_t)
        if self.event_collection_closing and closing_t >= 1.0:
            self.event_collection_open = False
            self.event_collection_closing = False
            self.event_collection_window_rect = None
            self.event_collection_close_rect = None
            return

        shade = pygame.Surface((width, height), pygame.SRCALPHA)
        shade.fill((0, 0, 0, int(118 * visibility)))
        surface.blit(shade, (0, 0))

        # Compact two-column archive: all 12 entries remain visible at once.
        panel_w = min(760, max(280, width - 36))
        panel_h = min(520, max(280, height - 36))
        if panel_w > width - 12:
            panel_w = width - 12
        if panel_h > height - 12:
            panel_h = height - 12
        final_panel = pygame.Rect((width - panel_w) // 2, (height - panel_h) // 2, panel_w, panel_h)
        scale = 0.90 + 0.10 * visibility
        draw_w, draw_h = max(1, int(panel_w * scale)), max(1, int(panel_h * scale))
        layer = pygame.Surface((panel_w, panel_h), pygame.SRCALPHA)

        # Windows 95 shell with restrained arcade status accents.
        layer.fill((192, 192, 192, 255))
        pygame.draw.rect(layer, (255, 255, 255), (0, 0, panel_w, panel_h), 2)
        pygame.draw.line(layer, (255, 255, 255), (2, 2), (panel_w - 3, 2), 1)
        pygame.draw.line(layer, (255, 255, 255), (2, 2), (2, panel_h - 3), 1)
        pygame.draw.line(layer, (64, 64, 64), (2, panel_h - 3), (panel_w - 3, panel_h - 3), 1)
        pygame.draw.line(layer, (64, 64, 64), (panel_w - 3, 2), (panel_w - 3, panel_h - 3), 1)

        title_bar = pygame.Rect(4, 4, panel_w - 8, 30)
        pygame.draw.rect(layer, (0, 0, 128), title_bar)
        # Pixel archive icon.
        pygame.draw.rect(layer, (192, 192, 192), (10, 10, 15, 17))
        pygame.draw.rect(layer, (0, 0, 0), (10, 10, 15, 17), 1)
        pygame.draw.line(layer, (0, 0, 128), (17, 12), (17, 25), 2)
        pygame.draw.line(layer, (0, 0, 128), (12, 16), (15, 16), 1)
        pygame.draw.line(layer, (0, 0, 128), (19, 16), (23, 16), 1)
        title_font = pygame.font.SysFont("Arial", 16 if panel_w >= 440 else 12, bold=True)
        title_text = "PALCHIK.EXE — КОЛЛЕКЦИЯ СОБЫТИЙ" if panel_w >= 440 else "КОЛЛЕКЦИЯ СОБЫТИЙ"
        title = title_font.render(title_text, True, (255, 255, 255))
        layer.blit(title, (32, 10))

        close_local = pygame.Rect(panel_w - 27, 9, 18, 18)
        pygame.draw.rect(layer, (192, 192, 192), close_local)
        pygame.draw.line(layer, (255, 255, 255), close_local.topleft, (close_local.right - 1, close_local.top), 2)
        pygame.draw.line(layer, (255, 255, 255), close_local.topleft, (close_local.left, close_local.bottom - 1), 2)
        pygame.draw.line(layer, (64, 64, 64), (close_local.left, close_local.bottom - 1), (close_local.right - 1, close_local.bottom - 1), 2)
        pygame.draw.line(layer, (64, 64, 64), (close_local.right - 1, close_local.top), (close_local.right - 1, close_local.bottom - 1), 2)
        close_glyph = pygame.font.SysFont("Arial", 12, bold=True).render("X", True, (0, 0, 0))
        layer.blit(close_glyph, close_glyph.get_rect(center=close_local.center))

        found_count = sum(
            1 for item_id, _ in EVENT_COLLECTION_ITEMS
            if self.event_collection_progress.get(item_id, {}).get("found")
            or self.event_collection_progress.get(item_id, {}).get("completed")
        )
        completed_count = sum(
            1 for item_id, _ in EVENT_COLLECTION_ITEMS
            if self.event_collection_progress.get(item_id, {}).get("completed")
        )
        summary_text = (
            f"НАЙДЕНО: {found_count:02d}/{len(EVENT_COLLECTION_ITEMS):02d}     ПРОЙДЕНО: {completed_count:02d}/{len(EVENT_COLLECTION_ITEMS):02d}"
            if panel_w >= 520 else
            f"НАЙДЕНО {found_count:02d}/{len(EVENT_COLLECTION_ITEMS):02d}  |  ПРОЙДЕНО {completed_count:02d}/{len(EVENT_COLLECTION_ITEMS):02d}"
        )
        summary_font = pygame.font.SysFont("Courier New", 12 if panel_w >= 520 else 9, bold=True)
        summary = summary_font.render(summary_text, True, (0, 0, 96))
        layer.blit(summary, (18, 45))

        # Progress meter and short archive hint.
        meter = pygame.Rect(18, 65, panel_w - 36, 7)
        pygame.draw.rect(layer, (96, 96, 96), meter)
        if len(EVENT_COLLECTION_ITEMS):
            fill_w = int((meter.width - 2) * (found_count / len(EVENT_COLLECTION_ITEMS)))
            if fill_w > 0:
                pygame.draw.rect(layer, (0, 128, 0), (meter.x + 1, meter.y + 1, fill_w, meter.height - 2))
        hint_font = pygame.font.SysFont("Arial", 10)
        hint_text = "СОБЫТИЕ ПОЯВИТСЯ В АРХИВЕ ПОСЛЕ ОБНАРУЖЕНИЯ" if panel_w >= 420 else "АРХИВ ОБНОВЛЯЕТСЯ ПРИ ОБНАРУЖЕНИИ"
        hint = hint_font.render(hint_text, True, (55, 55, 55))
        layer.blit(hint, (18, 79))

        # Use two columns on normal displays and three shorter columns when
        # vertical space is limited; all 12 entries stay inside the window.
        compact_grid = panel_h < 390
        columns = 3 if compact_grid else 2
        rows_per_column = 4 if compact_grid else 6
        col_gap = 10 if compact_grid else 12
        usable_width = max(1, panel_w - 36 - col_gap * (columns - 1))
        col_w = max(1, usable_width // columns)
        top = 101
        footer_y = panel_h - 20
        available_h = max(1, footer_y - top - 9)
        row_h = min(62, max(27, available_h // rows_per_column))
        card_h = max(23, row_h - 3)
        name_size = 12 if col_w >= 250 else (10 if col_w >= 125 else 8)
        status_size = 10 if col_w >= 250 else (8 if col_w >= 125 else 7)
        name_font = pygame.font.SysFont("Courier New", name_size, bold=True)
        status_font = pygame.font.SysFont("Courier New", status_size, bold=True)

        for index, (item_id, item_name) in enumerate(EVENT_COLLECTION_ITEMS):
            col = index // rows_per_column
            row = index % rows_per_column
            item_rect = pygame.Rect(
                18 + col * (col_w + col_gap),
                top + row * row_h,
                col_w,
                card_h,
            )
            item_progress = min(1.0, max(0.0, (now - self.event_collection_opened_at - 0.05 - index * 0.035) / 0.22))
            item_ease = 1.0 - (1.0 - item_progress) ** 2
            if item_ease <= 0:
                continue
            shown_rect = item_rect.move(0, int((1.0 - item_ease) * 11))
            progress = self.event_collection_progress.get(item_id, {})
            completed = bool(progress.get("completed", False))
            found = bool(progress.get("found", False)) or completed

            card_bg = (205, 225, 205) if completed else ((215, 228, 240) if found else (192, 192, 192))
            pygame.draw.rect(layer, card_bg, shown_rect)
            pygame.draw.line(layer, (255, 255, 255), shown_rect.topleft, (shown_rect.right - 1, shown_rect.top), 2)
            pygame.draw.line(layer, (255, 255, 255), shown_rect.topleft, (shown_rect.left, shown_rect.bottom - 1), 2)
            pygame.draw.line(layer, (96, 96, 96), (shown_rect.left, shown_rect.bottom - 1), (shown_rect.right - 1, shown_rect.bottom - 1), 2)
            pygame.draw.line(layer, (96, 96, 96), (shown_rect.right - 1, shown_rect.top), (shown_rect.right - 1, shown_rect.bottom - 1), 2)

            status_text, status_color = (
                ("ПРОЙДЕНО", (0, 105, 35)) if completed else
                (("НАЙДЕНО · ЕЩЁ НЕ ПРОЙДЕНО", (0, 75, 125)) if found else ("НЕ НАЙДЕНО", (80, 80, 80)))
            )
            indicator_color = (0, 150, 45) if completed else ((0, 105, 180) if found else (110, 110, 110))
            compact_card = shown_rect.height < 30
            indicator_size = 5 if compact_card else 7
            indicator_x = shown_rect.x + (5 if compact_card else 7)
            indicator_y = shown_rect.y + (5 if compact_card else 8)
            pygame.draw.rect(layer, indicator_color, (indicator_x, indicator_y, indicator_size, indicator_size))
            name_color = (15, 25, 35) if found else (75, 75, 75)
            name_surface = name_font.render(item_name, True, name_color)
            name_left = shown_rect.x + (13 if compact_card else 19)
            if name_surface.get_width() > shown_rect.width - (name_left - shown_rect.x) - 5:
                name_surface = pygame.font.SysFont("Arial", max(7, name_size - 1), bold=True).render(item_name, True, name_color)
            name_y = shown_rect.y + (3 if compact_card else 5)
            layer.blit(name_surface, (name_left, name_y))
            status_surface = status_font.render(status_text, True, status_color)
            if status_surface.get_width() > shown_rect.width - 10:
                status_surface = pygame.font.SysFont("Arial", max(7, status_size - 1), bold=True).render(status_text, True, status_color)
            status_bottom_pad = 2 if compact_card else 4
            layer.blit(status_surface, (shown_rect.x + 5, shown_rect.bottom - status_surface.get_height() - status_bottom_pad))

        footer = pygame.font.SysFont("Courier New", 10, bold=True).render(
            "ESC / X — ЗАКРЫТЬ АРХИВ", True, (35, 35, 80)
        )
        layer.blit(footer, footer.get_rect(center=(panel_w // 2, footer_y)))

        # Animated arcade scan marker along the inner bottom edge.
        if visibility > 0.45:
            scan_span = max(1, panel_w - 30)
            scan_x = 12 + int((now * 125) % scan_span)
            pygame.draw.line(layer, (0, 125, 45), (scan_x, panel_h - 5), (min(panel_w - 8, scan_x + 18), panel_h - 5), 2)

        scaled = pygame.transform.scale(layer, (draw_w, draw_h))
        scaled.set_alpha(max(0, min(255, int(255 * visibility))))
        actual_rect = scaled.get_rect(
            center=(final_panel.centerx, final_panel.centery + int((1.0 - opening_ease) * 16))
        )
        shadow = pygame.Surface((draw_w + 10, draw_h + 10), pygame.SRCALPHA)
        pygame.draw.rect(
            shadow, (0, 0, 0, int(100 * visibility)),
            pygame.Rect(4, 4, draw_w, draw_h),
        )
        surface.blit(shadow, (actual_rect.x - 4, actual_rect.y + 1))
        surface.blit(scaled, actual_rect)
        self.event_collection_window_rect = final_panel
        self.event_collection_close_rect = pygame.Rect(
            actual_rect.x + int(close_local.x * scale),
            actual_rect.y + int(close_local.y * scale),
            max(1, int(close_local.width * scale)),
            max(1, int(close_local.height * scale)),
        )

    def _draw_admin_panel(self, surface):
        self.admin_button_rects = {}
        self.admin_tab_rects = {}
        if not self.admin_panel_open:
            return

        w, h = surface.get_size()
        shade = pygame.Surface((w, h), pygame.SRCALPHA)
        shade.fill((0, 0, 0, 150))
        surface.blit(shade, (0, 0))

        panel_w = min(720, w - 32)
        panel_h = min(752 if self.admin_panel_tab == "events" else 620 if self.admin_panel_tab == "logs" else 500, h - 16)
        panel = pygame.Rect((w - panel_w) // 2, (h - panel_h) // 2, panel_w, panel_h)
        self.admin_panel_rect = panel
        pygame.draw.rect(surface, (0, 0, 0), panel.move(5, 6))
        pygame.draw.rect(surface, (192, 192, 192), panel)
        pygame.draw.rect(surface, (255, 255, 255), panel, 2)
        pygame.draw.rect(surface, (128, 128, 128), panel, 1)

        title_rect = pygame.Rect(panel.x + 3, panel.y + 3, panel.width - 6, 30)
        pygame.draw.rect(surface, (0, 0, 128), title_rect)
        title_font = pygame.font.SysFont("Arial", 18, bold=True)
        title = title_font.render("PALCHIK - ADMIN PANEL", True, (255, 255, 255))
        surface.blit(title, (title_rect.x + 10, title_rect.y + 5))

        tabs = [
            ("overview", "ОБЗОР"),
            ("phases", "ФАЗЫ"),
            ("minigames", "МИНИ-ИГРЫ"),
            ("events", "СОБЫТИЯ"),
            ("shop", "МАГАЗИН"),
            ("debug", "ОТЛАДКА"),
            ("logs", "ЖУРНАЛ"),
        ]
        tab_gap = 5
        tab_left = panel.x + 14
        tab_top = panel.y + 42
        tab_width = (panel.width - 28 - tab_gap * (len(tabs) - 1)) // len(tabs)
        tab_font = pygame.font.SysFont("Arial", 14, bold=True)
        for index, (tab_id, label) in enumerate(tabs):
            rect = pygame.Rect(tab_left + index * (tab_width + tab_gap), tab_top, tab_width, 32)
            self.admin_tab_rects[tab_id] = rect
            selected = self.admin_panel_tab == tab_id
            fill = (0, 0, 128) if selected else (212, 208, 200)
            text_color = (255, 255, 255) if selected else (25, 25, 25)
            pygame.draw.rect(surface, (80, 80, 80), rect.move(1, 2))
            pygame.draw.rect(surface, fill, rect)
            pygame.draw.line(surface, (255, 255, 255), rect.topleft, (rect.right - 1, rect.top), 2)
            pygame.draw.line(surface, (255, 255, 255), rect.topleft, (rect.left, rect.bottom - 1), 2)
            pygame.draw.line(surface, (80, 80, 80), (rect.left, rect.bottom - 1), (rect.right - 1, rect.bottom - 1), 2)
            label_surface = tab_font.render(label, True, text_color)
            surface.blit(label_surface, label_surface.get_rect(center=rect.center))

        body_left = panel.x + 20
        body_top = panel.y + 92
        body_width = panel.width - 40
        body_bottom = panel.bottom - 62
        body_height = body_bottom - body_top
        body = pygame.Rect(body_left, body_top, body_width, body_height)
        pygame.draw.rect(surface, (245, 245, 245), body)
        pygame.draw.rect(surface, (128, 128, 128), body, 1)

        heading_font = pygame.font.SysFont("Arial", 20, bold=True)
        text_font = pygame.font.SysFont("Arial", 16)
        small_font = pygame.font.SysFont("Arial", 14)
        button_font = pygame.font.SysFont("Arial", 16, bold=True)
        heading_by_tab = {
            "overview": "СОСТОЯНИЕ ИГРЫ",
            "phases": "ТЕСТИРОВАНИЕ ФАЗ",
            "minigames": "ЗАПУСК МИНИ-ИГР",
            "events": "ТЕСТИРОВАНИЕ СОБЫТИЙ",
            "shop": "МАГАЗИН",
            "debug": "ОТЛАДОЧНЫЕ ИНСТРУМЕНТЫ",
            "logs": "ЖУРНАЛ ОШИБОК И СОБЫТИЙ",
        }
        heading_surface = heading_font.render(heading_by_tab[self.admin_panel_tab], True, (20, 30, 55))
        surface.blit(heading_surface, (body.x + 18, body.y + 14))
        pygame.draw.line(surface, (190, 190, 190),
                         (body.x + 18, body.y + 46), (body.right - 18, body.y + 46), 1)

        def draw_button(action, label, column, row, enabled=True, top_offset=62, row_height=52, button_height=40):
            gap_x = 12
            left = body.x + 18
            col_width = (body.width - 36 - gap_x) // 2
            top = body.y + top_offset
            rect = pygame.Rect(left + column * (col_width + gap_x), top + row * row_height, col_width, button_height)
            self.admin_button_rects[action] = rect
            fill = (212, 208, 200) if enabled else (175, 175, 175)
            text_color = (20, 20, 20) if enabled else (95, 95, 95)
            pygame.draw.rect(surface, (90, 90, 90), rect.move(2, 2))
            pygame.draw.rect(surface, fill, rect)
            pygame.draw.line(surface, (255, 255, 255), rect.topleft, (rect.right - 1, rect.top), 2)
            pygame.draw.line(surface, (255, 255, 255), rect.topleft, (rect.left, rect.bottom - 1), 2)
            pygame.draw.line(surface, (80, 80, 80), (rect.left, rect.bottom - 1), (rect.right - 1, rect.bottom - 1), 2)
            pygame.draw.line(surface, (80, 80, 80), (rect.right - 1, rect.top), (rect.right - 1, rect.bottom - 1), 2)
            rendered = button_font.render(label, True, text_color)
            if rendered.get_width() > rect.width - 12:
                rendered = small_font.render(label, True, text_color)
            surface.blit(rendered, rendered.get_rect(center=rect.center))

        def draw_wrapped_text(text, x, y, max_width, font, color, max_lines=2):
            words = str(text).split()
            lines = []
            line = ""
            for word in words:
                candidate = word if not line else line + " " + word
                if font.size(candidate)[0] <= max_width or not line:
                    line = candidate
                else:
                    lines.append(line)
                    line = word
            if line:
                lines.append(line)
            line_height = font.get_linesize() + 1
            for line_index, line_text in enumerate(lines[:max_lines]):
                rendered = font.render(line_text, True, color)
                surface.blit(rendered, (x, y + line_index * line_height))

        phase_enabled = self._admin_phase_controls_available()
        game_enabled = phase_enabled

        if self.admin_panel_tab == "overview":
            player_name = (self.player_name or "—").strip() or "—"
            phase_name = self.game_logic.get_phase() if self.current_screen == "game" else "МЕНЮ"
            info_lines = [
                f"Профиль: {player_name[:28]}",
                f"Состояние: {phase_name}",
                f"Очки: {self.game_logic.score:,}    Всего кликов: {self.game_logic.total_clicks:,}",
            ]
            for index, line in enumerate(info_lines):
                rendered = text_font.render(line, True, (35, 35, 35))
                surface.blit(rendered, (body.x + 20, body.y + 62 + index * 28))
            draw_button("new_game", "НОВАЯ ИГРА С НАЧАЛА", 0, 2, True)
            draw_button("menu", "В ГЛАВНОЕ МЕНЮ", 1, 2, True)

        elif self.admin_panel_tab == "phases":
            phase_buttons = [
                ("phase_0", "ФАЗА 0 · 0"),
                ("phase_1", "ФАЗА 1 · 1500"),
                ("phase_2", "ФАЗА 2 · 2000"),
                ("phase_3", "ФАЗА 3 · 2500"),
                ("phase_4", "ФАЗА 4 · 2800"),
                ("final", "ФИНАЛ · 3000"),
            ]
            for index, (action, label) in enumerate(phase_buttons):
                draw_button(action, label, index % 2, index // 2, phase_enabled)

        elif self.admin_panel_tab == "minigames":
            registry = self._admin_minigame_registry()
            note = small_font.render(
                "Запускаются штатные игровые сценарии; после запуска панель закроется.",
                True, (55, 55, 55),
            )
            surface.blit(note, (body.x + 20, body.y + 54))
            game_items = list(registry.items())
            for index, (game_id, definition) in enumerate(game_items):
                column = index % 2
                row = index // 2
                draw_button(
                    f"minigame_{game_id}", definition["label"],
                    column, row, game_enabled, top_offset=82, row_height=86,
                )
                col_width = (body.width - 36 - 12) // 2
                description_x = body.x + 18 + column * (col_width + 12) + 2
                description_y = body.y + 82 + row * 86 + 44
                draw_wrapped_text(
                    definition["description"], description_x, description_y,
                    col_width - 10, small_font, (65, 65, 65), max_lines=2,
                )
            # Keep the reset action aligned beside the third mini-game, not alone below it.
            draw_button(
                "minigame_reset", "СБРОСИТЬ ТЕСТ", 1, 1, game_enabled,
                top_offset=82, row_height=86,
            )

        elif self.admin_panel_tab == "events":
            definition = self._admin_event_registry()["EVT_001_ROACH_ATTACK"]
            draw_wrapped_text(
                "EVT_001_ROACH_ATTACK · " + definition["label"],
                body.x + 20, body.y + 56, body.width - 40,
                small_font, (45, 45, 45), max_lines=1,
            )
            draw_wrapped_text(
                definition["description"],
                body.x + 20, body.y + 76, body.width - 40,
                small_font, (65, 65, 65), max_lines=2,
            )
            draw_button("event_trigger_EVT_001_ROACH_ATTACK", "TRIGGER", 0, 0, game_enabled, top_offset=118, row_height=54)
            draw_button("event_stop_EVT_001_ROACH_ATTACK", "STOP", 1, 0, True, top_offset=118, row_height=54)
            draw_button("event_reset_EVT_001_ROACH_ATTACK", "RESET", 0, 1, True, top_offset=118, row_height=54)
            draw_button("event_inspect_EVT_001_ROACH_ATTACK", "INSPECT", 1, 1, True, top_offset=118, row_height=54)
            inspect_text = self._managed_event_inspect(
                "EVT_001_ROACH_ATTACK", self.game_logic.inspect_roach_attack()
            )
            self.admin_event_inspect_text = inspect_text
            draw_wrapped_text(
                inspect_text, body.x + 20, body.y + 222, body.width - 40,
                small_font, (45, 45, 45), max_lines=2,
            )
            pygame.draw.line(surface, (190, 190, 190),
                             (body.x + 18, body.y + 252), (body.right - 18, body.y + 252), 1)
            definition_2 = self._admin_event_registry()["EVT_002_WORD_SHOCK"]
            draw_wrapped_text("EVT_002_WORD_SHOCK · " + definition_2["label"],
                              body.x + 20, body.y + 258, body.width - 40,
                              small_font, (45, 45, 45), max_lines=1)
            draw_wrapped_text(definition_2["description"],
                              body.x + 20, body.y + 278, body.width - 40,
                              small_font, (65, 65, 65), max_lines=1)
            draw_button("event_trigger_EVT_002_WORD_SHOCK", "TRIGGER", 0, 0, game_enabled, top_offset=300, row_height=44)
            draw_button("event_stop_EVT_002_WORD_SHOCK", "STOP", 1, 0, True, top_offset=300, row_height=44)

            definition_3 = self._admin_event_registry()["EVT_003_PLEASE_DONT_TOUCH"]
            draw_wrapped_text(
                "EVT_003_PLEASE_DONT_TOUCH · " + definition_3["label"],
                body.x + 20, body.y + 346, body.width - 40,
                small_font, (45, 45, 45), max_lines=1,
            )
            draw_wrapped_text(
                "REAL TRIGGER расходует попытку фазы. SANDBOX можно повторять без изменения сохранений.",
                body.x + 20, body.y + 366, body.width - 40,
                small_font, (65, 65, 65), max_lines=2,
            )
            current_phase = self.game_logic.get_phase()
            phase_used = self.evt003_runtime.ledger.has_attempted_phase(current_phase)
            real_allowed, real_reason = self.evt003_runtime.can_start(current_phase)
            real_enabled = game_enabled and self.evt003_state is None and real_allowed
            draw_button(
                "event_trigger_EVT_003_PLEASE_DONT_TOUCH", "REAL TRIGGER",
                0, 0, real_enabled, top_offset=408, row_height=44,
            )
            real_reason_text = (
                f"Реальная попытка в {current_phase} уже использована." if phase_used
                else (f"Недоступно: {real_reason}" if real_reason else "Реальный запуск расходует попытку и применяет последствия.")
            )
            draw_wrapped_text(real_reason_text, body.x + 20, body.y + 452, body.width - 40,
                              small_font, (125, 55, 45) if phase_used else (65, 65, 65), max_lines=1)
            pygame.draw.line(surface, (190, 190, 190),
                             (body.x + 18, body.y + 472), (body.right - 18, body.y + 472), 1)
            col_width = (body.width - 36 - 12) // 2
            draw_wrapped_text("SANDBOX · TEST PHASES · ESC CANCEL",
                              body.x + 20, body.y + 477, col_width - 8,
                              small_font, (25, 65, 45), max_lines=1)
            draw_button(
                "event_reset_sandbox_EVT_003_PLEASE_DONT_TOUCH", "RESET TEST DATA",
                1, 0, True, top_offset=474, row_height=26, button_height=24,
            )
            sandbox_phases = (
                ("phase_0", "TEST PHASE 0"), ("phase_1", "TEST PHASE 1"),
                ("phase_2", "TEST PHASE 2"), ("phase_3", "TEST PHASE 3"),
                ("phase_4", "TEST PHASE 4"), ("final", "TEST FINAL"),
            )
            for index, (phase_id, label) in enumerate(sandbox_phases):
                sandbox_allowed, _sandbox_reason = self.evt003_runtime.can_start(phase_id, sandbox=True)
                enabled = game_enabled and self.evt003_state is None and sandbox_allowed
                draw_button(
                    "event_test_EVT_003_PLEASE_DONT_TOUCH_" + phase_id, label,
                    index % 2, index // 2, enabled, top_offset=502, row_height=30, button_height=26,
                )

        elif self.admin_panel_tab == "logs":
            draw_button("logs_open_file", "ОТКРЫТЬ PALCHIK.LOG", 0, 0, True, top_offset=62)
            path_text = "Файл: " + str(self.log_file_path)
            draw_wrapped_text(path_text, body.x + 20, body.y + 108, body.width - 40,
                              small_font, (55, 55, 55), max_lines=2)
            entries = get_recent_log_entries(6, minimum_level="WARNING")
            if not entries:
                draw_wrapped_text("Ошибок и предупреждений в текущем сеансе пока нет.",
                                  body.x + 20, body.y + 158, body.width - 40,
                                  text_font, (55, 85, 60), max_lines=2)
            else:
                draw_wrapped_text("ПОСЛЕДНИЕ ПРЕДУПРЕЖДЕНИЯ И ОШИБКИ:",
                                  body.x + 20, body.y + 158, body.width - 40,
                                  small_font, (35, 35, 35), max_lines=1)
                y = body.y + 183
                for entry in reversed(entries):
                    color = (150, 35, 35) if entry["level"] in ("ERROR", "CRITICAL") else (120, 90, 35)
                    line = f"{entry['time']} [{entry['level']}] {entry['logger']}: {entry['message']}"
                    draw_wrapped_text(line, body.x + 20, y, body.width - 40,
                                      small_font, color, max_lines=2)
                    y += 38
            draw_wrapped_text("Полные traceback находятся в palchik.log и его ротационных копиях.",
                              body.x + 20, body.bottom - 34, body.width - 40,
                              small_font, (65, 65, 65), max_lines=1)

        elif self.admin_panel_tab == "shop":
            shop_lines = [
                "РАЗДЕЛ ПОДГОТОВЛЕН ДЛЯ БУДУЩЕГО МАГАЗИНА.",
                "Здесь будут подключены каталог товаров, валюта, покупки",
                "и инвентарь игрока. Функции пока не реализованы.",
            ]
            for index, line in enumerate(shop_lines):
                rendered = text_font.render(line, True, (45, 45, 45))
                surface.blit(rendered, (body.x + 22, body.y + 72 + index * 30))

        elif self.admin_panel_tab == "debug":
            draw_button("debug", "ОТЛАДКА: " + ("ВКЛ" if self.debug_mode else "ВЫКЛ"), 0, 0, True)
            draw_button("effects", "ЭФФЕКТЫ: " + ("ВКЛ" if self.effects_enabled else "ВЫКЛ"), 1, 0, True)
            draw_button("profiler", "ПРОФИЛИРОВАНИЕ 10 СЕК", 0, 1, True)
            draw_button("secret_force_open", "ОТКРЫТЬ ПОЛЕ", 1, 1, True)
            draw_button("secret_test_success", "ТЕСТ: ВЕРНЫЙ КОД", 0, 2, True)
            draw_button("secret_test_failure", "ТЕСТ: ОШИБКА", 1, 2, True)
            draw_button("secret_clear_input", "СБРОСИТЬ ПОЛЕ", 0, 3, True)
            draw_button("secret_reset_collection", "СБРОСИТЬ ДОСТУП", 1, 3, True)
            state_text = (
                f"Фиксированный код: {SECRET_ACCESS_CODE} | Поле: {'ОТКРЫТО' if self.secret_input_open else 'ЗАКРЫТО'} | "
                f"Коллекция: {'ОТКРЫТА' if self.event_collection_unlocked else 'ЗАКРЫТА'}"
            )
            draw_wrapped_text(state_text, body.x + 20, body.y + 286, body.width - 40,
                              small_font, (45, 45, 45), max_lines=2)

        close_rect = pygame.Rect(panel.right - 174, panel.bottom - 48, 154, 34)
        self.admin_button_rects["close"] = close_rect
        pygame.draw.rect(surface, (90, 90, 90), close_rect.move(2, 2))
        pygame.draw.rect(surface, (212, 208, 200), close_rect)
        pygame.draw.line(surface, (255, 255, 255), close_rect.topleft, (close_rect.right - 1, close_rect.top), 2)
        pygame.draw.line(surface, (255, 255, 255), close_rect.topleft, (close_rect.left, close_rect.bottom - 1), 2)
        pygame.draw.line(surface, (80, 80, 80), (close_rect.left, close_rect.bottom - 1), (close_rect.right - 1, close_rect.bottom - 1), 2)
        pygame.draw.line(surface, (80, 80, 80), (close_rect.right - 1, close_rect.top), (close_rect.right - 1, close_rect.bottom - 1), 2)
        close_text = button_font.render("ЗАКРЫТЬ", True, (20, 20, 20))
        surface.blit(close_text, close_text.get_rect(center=close_rect.center))

        footer = small_font.render("F2 / ESC · закрыть панель", True, (45, 45, 45))
        surface.blit(footer, (panel.x + 18, panel.bottom - 43))

    def _handle_admin_panel_event(self, event):
        if not self.admin_panel_open or event.type != pygame.MOUSEBUTTONDOWN or event.button != 1:
            return False
        screen_w, screen_h = self.screen.get_size()
        tex_w, tex_h = self.screen_texture.size
        pos = (int(event.pos[0] * tex_w / max(1, screen_w)),
               int(event.pos[1] * tex_h / max(1, screen_h)))
        if self.admin_panel_rect and not self.admin_panel_rect.collidepoint(pos):
            return True

        for tab_id, rect in self.admin_tab_rects.items():
            if rect.collidepoint(pos):
                self.admin_panel_tab = tab_id
                return True

        for action, rect in self.admin_button_rects.items():
            if not rect.collidepoint(pos):
                continue
            if action == "close":
                self.admin_panel_open = False
            elif action == "new_game":
                self._admin_start_new_game()
            elif action == "menu":
                if self.game_logic.word_shock_active or self.event_lifecycle.is_tracked("EVT_002_WORD_SHOCK"):
                    self._cancel_managed_word_shock(reason="RETURN_TO_MENU")
                if self.game_logic.roach_attack_active or self.event_lifecycle.is_tracked("EVT_001_ROACH_ATTACK"):
                    self._cancel_managed_roach_attack(reason="RETURN_TO_MENU")
                else:
                    self._stop_roach_audio()
                self.admin_panel_open = False
                self.intro_slides_active = False
                self.name_entry_active = False
                self.name_input_scene = None
                self.current_screen = "menu"
                self.audio_box.stop_music()
                self.audio_box.play_menu_music()
            elif action.startswith("phase_") or action == "final":
                if not self._admin_phase_controls_available():
                    return True
                phase_clicks = {
                    "phase_0": 0, "phase_1": 1500, "phase_2": 2000,
                    "phase_3": 2500, "phase_4": 2800, "final": 3000,
                }
                self._admin_set_phase(phase_clicks[action])
            elif action.startswith("minigame_"):
                if not self._admin_phase_controls_available():
                    return True
                game_id = action[len("minigame_"):]
                if game_id == "reset":
                    self._admin_reset_minigame()
                else:
                    self._admin_launch_minigame(game_id)
            elif action == "event_trigger_EVT_001_ROACH_ATTACK":
                self._admin_trigger_event("EVT_001_ROACH_ATTACK")
            elif action == "event_stop_EVT_001_ROACH_ATTACK":
                self._admin_stop_event("EVT_001_ROACH_ATTACK")
            elif action == "event_reset_EVT_001_ROACH_ATTACK":
                self._admin_reset_event("EVT_001_ROACH_ATTACK")
            elif action == "event_inspect_EVT_001_ROACH_ATTACK":
                self._admin_inspect_event("EVT_001_ROACH_ATTACK")
            elif action == "event_trigger_EVT_002_WORD_SHOCK":
                self._admin_trigger_event("EVT_002_WORD_SHOCK")
            elif action == "event_stop_EVT_002_WORD_SHOCK":
                self._admin_stop_event("EVT_002_WORD_SHOCK")
            elif action == "event_trigger_EVT_003_PLEASE_DONT_TOUCH":
                if self._admin_trigger_evt003():
                    self.admin_panel_open = False
                    self._show_notification("EVT_003: REAL TRIGGER", duration=1800)
            elif action.startswith("event_test_EVT_003_PLEASE_DONT_TOUCH_"):
                phase_id = action[len("event_test_EVT_003_PLEASE_DONT_TOUCH_"):]
                if self._admin_test_evt003(phase_id):
                    self.admin_panel_open = False
                    self._show_notification(f"EVT_003 SANDBOX: {phase_id}", duration=1800)
            elif action == "event_reset_sandbox_EVT_003_PLEASE_DONT_TOUCH":
                if self.evt003_state is None:
                    self.evt003_runtime.reset_sandbox_history()
                    self._show_notification("EVT_003 sandbox history reset.", duration=1800)
            elif action == "logs_open_file":
                self._open_admin_log_file()
            elif action == "debug":
                self.debug_mode = not self.debug_mode
            elif action == "effects":
                self.effects_enabled = not self.effects_enabled
            elif action == "profiler":
                self.profiler.start(duration=10.0, scenario="admin_panel")
                self._show_notification("Профилирование запущено (10 сек)", duration=1500)
            elif action == "secret_force_open":
                self._open_secret_input(force=True)
                self.admin_panel_open = False
                self._show_notification("ТЕСТ: ПОЛЕ СЕКРЕТНОГО ВВОДА", duration=1500)
            elif action == "secret_test_success":
                self._open_secret_input(force=True)
                self.admin_panel_open = False
                self._submit_secret_input(SECRET_ACCESS_CODE)
            elif action == "secret_test_failure":
                self._open_secret_input(force=True)
                self.admin_panel_open = False
                self._submit_secret_input("000000")
            elif action == "secret_clear_input":
                self.secret_input_open = False
                self.secret_input_closing = False
                self.secret_input_value = ""
                self.secret_prompt_session.retry_after_cancel()
                self._show_notification("ПОЛЕ СЕКРЕТНОГО ВВОДА СБРОШЕНО", duration=1500)
            elif action == "secret_reset_collection":
                try:
                    SaveManager.save_event_collection_state(unlocked=False)
                except Exception:
                    self.app_logger.exception("Не удалось сбросить коллекцию событий")
                    self._show_notification("ОШИБКА СБРОСА КОЛЛЕКЦИИ", duration=1800)
                else:
                    self.event_collection_unlocked = False
                    self.event_collection_open = False
                    self.event_collection_closing = False
                    self.secret_input_open = False
                    self.secret_input_closing = False
                    self.secret_input_value = ""
                    self.secret_prompt_session.begin_session()
                    self._show_notification("ДОСТУП К КОЛЛЕКЦИИ СБРОШЕН", duration=1800)
            return True
        return True

    def _exit_game(self):
        self.audio_box.play_click()
        self.running = False
        pygame.quit()
        sys.exit()

    def _on_game_ui_update(self, seconds_left=None, lucky=False):
        if seconds_left is not None:
            self.game_seconds_left = seconds_left
        if lucky:
            self.game_view.trigger_target_animation()
            self.audio_box.play_lucky()

    def _on_limit_reached(self):
        lang_code = self.current_lang if self.current_lang in TRANSLATIONS else "RU"
        tc = self.game_logic.total_clicks
        phase_idx = self.game_logic.get_phase_index()
        if phase_idx >= 5 and not self.final_phase_triggered:
            self.final_phase_triggered = True
            self.game_logic.timer_active = True
            phrase = TRANSLATIONS[lang_code]["horror_phrases"][12]
            self.game_view.set_phrase(phrase, 0.0, tc, is_horror=True, saved_meme=self.game_current_phrase)
            self.game_current_phrase = phrase
            return
        if self.game_logic.horror_cooldown:
            return
        pool_range, glitch, only_horror = self.game_logic.get_phrase_pool_and_glitch()
        if only_horror:
            if phase_idx >= 4:
                phrase = "".join(random.choice("01#&%?") for _ in range(random.randint(20,40)))
                self.game_view.set_phrase(phrase, 1.0, tc, is_horror=True, saved_meme=self.game_current_phrase)
                self.game_current_phrase = phrase
            else:
                phrases = TRANSLATIONS[lang_code]["horror_phrases"]
                idx = random.choice(list(pool_range)) if pool_range else 0
                phrase = phrases[idx]
                self.game_view.set_phrase(phrase, glitch, tc, is_horror=True, saved_meme=self.game_current_phrase)
                self.game_current_phrase = phrase
        else:
            use_horror = random.random() < (0.2 if phase_idx >= 1 else 0)
            if use_horror and not self.game_logic.horror_cooldown:
                phrases = TRANSLATIONS[lang_code]["horror_phrases"]
                max_idx = min(len(phrases)-1, max(pool_range) if pool_range else 0)
                idx = random.randint(0, max_idx) if max_idx>=0 else 0
                phrase = phrases[idx]
                self.game_view.set_phrase(phrase, glitch, tc, is_horror=True, saved_meme=self.game_current_phrase)
                self.game_current_phrase = phrase
            else:
                self._set_meme_phrase()

    def _on_clean_finished(self):
        self.game_seconds_left = 30

    def _update_menu(self):
        current_time = pygame.time.get_ticks()
        self.current_lang = self.settings_box.current_lang
        if current_time - self.menu_start_time > self.start_delay:
            if self.hint_alpha < 255.0:
                self.hint_alpha += 5.1
                if self.hint_alpha > 255.0:
                    self.hint_alpha = 255.0
                    self.hint_visible = True
            if self.hint_alpha == 255.0 and current_time - self.last_blink_time > self.blink_interval:
                self.hint_visible = not self.hint_visible
                self.last_blink_time = current_time
        else:
            self.hint_alpha = 0.0
            self.hint_visible = False
        if self.game_logic.get_phase_index() >= 3:
            self.menu_jitter_offset = random.randint(-2, 2)
        else:
            self.menu_jitter_offset = 0

    def _commit_player_name(self, name):
        name = (name or "").strip()
        if not name:
            return
        self.player_name = name
        self.game_logic.player_name = name
        self.game_logic.name_verified = self.game_logic.verify_player_name(name)
        self.game_logic.system_os_user = self.name_input_scene.system_os_user
        self.game_logic.is_authentic = (name.lower() == self.name_input_scene.system_os_user.lower())
        SaveManager.save_game_data(
            self.game_logic.score,
            self.current_lang,
            self.game_logic.total_clicks,
            self.game_logic.wallpaper_index,
            name,
            self.name_input_scene.system_os_user
        )
        self.name_entry_active = False
        self.name_input_scene = None
        self._begin_intro_slides()

    def _handle_name_entry_events(self, event):
        if not self.name_input_scene:
            return
        if event.type == pygame.KEYDOWN:
            result = self.name_input_scene.handle_keyboard(event)
            if result == "QUIT":
                self.name_entry_active = False
                self.name_input_scene = None
                self.current_screen = "menu"
                self.audio_box.play_menu_music()
            elif result == "DONE":
                self._commit_player_name(self.name_input_scene.buffer)
        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            self.menu_cursor.trigger_click_animation()
            w, h = self.screen.get_size()
            mouse_pos = event.pos
            tex_w, tex_h = self.screen_texture.size
            pos_x = int(mouse_pos[0] * (tex_w / w))
            pos_y = int(mouse_pos[1] * (tex_h / h))
            result = self.name_input_scene.handle_mouse((pos_x, pos_y))
            if result == "QUIT":
                self.name_entry_active = False
                self.name_input_scene = None
                self.current_screen = "menu"
                self.audio_box.play_menu_music()
            elif result == "DONE":
                self._commit_player_name(self.name_input_scene.buffer)
        elif event.type == pygame.MOUSEMOTION:
            w, h = self.screen.get_size()
            mouse_pos = event.pos
            tex_w, tex_h = self.screen_texture.size
            pos_x = int(mouse_pos[0] * (tex_w / w))
            pos_y = int(mouse_pos[1] * (tex_h / h))
            self.name_input_scene.get_hover((pos_x, pos_y))

    def _handle_game_events(self, event):
        if (self.evt004_runtime is not None and self.evt004_runtime.running
                and event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE):
            self._finish_evt004(cancelled=True, reason="PLAYER_CANCELLED")
            return
        if self.game_logic.word_shock_active and event.type != pygame.VIDEORESIZE:
            self._handle_word_shock_input(event)
            return
        if self.secret_input_open and event.type != pygame.VIDEORESIZE:
            if event.type == pygame.KEYDOWN:
                self._handle_secret_input_key(event)
            elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                screen_w, screen_h = self.screen.get_size()
                tex_w, tex_h = self.screen_texture.size
                mouse_pos = (
                    int(event.pos[0] * tex_w / max(1, screen_w)),
                    int(event.pos[1] * tex_h / max(1, screen_h)),
                )
                close_rect = getattr(self, "secret_input_close_rect", None)
                cancel_rect = getattr(self, "secret_input_cancel_rect", None)
                ok_rect = getattr(self, "secret_input_ok_rect", None)
                if close_rect and close_rect.collidepoint(mouse_pos):
                    self._cancel_secret_input()
                elif cancel_rect and cancel_rect.collidepoint(mouse_pos):
                    self._cancel_secret_input()
                elif ok_rect and ok_rect.collidepoint(mouse_pos):
                    self._confirm_secret_input()
            return
        if self.event_collection_open and event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                self._close_event_collection()
            return
        if event.type == pygame.VIDEORESIZE:
            self.screen = pygame.display.set_mode((event.w, event.h), pygame.FULLSCREEN | pygame.DOUBLEBUF | pygame.OPENGL)
            self._setup_menu_hitboxes()
            self.game_view.width, self.game_view.height = event.w, event.h
            self.game_view.recalculate_layout()
        elif event.type == pygame.MOUSEBUTTONUP and event.button == 1:
            self.game_logic.timer_scale = 1.0
            self.game_view.lore_window_dragging = False
            self.game_view.lore_scroll_dragging = False
        elif event.type == pygame.MOUSEWHEEL and getattr(self.game_logic, "lore_window_open", False):
            if not getattr(self.game_logic, "lore_text_viewer_open", False) and not getattr(self.game_logic, "lore_image_viewer_open", False):
                screen_w, screen_h = self.screen.get_size()
                tex_w, tex_h = self.screen_texture.size
                mouse_pos = pygame.mouse.get_pos()
                pos = (int(mouse_pos[0] * (tex_w / screen_w)), int(mouse_pos[1] * (tex_h / screen_h)))
                if self.game_view.handle_lore_wheel(self.game_logic, pos, event.y):
                    return
        elif event.type == pygame.MOUSEMOTION:
            if self.game_view.lore_window_dragging:
                tex_w, tex_h = self.screen_texture.size
                screen_w, screen_h = self.screen.get_size()
                mouse_tex_x = int(event.pos[0] * (tex_w / screen_w))
                mouse_tex_y = int(event.pos[1] * (tex_h / screen_h))
                
                win_w = int(tex_w * 0.65)
                win_h = int(tex_h * 0.55)
                base_x = (tex_w - win_w) // 2
                base_y = (tex_h - win_h) // 2
                
                new_x = mouse_tex_x - self.game_view.lore_drag_start_x
                new_y = mouse_tex_y - self.game_view.lore_drag_start_y
                self.game_view.lore_window_offset_x = new_x - base_x
                self.game_view.lore_window_offset_y = new_y - base_y
                
                self.game_view.lore_window_offset_x = max(-base_x, min(tex_w - win_w - base_x, self.game_view.lore_window_offset_x))
                self.game_view.lore_window_offset_y = max(-base_y, min(tex_h - win_h - base_y, self.game_view.lore_window_offset_y))
            elif getattr(self.game_logic, "lore_window_open", False):
                tex_w, tex_h = self.screen_texture.size
                screen_w, screen_h = self.screen.get_size()
                pos = (int(event.pos[0] * (tex_w / screen_w)), int(event.pos[1] * (tex_h / screen_h)))
                self.game_view.handle_lore_motion(self.game_logic, pos)
            
        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            self.menu_cursor.trigger_click_animation()
            win_w, win_h = self.screen.get_size()
            tex_w, tex_h = self.screen_texture.size
            pos_x = int(event.pos[0] * (tex_w / win_w))
            pos_y = int(event.pos[1] * (tex_h / win_h))
            pos = (pos_x, pos_y)

            # EVT_004 exclusively owns left-click input while the encounter is active.
            if self._handle_evt004_click(pos):
                return

            if self.event_collection_open:
                if self.event_collection_closing:
                    return
                if (self.event_collection_close_rect and self.event_collection_close_rect.collidepoint(pos)):
                    self._close_event_collection()
                elif self.event_collection_window_rect and not self.event_collection_window_rect.collidepoint(pos):
                    self._close_event_collection()
                return
            if self.event_collection_icon_rect and self.event_collection_icon_rect.collidepoint(pos):
                self._open_event_collection()
                return

            hx = getattr(self.game_logic, "hidden_hitbox_x", 0)
            hy = getattr(self.game_logic, "hidden_hitbox_y", 0)
            hidden_rect = pygame.Rect(hx - 15, hy - 15, 30, 30)
            if hidden_rect.collidepoint(pos) and not getattr(self.game_logic, "code_window_open", False):
                self.game_logic.code_window_open = True
                self.game_logic.input_buffer = [None, None, None]
                self.game_logic.current_cell_index = 0
                self.game_logic.current_cell_buffer = ""
                self.game_logic.system_response_text = ""
                self.game_view.code_window_dirty = True
                return
            if getattr(self.game_logic, "code_window_open", False):
                close_rect = getattr(self.game_view, "code_close_rect", None)
                if close_rect and close_rect.collidepoint(pos):
                    self._cancel_archive_pin()
                    return
                cancel_rect = getattr(self.game_view, "code_cancel_btn_rect", None)
                if cancel_rect and cancel_rect.collidepoint(pos):
                    self._cancel_archive_pin()
                    return
                if self.code_init_active:
                    return
                ok_rect = getattr(self.game_view, "ok_btn_rect", None)
                if ok_rect and ok_rect.collidepoint(pos):
                    self._submit_archive_pin()
                    return
                for index, field_rect in enumerate(getattr(self.game_view, "code_input_rects", [])):
                    if field_rect.collidepoint(pos):
                        self.game_logic.current_cell_index = index
                        self.game_logic.current_cell_buffer = ""
                        self.game_logic.input_buffer[index] = None
                        self.game_view.code_window_dirty = True
                        return
                return
            if getattr(self.game_logic, "lore_window_open", False):
                if hasattr(self.game_view, 'handle_lore_viewer_click'):
                    if self.game_view.handle_lore_viewer_click(self.game_logic, pos):
                        return
                
                lore_rect = getattr(self.game_view, 'lore_win_rect', None)
                if not lore_rect:
                    return
                
                close_rect = getattr(self.game_view, 'lore_close_rect', None)
                if close_rect and close_rect.collidepoint(pos):
                    self.game_view.handle_lore_click(self.game_logic, pos)
                    return

                if hasattr(self.game_view, "handle_lore_menu_click"):
                    if self.game_view.handle_lore_menu_click(self.game_logic, pos):
                        return

                header_rect = pygame.Rect(lore_rect.x, lore_rect.y, lore_rect.width, 24)
                if header_rect.collidepoint(pos):
                    if not (close_rect and close_rect.collidepoint(pos)):
                        self.game_view.lore_window_dragging = True
                        self.game_view.lore_drag_start_x = pos[0] - lore_rect.x
                        self.game_view.lore_drag_start_y = pos[1] - lore_rect.y
                    return
                
                if hasattr(self.game_view, 'handle_lore_click'):
                    self.game_view.handle_lore_click(self.game_logic, pos)
                return
            
            if getattr(self.game_logic, "lore_icon_visible", False):
                if hasattr(self.game_view, 'rect_lore_icon') and self.game_view.rect_lore_icon:
                    if self.game_view.rect_lore_icon.collidepoint(pos):
                        self.game_logic.lore_window_open = not self.game_logic.lore_window_open
                        return
            
            if self.game_view.rect_back.collidepoint(pos):
                if self.game_logic.roach_attack_active or self.event_lifecycle.is_tracked("EVT_001_ROACH_ATTACK"):
                    self._cancel_managed_roach_attack(reason="BACK_TO_MENU")
                else:
                    self._stop_roach_audio()
                self.current_screen = "menu"
                self.audio_box.play_menu_music()
                return
            elif self.game_view.rect_wallpaper.collidepoint(pos):
                next_index = self.game_logic.wallpaper_index + 1
                self.game_logic.set_wallpaper(next_index)
                return
            elif hasattr(self, 'subtitle_rect') and self.subtitle_rect and self.subtitle_rect.collidepoint(pos):
                if self.subtitle_state == "waiting_click":
                    # По упрощённой механике субтитр исчезает мгновенно по клику
                    self.subtitle_state = "idle"
                    self.subtitle_state_timer = 0.0
                    self.subtitle_next_idle_timer = 0.0
                    self.subtitle_alpha = 0
                return

            if self.game_logic.minigame_active:
                for idx, rect in enumerate(self.game_view.rect_sectors):
                    if rect.collidepoint(pos):
                        self.game_logic.verify_sector_click(idx)
                        return
                return
            if (
                self.game_logic.roach_attack_active
                and not self.game_logic.timer_active
                and not self.game_logic.sprite_active
                and not self.game_logic.chase_planet_active
                and not self.game_logic.fade_screen_active
                and self.game_logic.clicks_in_cycle < 10
            ):
                for hitbox_slot, roach_rect in enumerate(self.game_view.roach_hitboxes):
                    if roach_rect.collidepoint(pos):
                        roach_index = self.game_view.roach_hitbox_indices[hitbox_slot]
                        roach_center = roach_rect.center
                        reward = self.game_logic.squash_roach(roach_index)
                        if reward:
                            self.game_view.trigger_roach_squash(roach_center)
                            self.audio_box.play_roach_attack("squash")
                            self._sync_managed_roach_attack()
                        return

            if self.game_logic.clicks_in_cycle < 10 and not self.game_logic.timer_active and not self.game_logic.fade_screen_active:
                if self.game_view.rect_target.collidepoint(pos):
                    # Отдельный короткий звук взаимодействия с игровым объектом.
                    self.audio_box.play_game_click()
                    if self.game_logic.clicks_in_cycle == 0 and not self.secret_input_open:
                        self.secret_prompt_session.begin_click_cycle()
                    result = self.game_logic.register_click()
                    prompt_due = self.secret_prompt_session.register_accepted_click(
                        result not in ("IGNORE", "JAMMED", "TRAP_TRIGGERED")
                    )
                    if result in ("NORMAL", "GHOST_BOOST", "RESISTANCE"):
                        sequence_result = self.game_logic.record_roach_sequence_click()
                        if sequence_result == "WORD_SHOCK_TRIGGER":
                            self._start_word_shock()
                            return
                        if sequence_result == "ROACH_TRIGGER":
                            self._start_roach_attack()
                            return
                    if (
                        prompt_due
                        and not self.secret_input_open
                        and not self.game_logic.roach_attack_active
                        and not self.game_logic.minigame_active
                        and not self.game_logic.timer_active
                        and not self.game_logic.sprite_active
                        and not self.game_logic.chase_planet_active
                        and not self.game_logic.fade_screen_active
                        and not self.game_logic.code_window_open
                        and not self.game_logic.lore_window_open
                    ):
                        self._open_secret_input()
                    if result in ["NORMAL", "LUCKY"]:
                        self.game_view.trigger_target_animation()
                        if result == "LUCKY":
                            self.game_view.trigger_label_animation()
                    return
                else:
                    now = pygame.time.get_ticks()
                    if now - getattr(self.game_logic, 'click_phrase_cooldown', 0) > 1500:
                        phase = self.game_logic.get_phase()
                        phrase = self.game_logic.get_click_phrase(phase)
                        if phrase:
                            self.game_logic.current_click_phrase = phrase
                            self.game_logic.click_phrase_timer = now + 2000
                            self.game_logic.click_phrase_cooldown = now
                            self.game_logic.click_phrase_alpha = 0
                            self.game_logic.click_phrase_scale = 0.0
                            self.game_logic.click_phrase_y_offset = 0
                            self.game_logic.click_phrase_pos = list(pos)
            else:
                if self.game_logic.fade_screen_active:
                    return

                # Проверяем попадание по любой активной планете.
                _chase_planet_target_index = None
                _chase_planets = getattr(self.game_logic, "chase_planets", [])

                if self.game_logic.sprite_active:
                    if _chase_planets:
                        for _planet_index, _planet in enumerate(_chase_planets):
                            _planet_rect = pygame.Rect(
                                int(_planet["x"]), int(_planet["y"]), 44, 44
                            )
                            if _planet_rect.collidepoint(pos):
                                _chase_planet_target_index = _planet_index
                                break
                    else:
                        _legacy_rect = pygame.Rect(
                            int(self.game_logic.sprite_x),
                            int(self.game_logic.sprite_y),
                            44, 44,
                        )
                        if _legacy_rect.collidepoint(pos):
                            _chase_planet_target_index = -1

                if (
                    (self.game_logic.timer_active or self.game_logic.sprite_active)
                    and _chase_planet_target_index is None
                ):
                    self.audio_box.play_chase_planet("click")

                if self.game_logic.sprite_active:
                    if _chase_planet_target_index is not None:
                        self.audio_box.play_chase_planet("catch")

                        self.game_logic.chase_planets_caught_round += 1
                        self.game_logic.chase_planets_caught_total += 1
                        self.game_logic.score += 10

                        if _chase_planet_target_index == -1:
                            self.game_logic.chase_planets.clear()
                        else:
                            self.game_logic.chase_planets.pop(
                                _chase_planet_target_index
                            )

                        if self.game_logic.chase_planets:
                            _first_planet = self.game_logic.chase_planets[0]
                            self.game_logic.sprite_x = _first_planet["x"]
                            self.game_logic.sprite_y = _first_planet["y"]
                            self.game_logic.sprite_active = True
                            self.game_logic.chase_planet_active = True
                            return

                        # Раунд завершается после поимки последней планеты.
                        self.game_logic.sprite_active = False
                        self.game_logic.timer_active = False
                        self.game_logic.timer_clicks = 0
                        self.game_logic.chase_planet_active = True

                        self.audio_box.play_chase_planet("victory", queue=True)

                        phase_key = self.game_logic.get_phase()
                        earth_data = TRANSLATIONS[self.current_lang]["earth_phases"]
                        if phase_key not in earth_data:
                            phase_key = "phase_4"

                        win_pool = earth_data[phase_key]["win"]
                        self.game_logic.set_notification(
                            random.choice(win_pool), duration=5000
                        )
                        self.game_logic.notification_color = (46, 204, 113)
                        self.game_logic.fade_screen_active = True
                        self.game_logic.fade_start_time = int(time.monotonic() * 1000)
                        return
                    else:
                        now = pygame.time.get_ticks()
                        if now - getattr(self.game_logic, 'click_phrase_cooldown', 0) > 1500:
                            phase = self.game_logic.get_phase()
                            phrase = self.game_logic.get_click_phrase(phase)
                            if phrase:
                                self.game_logic.current_click_phrase = phrase
                                self.game_logic.click_phrase_timer = now + 2000
                                self.game_logic.click_phrase_cooldown = now
                                self.game_logic.click_phrase_alpha = 0
                                self.game_logic.click_phrase_scale = 0.0
                                self.game_logic.click_phrase_y_offset = 0
                                self.game_logic.click_phrase_pos = list(pos)
                        return

                click_phrase_shown = False

                if self.game_logic.timer_active:
                    pbar_center_x = tex_w // 2
                    pbar_center_y = int(tex_h * 0.48)

                    click_rect = pygame.Rect(pbar_center_x - 200, pbar_center_y - 22, 400, 44)
                    
                    if click_rect.collidepoint(pos) and not self.game_logic.sprite_active:
                        self.game_logic.timer_clicks += 1
                        self.game_logic.timer_scale = 0.94
                        spawn_needed = getattr(self.game_logic, "sprite_spawn_clicks", 3)
                        if self.game_logic.timer_clicks >= spawn_needed:
                            self._spawn_chase_planets()
                        return
                    else:
                        click_phrase_shown = True

                else:
                    if self.game_view.rect_instant_wash.collidepoint(pos) and self.game_logic.score >= self.game_logic.upgrade_cost and not self.game_logic.system_jammed:
                        self.game_logic.wash_hands_instantly()
                        return
                    elif self.game_view.rect_free_wash_btn.collidepoint(pos):
                        if self.game_logic.system_jammed:
                            if self.game_logic.try_unjam_system():
                                self._show_notification("SYSTEM RESET")
                        else:
                            self._start_free_clean_flow()
                        return
                    else:
                        click_phrase_shown = True
                
                if click_phrase_shown:
                    now = pygame.time.get_ticks()
                    if now - getattr(self.game_logic, 'click_phrase_cooldown', 0) > 1500:
                        phase = self.game_logic.get_phase()
                        phrase = self.game_logic.get_click_phrase(phase)
                        if phrase:
                            self.game_logic.current_click_phrase = phrase
                            self.game_logic.click_phrase_timer = now + 2000
                            self.game_logic.click_phrase_cooldown = now
                            self.game_logic.click_phrase_alpha = 0
                            self.game_logic.click_phrase_scale = 0.0
                            self.game_logic.click_phrase_y_offset = 0
                            self.game_logic.click_phrase_pos = list(pos)
                    return
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_BACKQUOTE or (hasattr(event, 'unicode') and event.unicode in ('ё', 'Ё', '`', '~')):
                self.debug_mode = not self.debug_mode
                self._show_notification(f"DEBUG HITBOXES: {'ON' if self.debug_mode else 'OFF'}", duration=1000)
                # Запуск профайлера на 10 секунд
                if self.current_screen == "menu":
                    scenario = "menu"
                elif self.current_screen == "game":
                    if self.game_logic.code_window_open:
                        scenario = "game_code_window"
                    elif self.game_logic.lore_window_open:
                        scenario = "game_lore_window"
                    elif self.settings_box.is_open:
                        scenario = "game_settings"
                    else:
                        scenario = "gameplay"
                else:
                    scenario = "unknown"
                self.profiler.start(duration=10.0, scenario=scenario)
                self._show_notification(f"Профилирование запущено (10 сек)", duration=1500)
            elif event.key == pygame.K_F7:
                self.game_logic.total_clicks = 1500
                self.game_logic._sync_to_disk()
                self.game_logic.horror_cooldown = False
                self.game_view.recalculate_layout()
                msg = f"CHEAT: Phase 1 (1500 clicks)"
                self._show_notification(msg)
                self._on_limit_reached()
            elif event.key == pygame.K_F8:
                self.game_logic.total_clicks = 2500
                self.game_logic._sync_to_disk()
                self.game_logic.horror_cooldown = False
                self.game_view.recalculate_layout()
                msg = f"CHEAT: Phase 2 (2500 clicks)"
                self._show_notification(msg)
                self._on_limit_reached()
            elif event.key == pygame.K_F9:
                self.game_logic.cheat_to_paranoia()
                self.game_logic.horror_cooldown = False
                self.game_view.recalculate_layout()
                new_clicks = self.game_logic.total_clicks
                phase = self._get_phase_name(new_clicks)
                msg = f"CHEAT: jumped to {phase} ({new_clicks} clicks)"
                self._show_notification(msg)
                self._on_limit_reached()
            elif event.key == pygame.K_F10:
                self.game_logic.total_clicks = 2800
                self.game_logic._sync_to_disk()
                self.game_logic.horror_cooldown = False
                self.game_view.recalculate_layout()
                msg = f"CHEAT: Phase 4 (2800 clicks)"
                self._show_notification(msg)
                self._on_limit_reached()
            elif event.key == pygame.K_F11:
                self.game_logic.total_clicks = 3000
                self.game_logic._sync_to_disk()
                self.game_logic.horror_cooldown = False
                self.game_view.recalculate_layout()
                msg = f"CHEAT: Final Phase (3000 clicks)"
                self._show_notification(msg)
                self._on_limit_reached()
            elif event.key == pygame.K_F12:
                self._reset_progress()
            elif event.key == pygame.K_F5:
                self.effects_enabled = not self.effects_enabled
                self._show_notification(f"EFFECTS: {'ON' if self.effects_enabled else 'OFF'}", duration=1500)
            elif event.key == pygame.K_F3:
                if self.current_screen == "menu":
                    scenario = "menu"
                elif self.current_screen == "game":
                    if self.game_logic.code_window_open:
                        scenario = "game_code_window"
                    elif self.game_logic.lore_window_open:
                        scenario = "game_lore_window"
                    elif self.settings_box.is_open:
                        scenario = "game_settings"
                    else:
                        scenario = "gameplay"
                else:
                    scenario = "unknown"
                self.profiler.start(duration=10.0, scenario=scenario)
                self._show_notification(f"Профилирование запущено (10 сек)", duration=1500)
            elif (getattr(self.game_logic, "lore_window_open", False)
                  and not getattr(self.game_logic, "code_window_open", False)
                  and not getattr(self.game_logic, "lore_text_viewer_open", False)
                  and not getattr(self.game_logic, "lore_image_viewer_open", False)
                  and self.game_view.handle_lore_key(self.game_logic, event)):
                return
            elif getattr(self.game_logic, "code_window_open", False):
                logic = self.game_logic
                if event.key == pygame.K_ESCAPE:
                    self._cancel_archive_pin()
                    return
                if self.code_init_active:
                    return
                cache_invalidated = False
                if event.key == pygame.K_BACKSPACE:
                    if logic.current_cell_buffer:
                        logic.current_cell_buffer = logic.current_cell_buffer[:-1]
                        cache_invalidated = True
                    elif logic.current_cell_index > 0:
                        logic.current_cell_index -= 1
                        logic.input_buffer[logic.current_cell_index] = None
                        logic.current_cell_buffer = ""
                        cache_invalidated = True
                elif event.key in (pygame.K_RETURN, pygame.K_KP_ENTER):
                    self._submit_archive_pin()
                    return
                else:
                    digit = None
                    if pygame.K_0 <= event.key <= pygame.K_9:
                        digit = str(event.key - pygame.K_0)
                    elif pygame.K_KP0 <= event.key <= pygame.K_KP9:
                        digit = str(event.key - pygame.K_KP0)
                    if digit is not None and logic.current_cell_index < 3 and len(logic.current_cell_buffer) < 2:
                        logic.current_cell_buffer += digit
                        cache_invalidated = True
                        if len(logic.current_cell_buffer) == 2:
                            logic.input_buffer[logic.current_cell_index] = int(logic.current_cell_buffer)
                            logic.current_cell_index += 1
                            logic.current_cell_buffer = ""
                if cache_invalidated:
                    self.game_view.code_window_dirty = True

    def _draw_menu_to_texture(self):
        w, h = self.screen.get_size()
        surf = pygame.Surface((w, h))
        if self.settings_box.accessibility_visual:
            surf.fill((38, 50, 56))
        else:
            surf.fill(COLOR_BLACK)

        glitch_intensity = self.game_logic.get_glitch_intensity()
        title_text = "PALCHIK"
        if self.effects_enabled and self.game_logic.get_phase_index() >= 3 and random.random() < 0.03:
            title_text = random.choice(["PALCH1K", "PALCH!K", "PALCH|K", "ERROR"])
        title_surf = text_cache.render_with_font(self.font_title, self.apply_glitch(title_text, glitch_intensity), True, COLOR_WHITE)
        title_rect = title_surf.get_rect(center=(w // 2 + self.menu_jitter_offset, h // 2 - 30 + self.menu_jitter_offset))
        surf.blit(title_surf, title_rect)

        if self.hint_alpha > 0.0:
            hint_str = TRANSLATIONS[self.current_lang]["hint"]
            alpha = int(self.hint_alpha) if (self.hint_visible or self.hint_alpha < 255.0) else 0
            if alpha > 0:
                raw = text_cache.get_surface(self.apply_glitch(hint_str, glitch_intensity), "Courier New", 16, COLOR_DARK_GREY, bold=True)
                tmp = pygame.Surface(raw.get_size(), pygame.SRCALPHA)
                tmp.blit(raw, (0, 0))
                tmp.set_alpha(alpha)
                surf.blit(tmp, tmp.get_rect(center=(w // 2 + self.menu_jitter_offset // 2, h // 2 + 50 + self.menu_jitter_offset // 2)))

        for name, box in self.menu_cursor.hitboxes.items():
            if name == "start":
                continue
            rect = box["rect"]
            if name == "lang":
                label = "🌐"
            elif name == "theme":
                label = "🎨"
            elif name == "settings":
                label = "⚙️"
            elif name == "exit":
                label = "🚪"
            else:
                continue
            if self.effects_enabled and name == "settings" and self.game_logic.get_phase_index() >= 3 and random.random() < 0.02:
                label = random.choice(["⚙️⚠️", "💀", "???"])
            btn_txt = text_cache.get_surface(label, "Segoe UI Symbol", 22, COLOR_GREY, bold=True)
            btn_rect = btn_txt.get_rect(center=(rect.centerx + self.menu_jitter_offset, rect.centery + self.menu_jitter_offset))
            surf.blit(btn_txt, btn_rect)

        self.settings_box.draw(surf, self.font_title, self.font_txt_btn, self.current_lang,
                               int(self.audio_box._volume * 100))
        
        # Debug mode FPS and performance monitoring
        if self.debug_mode:
            fps = int(self.clock.get_fps())
            fps_surf = text_cache.get_surface(f"FPS: {fps}", "Courier New", 16, (0, 255, 0), bold=True)
            surf.blit(fps_surf, (10, 10))
            
            dt = self.clock.get_time()
            dt_text = f"Frame: {dt} ms"
            dt_surf = text_cache.get_surface(dt_text, "Courier New", 16, (0, 255, 0), bold=True)
            surf.blit(dt_surf, (10, 30))
            
            if PSUTIL_AVAILABLE:
                cpu_percent = psutil.cpu_percent(interval=0.0)
                cpu_text = f"CPU: {cpu_percent}%"
                cpu_surf = text_cache.get_surface(cpu_text, "Courier New", 16, (0, 255, 0), bold=True)
                surf.blit(cpu_surf, (10, 50))
                
                mem = psutil.virtual_memory()
                mem_text = f"RAM: {mem.percent}% ({mem.used//1024//1024} MB / {mem.total//1024//1024} MB)"
                mem_surf = text_cache.get_surface(mem_text, "Courier New", 16, (0, 255, 0), bold=True)
                surf.blit(mem_surf, (10, 70))

            text_cache.remove_by_text_prefix("FPS:")
            text_cache.remove_by_text_prefix("Frame: ")
            text_cache.remove_by_text_prefix("CPU:")
            text_cache.remove_by_text_prefix("RAM:")
            text_cache.remove_by_text_prefix("SECRET CODE:")
        
        self._draw_admin_panel(surf)
        self.menu_cursor.draw(surf)
        self.screen_texture.write(pygame.image.tostring(surf, 'RGBA', True))

    def _draw_game_to_texture(self):
        w, h = self.screen_texture.size
        surf = pygame.Surface((w, h))
        if self.evt003_state in ("RUNNING", "GAME_OVER"):
            if self.evt003_state == "RUNNING":
                elapsed = max(0.0, time.monotonic() - self.evt003_started_at)
                duration = float(self.evt003_runtime.duration_seconds)
                remaining_seconds = max(0, int(math.ceil(duration - elapsed)))
                message = "PLEASE DON'T TOUCH ANYTHING"
                self.evt003_presentation.draw_check(
                    surf, message[:self.evt003_typewriter_count], elapsed,
                    wallpaper_index=self.game_logic.wallpaper_index,
                    remaining_seconds=remaining_seconds,
                    duration_seconds=duration,
                )
            else:
                progress = (time.monotonic() - self.evt003_gameover_started_at) / 2.35
                self.evt003_presentation.draw_game_over(
                    surf, progress, wallpaper_index=self.game_logic.wallpaper_index,
                )
            # The system cursor is normally composed by the gameplay renderer.
            # This exclusive event render path must compose it explicitly as well.
            self.menu_cursor.set_hover_state(False)
            self.menu_cursor.draw(surf)
            self.screen_texture.write(pygame.image.tobytes(surf, "RGBA", True))
            return
        glitch_intensity = self.game_logic.get_glitch_intensity()
        center_text = self.game_logic.get_center_text(self.current_lang)
        self.game_view.draw(
            surf, 
            self.game_logic, 
            self.current_lang,
            self.game_seconds_left, 
            center_text, 
            self.game_blink_visible,
            glitch_intensity, 
            self.typed_phrase, 
            self.game_logic.total_clicks,
            self.game_logic.wallpaper_index, 
            self.easter_egg_phrase, 
            effects_enabled=self.effects_enabled,
            debug_mode=self.debug_mode
        )

        # EVT_004 overlay: draw dragon and damaged targets over the game scene
        self._draw_evt004(surf)

        if self.game_logic.word_shock_active:
            if self.admin_panel_open:
                self._draw_admin_panel(surf)
            self.screen_texture.write(pygame.image.tobytes(surf, "RGBA", True))
            return

        self._draw_event_collection_icon(surf)
        self._draw_secret_input(surf)

        clicks = self.game_logic.total_clicks
        phase_name = self._get_phase_name(clicks)
        info_text = f"{phase_name} | CLICKS: {clicks}"
        info_surf = text_cache.get_surface(self.game_view.apply_glitch(info_text, glitch_intensity), "Courier New", 16, (0, 255, 0), bold=True)
        surf.blit(info_surf, (w - info_surf.get_width() - 10, h - info_surf.get_height() - 10))

        if self.notification_text and pygame.time.get_ticks() < self.notification_timer:
            notif_surf = text_cache.get_surface(self.notification_text, "Courier New", 16, (255, 255, 0), bold=True)
            surf.blit(notif_surf, (w - notif_surf.get_width() - 10, h - notif_surf.get_height() - 40))
        elif self.notification_text:
            self.notification_text = ""

        # Draw subtitles
        self._draw_subtitles(surf, self.font_subtitle)

        # Debug overlay (restored - toggle with backtick key)
        if self.debug_mode:
            # Secret code
            code_str = f"SECRET CODE: {self.game_logic.secret_code}"
            code_surf = text_cache.get_surface(code_str, "Courier New", 16, (0, 255, 0), bold=True)
            surf.blit(code_surf, (10, 10))
            # FPS
            fps = int(self.clock.get_fps())
            fps_text = f"FPS: {fps}"
            fps_surf = text_cache.get_surface(fps_text, "Courier New", 16, (0, 255, 0), bold=True)
            surf.blit(fps_surf, (10, 30))
            # Frame time
            dt = self.clock.get_time()
            dt_text = f"Frame: {dt} ms"
            dt_surf = text_cache.get_surface(dt_text, "Courier New", 16, (0, 255, 0), bold=True)
            surf.blit(dt_surf, (10, 50))
            # CPU usage (if psutil available)
            if PSUTIL_AVAILABLE:
                cpu_percent = psutil.cpu_percent(interval=0.0)
                cpu_text = f"CPU: {cpu_percent}%"
                cpu_surf = text_cache.get_surface(cpu_text, "Courier New", 16, (0, 255, 0), bold=True)
                surf.blit(cpu_surf, (10, 70))
                # Memory usage
                mem = psutil.virtual_memory()
                mem_text = f"RAM: {mem.percent}% ({mem.used//1024//1024} MB / {mem.total//1024//1024} MB)"
                mem_surf = text_cache.get_surface(mem_text, "Courier New", 16, (0, 255, 0), bold=True)
                surf.blit(mem_surf, (10, 90))

            text_cache.remove_by_text_prefix("FPS:")
            text_cache.remove_by_text_prefix("Frame: ")
            text_cache.remove_by_text_prefix("CPU:")
            text_cache.remove_by_text_prefix("RAM:")
            text_cache.remove_by_text_prefix("SECRET CODE:")

        self._draw_admin_panel(surf)
        if self.event_collection_open and self.evt003_state is None:
            self._draw_event_collection_window(surf)
        if self.evt003_state in ("FORGIVENESS_DIALOG", "PENDING_NOTICE"):
            payload = self.evt003_dialog_payload or {}
            self.evt003_ok_rect = self.evt003_presentation.draw_dialog(
                surf,
                payload.get("text", "Нарушение зафиксировано."),
                title=payload.get("title", "СИСТЕМНОЕ УВЕДОМЛЕНИЕ"),
            )
        self.menu_cursor.draw(surf)
        self.screen_texture.write(pygame.image.tobytes(surf, 'RGBA', True))


    def _draw_fake_crash(self):
        w, h = self.screen.get_size()
        surf = pygame.Surface((w, h))
        surf.fill((0,0,0))
        lines = [
            "BIOS VHS EMULATOR v0.1",
            "DETECTING MEMORY CORRUPTION...",
            "TAPE HEAD DESYNC DETECTED",
            "READ ERROR: SECTOR 0x7F",
            "CRITICAL: FRAME BUFFER OVERFLOW",
            "",
            "PRESS ANY KEY TO SHUTDOWN..."
        ]
        y = h//3
        for line in lines:
            text = text_cache.get_surface(line, "Consolas", 18, (0, 255, 0), bold=True)
            surf.blit(text, (w//2 - text.get_width()//2, y))
            y += 30
        return surf

    def _reset_progress(self):
        # Keep the original F12 behavior: reset phase clicks without resetting
        # score, timers, mini-games, or other live gameplay state.
        self.game_logic.total_clicks = 0
        self.game_logic.horror_cooldown = False
        self.game_logic._sync_to_disk()
        self._set_meme_phrase()
        self.final_phase_triggered = False
        self.crash_stage = 0
        self.game_blink_visible = True
        self.typed_phrase = ""
        self.easter_egg_phrase = ""
        self.easter_egg_timer = 0
        self.game_view.recalculate_layout()
        self.game_view.target_scale = 1.0
        self.game_view.label_scale = 1.0
        self.game_view.target_animation_time = 0
        self.game_view.label_animation_time = 0
        self._setup_menu_hitboxes()
        self._show_notification("PROGRESS RESET: total_clicks = 0", duration=2000)

    def _handle_menu_events(self, event):
        if event.type == pygame.VIDEORESIZE:
            self.screen = pygame.display.set_mode((event.w, event.h), pygame.FULLSCREEN | pygame.DOUBLEBUF | pygame.OPENGL)
            self._setup_menu_hitboxes()
            self.game_view.width, self.game_view.height = event.w, event.h
            self.game_view.recalculate_layout()
        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            self.menu_cursor.trigger_click_animation()
            if self.settings_box.is_open:
                self._handle_settings_click(event.pos)
            else:
                self.menu_cursor.handle_click(event.pos, event.pos)

    def _handle_settings_click(self, pos):
        for name, rect in self.settings_box.hitboxes.items():
            if rect.collidepoint(pos):
                if name.startswith("lang_"):
                    code = name.split("_")[1]
                    self.current_lang = code
                    self.game_logic.current_lang = code
                    SaveManager.save_game_data(self.game_logic.score, code, self.game_logic.total_clicks, self.game_logic.wallpaper_index)
                    self.settings_box.close_dialog()
                elif name == "vol_minus":
                    self.audio_box.set_volume(self.audio_box._volume - 0.1)
                elif name == "vol_plus":
                    self.audio_box.set_volume(self.audio_box._volume + 0.1)
                elif name == "toggle_vibration":
                    self.settings_box.vibration = not self.settings_box.vibration
                elif name == "toggle_audio_acc":
                    self.settings_box.accessibility_audio = not self.settings_box.accessibility_audio
                    self.audio_box.accessibility_audio = self.settings_box.accessibility_audio
                elif name == "toggle_visual_acc":
                    self.settings_box.accessibility_visual = not self.settings_box.accessibility_visual
                elif name == "btn_close":
                    self.settings_box.close_dialog()
                return

    def _cancel_archive_pin(self):
        logic = self.game_logic
        logic.code_window_open = False
        logic.input_buffer = [None, None, None]
        logic.current_cell_index = 0
        logic.current_cell_buffer = ""
        logic.system_response_text = ""
        logic.failed_attempts_count = 0
        logic.auto_close_timer = 0.0
        self.code_init_active = False
        self.game_view.code_window_dirty = True

    def _submit_archive_pin(self):
        logic = self.game_logic
        if self.code_init_active:
            return
        if logic.current_cell_buffer or any(value is None for value in logic.input_buffer):
            logic.system_response_text = "Введите все три части PIN-кода."
            self.game_view.code_window_dirty = True
            return

        if logic.input_buffer == logic.secret_code:
            logic.lore_icon_visible = False
            logic.input_buffer = [None, None, None]
            logic.current_cell_index = 0
            logic.current_cell_buffer = ""
            logic.failed_attempts_count = 0
            logic.auto_close_timer = 0.0
            SaveManager.save_game_data(
                logic.score,
                self.current_lang,
                logic.total_clicks,
                logic.wallpaper_index,
                self.player_name,
                logic.system_os_user,
            )
            self._start_code_init_sequence()
            return

        logic.failed_attempts_count += 1
        logic.input_buffer = [None, None, None]
        logic.current_cell_index = 0
        logic.current_cell_buffer = ""
        if logic.failed_attempts_count >= 3:
            logic.system_response_text = "Ошибка доступа"
            logic.auto_close_timer = 2.0
        else:
            logic.system_response_text = "Ошибка доступа. Код неверен."
        self.game_view.code_window_dirty = True

    def _start_code_init_sequence(self):
        self.code_init_active = True
        self.code_init_step = 0
        self.code_init_text = "Инициализация проверки системы.. Пожалуйста, подождите"
        self.code_init_display = ""
        self.code_init_word_index = 0
        self.code_init_timer = 0.0
        self.code_init_phase_timer = 0.0
        self.code_init_word_count = 0
        self.code_init_current_word = 0
        self.game_logic.system_response_text = ""
        self.game_view.code_window_dirty = True

    def _update_code_init(self, dt):
        if not self.code_init_active:
            return
        
        if self.code_init_step == 0:
            if self.code_init_word_count == 0:
                words = self.code_init_text.split()
                self.code_init_word_count = len(words)
                self.code_init_current_word = 0
                self.code_init_display = ""
            
            self.code_init_timer += dt
            if self.code_init_timer >= 0.4:
                self.code_init_timer = 0.0
                if self.code_init_current_word < self.code_init_word_count:
                    words = self.code_init_text.split()
                    if self.code_init_display:
                        self.code_init_display += " " + words[self.code_init_current_word]
                    else:
                        self.code_init_display = words[self.code_init_current_word]
                    self.code_init_current_word += 1
                    self.game_logic.system_response_text = self.code_init_display
                    self.game_view.code_window_dirty = True
                else:
                    self.code_init_step = 1
                    self.code_init_phase_timer = 0.0
                    self.code_init_timer = 0.0
                    self.code_init_current_word = 0
                    self.code_init_display = ""
        
        elif self.code_init_step == 1:
            self.code_init_phase_timer += dt
            if self.code_init_phase_timer >= 2.5:
                self.code_init_text = "Инициализация завершена. Сектор памяти восстановлен."
                self.code_init_step = 2
                self.code_init_timer = 0.0
                self.code_init_current_word = 0
                self.code_init_display = ""
                self.code_init_phase_timer = 0.0
                self.code_init_word_count = 0
                self.game_view.code_window_dirty = True
        
        elif self.code_init_step == 2:
            if self.code_init_word_count == 0:
                words = self.code_init_text.split()
                self.code_init_word_count = len(words)
                self.code_init_current_word = 0
                self.code_init_display = ""
            
            self.code_init_timer += dt
            if self.code_init_timer >= 0.4:
                self.code_init_timer = 0.0
                if self.code_init_current_word < self.code_init_word_count:
                    words = self.code_init_text.split()
                    if self.code_init_display:
                        self.code_init_display += " " + words[self.code_init_current_word]
                    else:
                        self.code_init_display = words[self.code_init_current_word]
                    self.code_init_current_word += 1
                    self.game_logic.system_response_text = self.code_init_display
                    self.game_view.code_window_dirty = True
                else:
                    self.code_init_step = 3
                    self.code_init_phase_timer = 0.0
                    self.code_init_timer = 0.0
        
        elif self.code_init_step == 3:
            self.code_init_phase_timer += dt
            if self.code_init_phase_timer >= 1.5:
                self.game_logic.code_window_open = False
                self.code_init_active = False
                self.game_logic.system_response_text = ""
                self.game_logic.input_buffer = [None, None, None]
                self.game_logic.current_cell_index = 0
                self.game_logic.current_cell_buffer = ""
                self.channel_switch_active = True
                self.channel_switch_start_ms = pygame.time.get_ticks()
                self.audio_box.play_channel_switch()

    def _update_hidden_system(self, dt):
        logic = self.game_logic
        if getattr(logic, "auto_close_timer", 0.0) > 0:
            logic.auto_close_timer -= dt
            if logic.auto_close_timer <= 0:
                logic.code_window_open = False
                logic.secret_code = [14, 17, 23]
                random.shuffle(logic.secret_code)
                logic.failed_attempts_count = 0
                logic.input_buffer = [None, None, None]
                logic.current_cell_index = 0
                logic.current_cell_buffer = ""
                logic.system_response_text = ""
                SaveManager.save_game_data(
                    logic.score,
                    self.current_lang,
                    logic.total_clicks,
                    logic.wallpaper_index,
                    self.player_name,
                    getattr(logic, "system_os_user", "")
                )

    def _evt003_schedule_phase(self, phase):
        self.evt003_scheduled_phase = str(phase)
        self.evt003_next_check_at = time.monotonic() + random.uniform(
            self.evt003_runtime.random_delay_min_seconds,
            self.evt003_runtime.random_delay_max_seconds,
        )

    def _evt003_begin_gameplay_entry(self):
        # Sandbox punishment follows the same visible menu -> next-entry dialog
        # flow as a real event, but its notice stays volatile and never enters saves.
        sandbox_pending = getattr(self, "evt003_sandbox_pending_notice", None)
        if isinstance(sandbox_pending, dict) and sandbox_pending.get("text"):
            self.evt003_dialog_payload = dict(sandbox_pending)
            self.evt003_state = "PENDING_NOTICE"
            self.evt003_is_sandbox = True
        else:
            pending = getattr(self.game_logic, "evt003_pending_notification", None)
            if isinstance(pending, dict) and pending.get("text"):
                self.evt003_dialog_payload = dict(pending)
                self.evt003_state = "PENDING_NOTICE"
            else:
                self.evt003_state = None
                self.evt003_dialog_payload = None
            self.evt003_is_sandbox = False
        self.evt003_instance_id = None
        self._evt003_schedule_phase(self.game_logic.get_phase())

    def _maybe_start_evt003(self):
        if self.current_screen != "game" or self.crash_stage != 0:
            return
        if self.intro_slides_active or self.name_entry_active or self.admin_panel_open or self.channel_switch_active:
            return
        phase = self.game_logic.get_phase()
        now = time.monotonic()
        if phase != self.evt003_scheduled_phase:
            self._evt003_schedule_phase(phase)
        if now < self.evt003_next_check_at:
            return
        logic = self.game_logic
        blocked = (
            logic.word_shock_active or logic.roach_attack_active
            or logic.minigame_active or logic.timer_active or logic.sprite_active
            or logic.chase_planet_active or logic.fade_screen_active
            or logic.code_window_open or logic.lore_window_open
            or logic.lore_text_viewer_open or logic.lore_image_viewer_open
            or self.settings_box.is_open
        )
        if blocked:
            self.evt003_next_check_at = now + 4.0
            return
        allowed, reason = self.evt003_runtime.can_start(phase)
        if not allowed:
            if reason == "ALREADY_OCCURRED_THIS_PHASE":
                self.evt003_next_check_at = float("inf")
            else:
                self.evt003_next_check_at = now + 5.0
            return
        try:
            instance = self.evt003_runtime.start(phase)
        except Exception as exc:
            self._log_exception("EVT003_RANDOM_START", exc)
            self.evt003_next_check_at = now + 8.0
            return
        self.evt003_instance_id = instance.instance_id
        self.evt003_started_at = float(instance.started_at or now)
        self.evt003_typewriter_count = 0
        self.evt003_typewriter.reset(
            "PLEASE DON'T TOUCH ANYTHING", started_at=self.evt003_started_at,
            interval=self.evt003_typewriter_interval,
        )
        self.evt003_is_sandbox = False
        self.evt003_state = "RUNNING"

    def _evt003_violation(self):
        if self.evt003_state != "RUNNING" or not self.evt003_instance_id:
            return
        try:
            result = self.evt003_runtime.register_click(self.evt003_instance_id)
        except Exception as exc:
            self._log_exception("EVT003_VIOLATION_RESOLUTION", exc)
            # Fail closed: do not route this click into ordinary gameplay.
            self.evt003_state = "GAME_OVER"
            self.evt003_gameover_started_at = time.monotonic()
            self.audio_box.play_evt003_failure()
            return
        self.evt003_instance_id = None
        self.evt003_dialog_payload = {
            "text": result["notification_text"],
            "title": "СИСТЕМНОЕ ПРЕДУПРЕЖДЕНИЕ" if result["decision"] == "FORGIVENESS" else "СИСТЕМНОЕ НАРУШЕНИЕ",
            "phase": result["phase"],
            "notification_type": result["notification_type"],
        }
        if result.get("sandbox") and result["decision"] == "PUNISHMENT":
            # The real runtime persists its notice in GameLogic. Sandbox must
            # mirror the presentation without touching persistent player data.
            self.evt003_sandbox_pending_notice = dict(self.evt003_dialog_payload)
        if result["decision"] == "FORGIVENESS":
            self.evt003_state = "FORGIVENESS_DIALOG"
            self.audio_box.play_evt003_reprimand()
        else:
            self.evt003_state = "GAME_OVER"
            self.evt003_gameover_started_at = time.monotonic()
            self.audio_box.play_evt003_failure()

    def _evt003_acknowledge_dialog(self):
        state = self.evt003_state
        if state == "PENDING_NOTICE":
            if self.evt003_is_sandbox:
                self.evt003_sandbox_pending_notice = None
            else:
                self.game_logic.consume_evt003_pending_notification()
        was_sandbox = self.evt003_is_sandbox
        self.evt003_state = None
        self.evt003_instance_id = None
        self.evt003_dialog_payload = None
        self.evt003_ok_rect = None
        self.evt003_is_sandbox = False
        if was_sandbox:
            self._evt003_schedule_phase(self.game_logic.get_phase())
        self.audio_box.play_click()

    def _evt003_cancel_sandbox(self):
        instance_id = self.evt003_instance_id
        try:
            if instance_id:
                self.evt003_runtime.cancel(instance_id, reason="ADMIN_SANDBOX_ESCAPE")
        except Exception as exc:
            self._log_exception("EVT003_SANDBOX_CANCEL", exc)
        self.evt003_instance_id = None
        self.evt003_state = None
        self.evt003_dialog_payload = None
        self.evt003_ok_rect = None
        self.evt003_typewriter_count = 0
        self.evt003_is_sandbox = False
        self._evt003_schedule_phase(self.game_logic.get_phase())
        self._show_notification("EVT_003 SANDBOX: тест отменён; сохранения не изменены.", duration=2200)

    def _handle_evt003_event(self, event):
        """Exclusive input path while the check, animation or Win95 dialog is active."""
        if event.type == pygame.VIDEORESIZE:
            self.screen = pygame.display.set_mode(
                (event.w, event.h), pygame.FULLSCREEN | pygame.DOUBLEBUF | pygame.OPENGL
            )
            self._setup_menu_hitboxes()
            self.game_view.width, self.game_view.height = event.w, event.h
            self.game_view.recalculate_layout()
            return
        if self.evt003_is_sandbox and event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
            self._evt003_cancel_sandbox()
            return
        if self.evt003_state == "RUNNING":
            if event.type in (pygame.MOUSEBUTTONDOWN, pygame.MOUSEWHEEL):
                # At/after the 30-second deadline the check has already succeeded;
                # do not turn a late event-queue delivery into a false violation.
                if time.monotonic() - self.evt003_started_at >= self.evt003_runtime.duration_seconds:
                    self._update_evt003()
                else:
                    self._evt003_violation()
            return
        if self.evt003_state in ("FORGIVENESS_DIALOG", "PENDING_NOTICE"):
            acknowledge = event.type == pygame.KEYDOWN and event.key in (pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE)
            if event.type == pygame.MOUSEBUTTONDOWN and self.evt003_ok_rect:
                win_w, win_h = self.screen.get_size()
                tex_w, tex_h = self.screen_texture.size
                pos = (
                    int(event.pos[0] * tex_w / max(1, win_w)),
                    int(event.pos[1] * tex_h / max(1, win_h)),
                )
                acknowledge = self.evt003_ok_rect.collidepoint(pos)
            if acknowledge:
                self._evt003_acknowledge_dialog()
            return
        # The punishment animation is intentionally non-interactive.
        return

    def _update_evt003(self):
        now = time.monotonic()
        if self.evt003_state == "RUNNING":
            elapsed = max(0.0, now - self.evt003_started_at)
            newly_revealed = self.evt003_typewriter.advance(now)
            self.evt003_typewriter_count = self.evt003_typewriter.visible_count
            for _ in range(newly_revealed):
                self.audio_box.play_typewriter_tick()
            try:
                outcome = self.evt003_runtime.update(self.evt003_instance_id)
            except Exception as exc:
                self._log_exception("EVT003_COMPLIANCE_SAVE", exc)
                was_sandbox = self.evt003_is_sandbox
                try:
                    self.evt003_runtime.cancel(self.evt003_instance_id, reason="PRESENTATION_RECOVERY")
                except Exception:
                    pass
                self.evt003_instance_id = None
                self.evt003_state = None
                self.evt003_is_sandbox = False
                self._show_notification("EVT_003: ошибка. Подробности: F2 → ЖУРНАЛ.", duration=3500)
                if was_sandbox:
                    self._evt003_schedule_phase(self.game_logic.get_phase())
                return
            if outcome is not None:
                was_sandbox = self.evt003_is_sandbox
                self.evt003_instance_id = None
                self.evt003_state = None
                self.evt003_typewriter_count = 0
                self.audio_box.play_evt003_success()
                if was_sandbox:
                    self.evt003_is_sandbox = False
                    self._evt003_schedule_phase(self.game_logic.get_phase())
                    self._show_notification("SANDBOX: COMPLIANCE · баланс и история не изменены.", duration=2600)
                else:
                    self.evt003_next_check_at = float("inf")
            return
        if self.evt003_state == "GAME_OVER":
            progress = (now - self.evt003_gameover_started_at) / 2.35
            if progress >= 1.0:
                was_sandbox = self.evt003_is_sandbox
                self.evt003_state = None
                self.evt003_dialog_payload = None
                self.evt003_instance_id = None
                self.evt003_is_sandbox = False
                if was_sandbox:
                    # Sandbox isolates persistent balance/history, not the visible game-over flow.
                    self._evt003_schedule_phase(self.game_logic.get_phase())
                    self.admin_panel_open = False
                self.current_screen = "menu"
                self.audio_box.play_menu_music()
            return

    def _update_game(self):
        if self.event_collection_open or self.secret_input_open:
            return
        if self.evt004_runtime is not None:
            self._update_evt004(self.clock.get_time() / 1000.0)
            # EVT004 has an exclusive main_gameplay claim; do not tick normal gameplay underneath it.
            return
        if self.evt003_state is not None:
            self._update_evt003()
            return
        self._maybe_start_evt003()
        if self.evt003_state is not None:
            return
        if self.game_logic.word_shock_active or self.event_lifecycle.is_tracked("EVT_002_WORD_SHOCK"):
            self._sync_managed_word_shock()
        if self.game_logic.word_shock_active:
            word_shock_update = self.game_logic.update_word_shock()
            if word_shock_update == "MODAL_OPEN":
                pygame.key.start_text_input()
            elif word_shock_update == "EXPIRED":
                pygame.key.stop_text_input()
                self._sync_managed_word_shock()
            return
        now = pygame.time.get_ticks()
        dt = self.clock.get_time() / 1000.0
        self._update_hidden_system(dt)
        self._update_code_init(dt)
        
        # Отслеживаем завершение погони, чтобы проиграть звук ухода планеты
        # только при истечении таймера, а не после успешного захвата.
        chase_was_active = self.game_logic.sprite_active
        chase_timer_was_active = self.game_logic.timer_active

        # Оптимизация: GameLogic.update() вызываем с dt для возможности throttling
        self.game_logic.update()
        self._sync_managed_roach_attack()
        sequence_update = self.game_logic.update_roach_sequence()
        if sequence_update == "ROACH_TRIGGER":
            self._start_roach_attack()
        _roach_mode_blocked = (
            self.game_logic.minigame_active
            or self.game_logic.timer_active
            or self.game_logic.sprite_active
            or self.game_logic.chase_planet_active
            or self.game_logic.fade_screen_active
            or self.game_logic.clicks_in_cycle >= 10
        )
        if self.game_logic.roach_attack_active and not _roach_mode_blocked:
            _roach_forbidden = self.game_view.rect_target.inflate(170, 150)
            _win_w, _win_h = self.screen.get_size()
            _tex_w, _tex_h = self.screen_texture.size
            _mouse = pygame.mouse.get_pos()
            _cursor_tex = (
                int(_mouse[0] * (_tex_w / max(1, _win_w))),
                int(_mouse[1] * (_tex_h / max(1, _win_h))),
            )
            self.game_logic.update_roaches(
                dt, self.game_view.width, self.game_view.height,
                _roach_forbidden, cursor_pos=_cursor_tex,
            )
        self._sync_roach_audio()

        if (
            chase_was_active
            and chase_timer_was_active
            and not self.game_logic.sprite_active
            and self.game_logic.fade_screen_active
        ):
            self.audio_box.play_chase_planet("escape")

        self.game_view.update_animations()
        
        # Оптимизация CPU: обновляем уведомления и horror-фразы не каждый кадр, а раз в ~200 мс
        if now - getattr(self, '_last_notification_update', 0) >= 200:
            self._last_notification_update = now
            
            if self.game_logic.clicks_in_cycle >= 10 and not self.game_logic.minigame_active and not self.game_logic.timer_active and not self.game_logic.fade_screen_active:
                now_ms = int(time.monotonic() * 1000)
                if self.game_logic.notification_timer <= now_ms or self.game_logic.notification_text in ("", TRANSLATIONS[self.current_lang]["hint"]):
                    text_source = TRANSLATIONS[self.current_lang]
                    
                    phase_key = self.game_logic.get_phase()
                    
                    if phase_key in ["phase_0", "phase_1"]:
                        phrases_pool = text_source["phrases"]
                    else:
                        phrases_pool = text_source["horror_phrases"]
                        
                    self.game_logic.set_notification(random.choice(phrases_pool), duration=5000)
            
            # Update personalized horror phrases based on phase
            if self.game_logic.is_horror_phase() and self.game_logic.player_name:
                phase_idx = self.game_logic.get_phase_index()
                phase_num = min(4, max(0, phase_idx - 1))
                
                if phase_num >= 2:
                    personalized = self.game_logic.get_personalized_horror_phrase(self.current_lang, phase_num)
                    if personalized and random.random() < 0.3:
                        self.game_logic.set_notification(personalized, duration=7000)

        if now - self.game_last_blink_time >= 500:
            self.game_blink_visible = not self.game_blink_visible
            self.game_last_blink_time = now
        else:
            self.game_blink_visible = True
        if self.final_phase_triggered and self.game_logic.is_final_phase():
            keep = self.game_view.update_typewriter(self.game_logic.total_clicks)
            self.typed_phrase = self.game_view.display_phrase
            if not keep and not self.game_logic.timer_active:
                self.game_logic.timer_active = False
                self.crash_stage = 1
                self.fake_crash_start = now
        else:
            self.game_view.update_typewriter(self.game_logic.total_clicks)
            self.typed_phrase = self.game_view.display_phrase

        if self.easter_egg_timer and now > self.easter_egg_timer:
            self.easter_egg_phrase = ""
            self.easter_egg_timer = 0
        if self.game_logic.sprite_active and not self.game_logic.minigame_active:
            win_w, win_h = self.screen.get_size()
            tex_w, tex_h = self.screen_texture.size
            mouse_pos = pygame.mouse.get_pos()
            mouse_tex_x = int(mouse_pos[0] * (tex_w / win_w))
            mouse_tex_y = int(mouse_pos[1] * (tex_h / win_h))

            _chase_planets = getattr(self.game_logic, "chase_planets", [])

            if _chase_planets:
                for _planet in _chase_planets:
                    _center_x = _planet["x"] + 22
                    _center_y = _planet["y"] + 22
                    _dx = _center_x - mouse_tex_x
                    _dy = _center_y - mouse_tex_y
                    _dist = math.hypot(_dx, _dy)

                    if 0 < _dist < 110:
                        _planet["x"] += (
                            (_dx / _dist) * self.game_logic.sprite_speed
                            + random.uniform(-1.5, 1.5)
                        )
                        _planet["y"] += (
                            (_dy / _dist) * self.game_logic.sprite_speed
                            + random.uniform(-1.5, 1.5)
                        )

                    _planet["x"] = max(
                        40, min(self.game_view.width - 84, _planet["x"])
                    )
                    _planet["y"] = max(
                        40, min(self.game_view.height - 84, _planet["y"])
                    )

                _first_planet = _chase_planets[0]
                self.game_logic.sprite_x = _first_planet["x"]
                self.game_logic.sprite_y = _first_planet["y"]
            else:
                # Совместимость с прежним одиночным режимом.
                _center_x = self.game_logic.sprite_x + 22
                _center_y = self.game_logic.sprite_y + 22
                _dx = _center_x - mouse_tex_x
                _dy = _center_y - mouse_tex_y
                _dist = math.hypot(_dx, _dy)

                if 0 < _dist < 110:
                    self.game_logic.sprite_x += (
                        (_dx / _dist) * self.game_logic.sprite_speed
                        + random.uniform(-1.5, 1.5)
                    )
                    self.game_logic.sprite_y += (
                        (_dy / _dist) * self.game_logic.sprite_speed
                        + random.uniform(-1.5, 1.5)
                    )

                    self.game_logic.sprite_x = max(
                        40, min(self.game_view.width - 84, self.game_logic.sprite_x)
                    )
                    self.game_logic.sprite_y = max(
                        40, min(self.game_view.height - 84, self.game_logic.sprite_y)
                    )

        if self.game_logic.fade_screen_active:
            current_ms = int(time.monotonic() * 1000)
            if current_ms - self.game_logic.fade_start_time >= self.game_logic.fade_duration:
                self.game_logic.fade_screen_active = False
                self.game_logic.chase_planet_active = False
                self.game_logic.clicks_in_cycle = 0
                self.game_logic.set_notification(TRANSLATIONS[self.current_lang]["hint"], duration=5000)
                self.game_logic.notification_color = (255, 255, 255)

        # If the second main-button press also started an exclusive legacy
        # event, defer the secret prompt until that event releases its gameplay lock.
        if (
            not self.secret_input_open
            and self.secret_prompt_session.prompt_pending
            and not self.game_logic.roach_attack_active
            and not self.game_logic.minigame_active
            and not self.game_logic.timer_active
            and not self.game_logic.sprite_active
            and not self.game_logic.chase_planet_active
            and not self.game_logic.fade_screen_active
            and not self.game_logic.code_window_open
            and not self.game_logic.lore_window_open
        ):
            self._open_secret_input()

        # Subtitle system update
        self._update_subtitles()

    def _load_subtitle_phrases(self, phase):
        """Загружает все фразы для указанной фазы из всех категорий (микс) для текущего языка."""
        lang_code = self.current_lang.lower()
        echoes_dir = os.path.join("assets", "echoes", lang_code)
        
        phase_map = {
            "phase_0": "phase_0.txt",
            "phase_1": "phase_1.txt",
            "phase_2": "phase_2.txt",
            "phase_3": "phase_3.txt",
            "phase_4": "phase_4.txt",
            "final": "final.txt"
        }
        filename = phase_map.get(phase)
        if not filename:
            return []
        
        if not os.path.isdir(echoes_dir):
            return []
        
        all_phrases = []
        for category in os.listdir(echoes_dir):
            category_path = os.path.join(echoes_dir, category)
            if not os.path.isdir(category_path):
                continue
            filepath = os.path.join(category_path, filename)
            if os.path.exists(filepath):
                try:
                    with open(filepath, "r", encoding="utf-8") as f:
                        lines = [line.strip() for line in f if line.strip()]
                        all_phrases.extend(lines)
                except Exception:
                    self.app_logger.exception("Ошибка загрузки субтитров: %s", filepath)
        
        return all_phrases

    def _update_subtitles(self):
        """Обновляет состояние субтитров."""
        if self.current_screen != "game" or self.settings_box.is_open:
            return
            
        dt = self.clock.get_time() / 1000.0
        phase = self.game_logic.get_phase()
        
        if self.subtitle_state == "idle":
            self.subtitle_next_idle_timer += dt
            if self.subtitle_next_idle_timer >= random.uniform(3.0, 8.0):
                phrases = self._load_subtitle_phrases(phase)
                if not phrases:
                    from localization import TRANSLATIONS
                    lang_code = self.current_lang if self.current_lang in TRANSLATIONS else "RU"
                    phrases = TRANSLATIONS[lang_code].get("subtitles", {}).get(phase, [])
                    if not phrases and lang_code != "RU":
                        phrases = TRANSLATIONS["RU"].get("subtitles", {}).get(phase, [])
                if not phrases:
                    phrases = ["..."]
                self.subtitle_full_text = random.choice(phrases)
                self.subtitle_displayed_text = ""
                self.subtitle_state = "typewriter"
                self.subtitle_state_timer = 0.0
                self.subtitle_typewriter_timer = 0.0
                self.subtitle_alpha = 255
                self.subtitle_next_idle_timer = 0.0

        elif self.subtitle_state == "typewriter":
            self.subtitle_typewriter_timer += dt
            if self.subtitle_typewriter_timer >= self.subtitle_typewriter_speed:
                self.subtitle_typewriter_timer = 0.0
                if len(self.subtitle_displayed_text) < len(self.subtitle_full_text):
                    self.subtitle_displayed_text = self.subtitle_full_text[:len(self.subtitle_displayed_text) + 1]
                else:
                    self.subtitle_state = "waiting_click"

        elif self.subtitle_state == "waiting_click":
            # Ждём клика игрока; субтитр скрывается по клику в _handle_game_events
            pass

    def _draw_subtitles(self, surface, font):
        """Рисует субтитры в нижней части экрана. (оптимизировано)"""
        if not self.subtitle_displayed_text or self.subtitle_alpha <= 0:
            return
        
        w, h = surface.get_size()
        bar_height = 80
        bar_y = h - int(h * 0.10) - bar_height // 2
        max_text_width = int(w * 0.80)
        
        # Кэшированный шрифт для измерения
        font_key = ("Arial", 24, True, False)
        fnt = text_cache.get_font_object("Arial", 24, bold=True)
        
        display_text = self.subtitle_displayed_text
        words = display_text.split()
        lines = []
        current_line = []
        
        # Однопроходный перенос строк: измеряем ширину через get_surface (кэшируется)
        for word in words:
            test_line = " ".join(current_line + [word])
            test_surf = text_cache.get_surface(test_line, "Arial", 24, (200, 200, 200), bold=True)
            if test_surf.get_width() <= max_text_width:
                current_line.append(word)
            else:
                if current_line:
                    lines.append(" ".join(current_line))
                current_line = [word]
        if current_line:
            lines.append(" ".join(current_line))
        
        line_height = 28
        total_height = len(lines) * line_height
        
        bg_padding_x = 20
        bg_padding_y = 10
        bg_width = max_text_width + bg_padding_x * 2
        bg_height = total_height + bg_padding_y * 2
        bg_x = (w - bg_width) // 2
        bg_y = bar_y - bg_padding_y
        
        # Фон — только если есть строки
        if lines:
            bg_surf = pygame.Surface((bg_width, bg_height), pygame.SRCALPHA)
            bg_surf.fill((0, 0, 0, int(153 * self.subtitle_alpha / 255)))
            surface.blit(bg_surf, (bg_x, bg_y))
            
            text_start_y = bg_y + bg_padding_y
            for idx, line in enumerate(lines):
                text_y = text_start_y + idx * line_height
                line_surf = text_cache.get_surface(line, "Arial", 24, (255, 255, 255), bold=True)
                line_surf.set_alpha(self.subtitle_alpha)
                text_x = (w - line_surf.get_width()) // 2
                surface.blit(line_surf, (text_x, text_y))
        
        self.subtitle_rect = pygame.Rect(bg_x, bg_y, bg_width, bg_height)

    def _draw_name_entry_to_texture(self):
        w, h = self.screen_texture.size
        surf = pygame.Surface((w, h))
        if self.name_input_scene:
            self.name_input_scene.update()
            self.name_input_scene.draw(surf)
        self._draw_admin_panel(surf)
        self.menu_cursor.draw(surf)
        self.screen_texture.write(pygame.image.tobytes(surf, 'RGBA', True))

    def run(self):
        while self.running:
            # Cursor animations must advance in every scene, not only the menu.
            self.menu_cursor.update()
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.running = False
                    pygame.quit()
                    sys.exit()
                if self.current_screen == "game" and self.evt003_state is not None:
                    self._handle_evt003_event(event)
                    continue
                if self.current_screen == "game" and self.game_logic.word_shock_active:
                    if event.type == pygame.KEYDOWN and event.key == pygame.K_F2:
                        self.admin_panel_open = not self.admin_panel_open
                        continue
                    if self.admin_panel_open:
                        if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                            self.admin_panel_open = False
                        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                            self._handle_admin_panel_event(event)
                        elif event.type == pygame.VIDEORESIZE:
                            self._handle_game_events(event)
                        continue
                    self._handle_game_events(event)
                    continue
                if event.type == pygame.KEYDOWN and event.key == pygame.K_F2:
                    panel_available = (
                        self.current_screen == "menu"
                        or (
                            self.current_screen == "game"
                            and not self.channel_switch_active
                            and (self.intro_slides_active or self.name_entry_active or self.crash_stage == 0)
                        )
                    )
                    if panel_available:
                        self.admin_panel_open = not self.admin_panel_open
                    continue
                if self.admin_panel_open:
                    if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                        self.admin_panel_open = False
                    elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                        self._handle_admin_panel_event(event)
                    continue
                if self.current_screen == "game" and self.channel_switch_active:
                    continue
                if self.current_screen == "menu":
                    self._handle_menu_events(event)
                elif self.current_screen == "game":
                    if self.intro_slides_active:
                        self._handle_intro_slide_events(event)
                    elif self.name_entry_active:
                        self._handle_name_entry_events(event)
                    elif self.crash_stage == 0:
                        self._handle_game_events(event)
                elif self.current_screen == "intro":
                    if event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE:
                        if self.video:
                            self.video.release()
                        self.current_screen = "menu"
                        self.audio_box.play_menu_music()
                    elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                        if self.video:
                            self.video.release()
                        self.current_screen = "menu"
                        self.audio_box.play_menu_music()

            if self.current_screen == "intro" and self.video is not None:
                ret, frame = self.video.read()
                if ret:
                    frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                    f_h, f_w, _ = frame.shape
                    video_surf = pygame.image.frombuffer(frame.tobytes(), (f_w, f_h), "RGB")
                    w, h = self.screen.get_size()
                    scaled = pygame.transform.scale(video_surf, (w, h))
                    self.screen_texture.write(pygame.image.tostring(scaled, 'RGBA', True))
                else:
                    self.video.release()
                    self.current_screen = "menu"
                    self.audio_box.play_menu_music()
                self.ctx.clear(0.0, 0.0, 0.0, 1.0)
                self.screen_texture.use(0)
                self.program['u_texture'] = 0
                self.program['u_effects_enabled'] = 1.0 if self.effects_enabled else 0.0
                self.program['u_channel_switch'] = 0.0
                self.program['u_channel_time'] = 0.0
                w, h = self.screen.get_size()
                self.program['u_resolution'] = (float(w), float(h))
                self.program['u_time'] = (pygame.time.get_ticks() / 1000.0) * 0.5
                self.vao.render(moderngl.TRIANGLE_STRIP)
                pygame.display.flip()
                self.clock.tick(30)
                continue

            if self.current_screen == "menu":
                self._update_menu()
                self._draw_menu_to_texture()
            elif self.current_screen == "game":
                if self.channel_switch_active:
                    elapsed_ms = pygame.time.get_ticks() - self.channel_switch_start_ms
                    if elapsed_ms >= self.channel_switch_duration_ms:
                        self.channel_switch_active = False
                        self.game_logic.lore_icon_visible = True
                        self._update_game()
                        self._draw_game_to_texture()
                elif self.intro_slides_active:
                    self._update_intro_slides()
                    self._draw_intro_slides_to_texture()
                elif self.name_entry_active:
                    self._draw_name_entry_to_texture()
                elif self.crash_stage == 0:
                    if not self.admin_panel_open:
                        self._update_game()
                    self._draw_game_to_texture()
                elif self.crash_stage == 1:
                    if self.fake_crash_start == 0:
                        self.fake_crash_start = pygame.time.get_ticks()
                    elapsed = pygame.time.get_ticks() - self.fake_crash_start
                    if elapsed < 5000:
                        crash_surf = self._draw_fake_crash()
                        self.screen_texture.write(pygame.image.tostring(crash_surf, 'RGBA', True))
                    else:
                        self.running = False
                        pygame.quit()
                        sys.exit()
                else:
                    self._draw_game_to_texture()

            if self.current_screen == "menu":
                mouse_pos = pygame.mouse.get_pos()
                # The start action intentionally covers most of the screen; it
                # remains clickable, but should not make the cursor a hand
                # over the whole background. The small menu controls do.
                self.menu_cursor.handle_mouse_movement(
                    mouse_pos, exclude_names={"start"}
                )
            elif self.current_screen == "game" and self.crash_stage == 0 and not self.channel_switch_active:
                mouse_pos = pygame.mouse.get_pos()
                hovering = bool(self.admin_panel_open or self.intro_slides_active)
                if self.intro_slides_active and self.intro_slide_button_rect:
                    tex_w, tex_h = self.screen_texture.size
                    screen_w, screen_h = self.screen.get_size()
                    mouse_pos = pygame.mouse.get_pos()
                    slide_pos = (int(mouse_pos[0] * tex_w / max(1, screen_w)), int(mouse_pos[1] * tex_h / max(1, screen_h)))
                    hovering = hovering or self.intro_slide_button_rect.collidepoint(slide_pos)
                if self.admin_panel_open:
                    pass
                elif self.intro_slides_active:
                    pass
                elif self.name_entry_active and self.name_input_scene:
                    tex_w, tex_h = self.screen_texture.size
                    screen_w, screen_h = self.screen.get_size()
                    name_pos = (
                        int(mouse_pos[0] * (tex_w / max(1, screen_w))),
                        int(mouse_pos[1] * (tex_h / max(1, screen_h))),
                    )
                    self.name_input_scene.get_hover(name_pos)
                    hovering = any((
                        self.name_input_scene.hover_cell is not None,
                        self.name_input_scene.hover_node is not None,
                        self.name_input_scene.hover_lang is not None,
                    ))
                elif self.settings_box.is_open:
                    hovering = any(
                        rect.collidepoint(mouse_pos)
                        for rect in self.settings_box.hitboxes.values()
                    )
                else:
                    if self.game_view.rect_back.collidepoint(mouse_pos):
                        hovering = True
                    if self.event_collection_icon_rect and self.event_collection_icon_rect.collidepoint(mouse_pos):
                        hovering = True
                    if not self.game_logic.timer_active and self.game_logic.clicks_in_cycle < 10:
                        if self.game_view.rect_target.collidepoint(mouse_pos):
                            hovering = True
                    if self.game_logic.clicks_in_cycle >= 10 and not self.game_logic.timer_active:
                        if self.game_logic.score >= self.game_logic.upgrade_cost:
                            if self.game_view.rect_instant_wash.collidepoint(mouse_pos):
                                hovering = True
                            elif self.game_view.rect_free_wash_btn.collidepoint(mouse_pos):
                                hovering = True
                        else:
                            if self.game_view.rect_free_wash_btn.collidepoint(mouse_pos):
                                hovering = True
                self.menu_cursor.set_hover_state(hovering)

            self.ctx.clear(0.0, 0.0, 0.0, 1.0)
            self.screen_texture.use(0)
            self.program['u_texture'] = 0
            self.program['u_effects_enabled'] = 1.0 if self.effects_enabled else 0.0
            channel_elapsed = (pygame.time.get_ticks() - self.channel_switch_start_ms) / 1000.0
            self.program['u_channel_switch'] = 1.0 if self.channel_switch_active else 0.0
            self.program['u_channel_time'] = channel_elapsed if self.channel_switch_active else 0.0
            w, h = self.screen.get_size()
            self.program['u_resolution'] = (float(w), float(h))
            self.program['u_time'] = (pygame.time.get_ticks() / 1000.0) * 0.5
            self.vao.render(moderngl.TRIANGLE_STRIP)
            pygame.display.flip()
            
            fps = self.clock.get_fps()
            dt = self.clock.get_time() / 1000.0
            self.profiler.tick(fps, dt)
            
            self.clock.tick(60)

if __name__ == "__main__":
    app = Application()
    app.run()
