"""Single source of truth for registered event metadata and configuration."""
from __future__ import annotations
import json
from pathlib import Path
from typing import Iterable, Mapping, Any
from .contracts import EventDefinition, EventSource

class EventCatalogError(ValueError):
    pass

class EventCatalog:
    def __init__(self, definitions: Iterable[EventDefinition], config_root: str | Path):
        self._definitions: dict[str, EventDefinition] = {}
        self._configs: dict[str, dict[str, Any]] = {}
        self.config_root = Path(config_root)
        for definition in definitions:
            if not definition.event_id or definition.event_id in self._definitions:
                raise EventCatalogError(f"Empty or duplicate event ID: {definition.event_id!r}")
            self._definitions[definition.event_id] = definition
        self.validate_configs()

    def get(self, event_id: str) -> EventDefinition | None:
        return self._definitions.get(event_id)

    def configuration(self, event_id: str) -> Mapping[str, Any] | None:
        payload = self._configs.get(event_id)
        return payload.copy() if payload is not None else None

    def is_enabled(self, event_id: str) -> bool:
        definition = self.get(event_id)
        config = self._configs.get(event_id)
        return bool(definition and definition.enabled and config and config.get("enabled", True))

    def all(self, *, enabled_only: bool = False) -> tuple[EventDefinition, ...]:
        values = tuple(self._definitions.values())
        return tuple(item for item in values if self.is_enabled(item.event_id)) if enabled_only else values

    def validate_configs(self) -> None:
        for definition in self._definitions.values():
            path = self.config_root / definition.config_file
            if not path.is_file():
                raise EventCatalogError(f"Missing config for {definition.event_id}: {path}")
            try:
                payload = json.loads(path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError) as exc:
                raise EventCatalogError(f"Invalid JSON for {definition.event_id}: {exc}") from exc
            if not isinstance(payload, dict):
                raise EventCatalogError(f"Config root must be an object for {definition.event_id}")
            if payload.get("event_id") != definition.event_id:
                raise EventCatalogError(f"Config ID mismatch for {definition.event_id}")
            if not isinstance(payload.get("enabled", True), bool):
                raise EventCatalogError(f"enabled must be boolean for {definition.event_id}")
            if not isinstance(payload.get("parameters", {}), dict):
                raise EventCatalogError(f"parameters must be an object for {definition.event_id}")
            if payload.get("source") != definition.source.value:
                raise EventCatalogError(f"Source mismatch for {definition.event_id}")
            configured_subcategories = payload.get("subcategories", [])
            if not isinstance(configured_subcategories, list) or not all(isinstance(x, str) for x in configured_subcategories):
                raise EventCatalogError(f"subcategories must be a string array for {definition.event_id}")
            if tuple(configured_subcategories) != definition.subcategories:
                raise EventCatalogError(f"Subcategory mismatch for {definition.event_id}")
            valid = {f"{definition.source.value}_{number:02d}" for number in range(1, 7)}
            if any(item not in valid for item in configured_subcategories):
                raise EventCatalogError(f"Invalid subcategory for {definition.event_id}: {configured_subcategories}")
            self._configs[definition.event_id] = payload

def load_default_catalog(project_root: str | Path | None = None) -> EventCatalog:
    root = Path(project_root) if project_root is not None else Path(__file__).resolve().parent.parent
    config_root = root / "config" / "events"
    definitions = (
        EventDefinition(
            event_id="EVT_001_ROACH_ATTACK", label="НАПАДЕНИЕ ТАРАКАНОВ",
            description="3 клика по центральной кнопке → пауза. 24 таракана; +1 очко за каждого.",
            source=EventSource.ACTION, implementation="legacy.roach_attack",
            config_file="evt_001_roach_attack.json", resources=("game_objects", "score", "main_gameplay"),
            exclusive_resources=("roach_input", "event_overlay"), subcategories=("ACTION_02",),
            phase_policy="CANCEL", interruptible=True,
            metadata={"status": "implemented", "admin_supported": True},
        ),
        EventDefinition(
            event_id="EVT_002_WORD_SHOCK", label="СЛОВЕСНЫЙ ШОК",
            description="3 клика → пауза 1 сек. Начать вторую тройку нужно в следующую секунду.",
            source=EventSource.ACTION, implementation="legacy.word_shock",
            config_file="evt_002_word_shock.json", resources=("event_timer",),
            exclusive_resources=("keyboard_text_input", "main_gameplay", "event_overlay"),
            subcategories=("ACTION_01",), phase_policy="CANCEL", interruptible=True,
            metadata={"status": "implemented", "admin_supported": True},
        ),
        EventDefinition(
            event_id="EVT_003_PLEASE_DONT_TOUCH", label="PLEASE DON'T TOUCH ANYTHING",
            description="Случайная 30-секундная проверка бездействия с сохранением истории игрока.",
            source=EventSource.RANDOM, implementation="events.evt003_runtime.EVT003Runtime",
            config_file="evt_003_please_dont_touch.json",
            resources=("event_timer",),
            exclusive_resources=("main_gameplay", "event_overlay", "mouse_input"),
            subcategories=("RANDOM_05",), phase_policy="CANCEL", interruptible=True,
            metadata={"status": "implemented", "admin_supported": True},
        ),
        EventDefinition(
            event_id="EVT_004_ADVENTURE_ROAD", label="ДОРОГА ПРИКЛЮЧЕНИЙ",
            description="Бой с драконом, который атакует элементы игрового интерфейса PALCHIK.",
            source=EventSource.ACTION, implementation="events.adventure_road_runtime.AdventureRoadRuntime",
            config_file="evt_004_road_of_adventures.json",
            resources=("main_gameplay", "event_overlay", "mouse_input", "cursor", "event_audio"),
            exclusive_resources=("main_gameplay", "event_overlay", "mouse_input"),
            subcategories=("ACTION_03",), phase_policy="CANCEL", interruptible=True,
            metadata={"status": "implemented", "admin_supported": True},
        ),
    )
    return EventCatalog(definitions, config_root)
