"""Minimal event lifecycle manager. Gameplay controllers migrate in verified steps."""
from __future__ import annotations
import time
import uuid
from .catalog import EventCatalog
from .contracts import EventInstance, EventStatus
from .resources import ResourceArbiter, ResourceClaim, ResourceMode

class EventManager:
    def __init__(self, catalog: EventCatalog, *, arbiter: ResourceArbiter | None = None, clock=None):
        self.catalog = catalog
        self.arbiter = arbiter or ResourceArbiter()
        self.clock = clock or time.monotonic
        self.instances: dict[str, EventInstance] = {}
        self.last_block_reason: dict[str, str] = {}

    def _claims_for(self, definition):
        exclusive = set(definition.exclusive_resources)
        resource_names = set(definition.resources) | exclusive
        for resource in sorted(resource_names):
            mode = ResourceMode.EXCLUSIVE if resource in exclusive else ResourceMode.SHARED
            yield ResourceClaim(definition.event_id, resource, mode, interruptible=definition.interruptible)

    def can_start(self, event_id: str) -> tuple[bool, str | None]:
        definition = self.catalog.get(event_id)
        if definition is None:
            return False, "UNKNOWN_EVENT_ID"
        if not self.catalog.is_enabled(event_id):
            return False, "EVENT_DISABLED"
        active_statuses = (EventStatus.ACTIVE, EventStatus.SUSPENDED, EventStatus.WAITING)
        if any(item.event_id == event_id and item.status in active_statuses for item in self.instances.values()):
            return False, "EVENT_ALREADY_ACTIVE"
        for claim in self._claims_for(definition):
            allowed, reason = self.arbiter.can_acquire(claim)
            if not allowed:
                return False, reason or "RESOURCE_CONFLICT"
        return True, None

    def begin(self, event_id: str, data: dict | None = None) -> EventInstance:
        allowed, reason = self.can_start(event_id)
        if not allowed:
            self.last_block_reason[event_id] = reason or "BLOCKED"
            raise RuntimeError(self.last_block_reason[event_id])
        definition = self.catalog.get(event_id)
        assert definition is not None
        acquired = []
        for claim in self._claims_for(definition):
            ok, claim_reason = self.arbiter.acquire(claim)
            if not ok:
                for resource in acquired:
                    self.arbiter.release(event_id, resource)
                self.last_block_reason[event_id] = claim_reason or "RESOURCE_CONFLICT"
                raise RuntimeError(self.last_block_reason[event_id])
            acquired.append(claim.resource)
        instance = EventInstance(
            instance_id=f"{event_id}:{uuid.uuid4().hex[:12]}", event_id=event_id,
            status=EventStatus.ACTIVE, started_at=self.clock(), data=dict(data or {}),
        )
        self.instances[instance.instance_id] = instance
        self.last_block_reason.pop(event_id, None)
        return instance

    def finish(self, instance_id: str, *, cancelled: bool = False, failed: bool = False, reason: str | None = None) -> EventInstance:
        instance = self.instances[instance_id]
        if instance.status not in (EventStatus.ACTIVE, EventStatus.SUSPENDED, EventStatus.WAITING):
            return instance
        if failed:
            instance.status = EventStatus.FAILED
        elif cancelled:
            instance.status = EventStatus.CANCELLED
        else:
            instance.status = EventStatus.COMPLETED
        instance.finished_at = self.clock()
        instance.failure_reason = reason
        self.arbiter.release_all(instance.event_id)
        return instance

    def active(self) -> tuple[EventInstance, ...]:
        return tuple(i for i in self.instances.values() if i.status == EventStatus.ACTIVE)
